close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 9 \n')
fprintf('General Linear Model with \n')
fprintf('Unknown Covariance \n')

fprintf('9.1 Background \n')
fprintf('In this chapter the general linear model is examined and problems associated an \n')
fprintf('unknown error covariance matrix are treated. The problems of heteroskedasticity \n')
fprintf('and autocorrelation are used as examples. \n')

fprintf('9.2 Estimated Generalized Least Squares \n')
fprintf('When the error covariance matrix is not known it must be consistently estimated \n')
fprintf('before the generalized least squares estimator can be used. The resulting \n')
fprintf('estimator is called the Estimated Generalized Least Squares (EGLS) estimator. \n')
fprintf('In this section the asymptotic properties of this estimator are considered and \n')
fprintf('algebraic conditions stated under which those properties hold. \n')

fprintf('9.3 Heteroskedasticity \n')
fprintf('An example of a heteroskedastic model is given in Section 9.3.7 in ITPE2. In \n')
fprintf('this example the error term is normal and independently distributed with mean \n')
fprintf('zero, but the error variance is not constant. Instead the error variance follows \n')
fprintf('the model of multiplicative heteroskedasticty described in Section 9.3.4 \n')
fprintf('The data contained in Table 9.1 is provided on the disk that accompanies this \n')
fprintf('book and is contained in the file TABLE9.1. LOAD that data and create the \n')
fprintf('design matrix X. \n')

% load dat[20,5] = table9.1;
% format 10,7;
% x = ones(20,1)~dat[.,2 3];

load mDataTable9_1
dat = mDataTable9_1;

x = [ones(20,1) dat(:, [2 3])];

fprintf('Create the vector sigma2 following (9.3.57) and compare to the tabled values. \n')
sigma2 = exp( -3 + 0.3 .* x(:,2) );
display([sigma2 dat(:,4)])
fprintf('Create the vector y using the given parameter values for and the first 20 official normal random numbers and compare to the tabled values. \n')
t = rows(x); % /* define t */
k = cols(x); % /* define k */
beta = [10 1 1]'; %; /* true beta */
% open f1=nrandom.dat; % /* open file */
load nrandom200
e = nrandom200(1:t); % /* read t obs. */
% f1 = close(f1); % /* close file */
e = sqrt(sigma2) .* e; % /* create e */
y = x*beta + e; % /* create y */
display([y dat(:,1)]) % /* print y */

fprintf('Begin by computing the least squares estimates of the coefficients. \n')
fprintf('Equation 9.3.58: \n')
b = x\y;
% format 8,5; b�; /* Eq. 9.3.58 */

display(b)

fprintf('Assuming (incorrectly) that the disturbances are homoskedastic, estimate the covariance matrix of the estimated coefficients. \n')

ehat = y - x*b;
sighat2 = ehat'*ehat/(t-k);
display(sighat2);
ixx = invpd(x'*x);
badcovb = sighat2*ixx;

fprintf('Equation 9.3.59: \n')
display(badcovb); %/* Eq. 9.3.59 */

fprintf('Print out the estimated coefficients in a row, with their (incorrectly) estimated standard errors beneath them. \n')
fprintf('The betas (OLS) are (Equation 9.3.60) \n')
disp(b'); % /* Eq. 9.3.60 */
fprintf('The (incorrectly) estimated standard errors of the betas (OLS) are (Equation 9.3.60) \n')
disp(sqrt(diag(badcovb))');

fprintf('Now compute the true covariance matrix for b, following Equation 9.3.61 in the \n')
fprintf('text. You can do this because you have the unusual information of the exact \n')
fprintf('structure of the errors, described in Equation 9.3.57 of the text. The function \n')
fprintf('DIAGRV puts the values of sigma2 on the diagonal of an identity matrix \n')


phi = diagrv(eye(t),sigma2);
covb = ixx*(x'*phi*x)*ixx;
fprintf('Equation 9.3.61: \n')
display(covb) %/* Eq. 9.3.61 */
fprintf('Compare the incorrectly computed standard errors with the true values. \n')
disp(sqrt(diag(badcovb))')
disp(sqrt(diag(covb))')
fprintf('Because you know the covariance matrix of the disturbances it is possible to compute the generalized least squares estimates and their covariance matrix. \n')
covg = invpd(x'*invpd(phi)*x);
fprintf('Equation 9.3.62: \n')
display(covg) %/* Eq. 9.3.62 */
bg = covg*x'*invpd(phi)*y;
fprintf('The betas (GLS) are (Equation 9.3.63) \n')
disp(bg') %/* Eq. 9.3.63 */
fprintf('The standard errors of the betas (GLS) are (Equation 9.3.63) \n')
disp(sqrt(diag(covg))')

fprintf('In general you will not know the exact structure of the error covariance matrix \n')
fprintf('and while you may suspect heteroskedasticity is present it is usually necessary \n')
fprintf('to test for its presence. First use the Breusch-Pagan test. \n')
fprintf('Using ehat computed above, compute the dependent variable to be used in the \n')
fprintf('test regression. \n')

sigtilde = ehat'*ehat/t;
e2 = (ehat.^2)./sigtilde;

fprintf('The independent variables to be used for the test are the first two columns of \n')
fprintf('the matrix X. \n')
z = x(:,[1 2]);
fprintf('The estimated coefficients are put into ahat. \n')
ahat = z\e2;
fprintf('Next compute the total and error sum of squares for the test regression \n')
sst = (e2 - mean(e2,1))'*(e2 - mean(e2,1));
e2hat = e2 - z*ahat;
sse = e2hat'*e2hat;
fprintf('The Breusch-Pagan test statistic is equal to one-half of the regression sum of \n')
fprintf('squares. \n')
q = .5*(sst - sse);
display(q)
chi2cdf(q,1);

fprintf('The statistic q is asymptotically distributed as Chi-square with 1 degree of \n')
fprintf('freedom. If q is greater than 3.84 (the 5 percent critical value) it is significant at the \n')
fprintf('5 percent level, and the hypothesis of homoskedasticity is rejected. \n')
fprintf('The Goldfeld-Quandt test requires running two separate regression on subsamples \n')
fprintf('of the data, and computing the residual sum of squares from each regression. \n')
fprintf('In general the data must be sorted according to an increasing error variance \n')
fprintf('before the partitioning. Here, however, if we assume that the error variance \n')
fprintf('increases with the magnitude of the second regressor, the data is already in the \n')
fprintf('proper order. \n')
fprintf('Include the first eight observations in the first regression. \n')
y1 = y(1:8,:);
x1 = x(1:8,:);
b1 = x1\y1;
e1 = y1 - x1*b1;
sse1 = e1'*e1;
fprintf('The second regression includes the last eight observations. \n')
y2 = y(13:20,:);
x2 = x(13:20,:);
b2 = x2\y2;
e2 = y2 - x2*b2;
sse2 = e2'*e2;
fprintf('The F-statistic for the Goldfeld-Quandt test is the ratio of the two residual sum of squares. \n')
f = sse2/sse1;
display(f)
fprintf('The F-statistic CDF is: \n')
disp(fcdf(f,5,5, 'upper'))

fprintf('At what significance level can you reject the hypothesis of homoskedasticity? \n')
fprintf('9.3.1 The Estimated Generalized Least Squares Estimator \n')
fprintf('Assuming the that least squares estimate, b, and the residuals, ehat, are still \n')
fprintf('in memory, the next step is to estimate the vector which is used to compute \n')
fprintf('the variances of the disturbances. From Equation 9.3.41 in the text, regress the \n')
fprintf('log of the squared errors on the first two columns of X. \n')
q = log(ehat.^2);
z = x(:,[1 2]);
ahat = z\q;
fprintf('Equation 9.3.64: \n')
display(ahat) % /* Eq. 9.3.64 */
fprintf('Adjust the constant term for bias. Although this is not necessary for the estimates of the coefficients, it will affect the estimated covariance matrix.\n')

ahat(1,1) = ahat(1,1) + 1.2704;
display(ahat)
fprintf('Compute the estimated generalized least squares estimator, following Equation 9.3.65 in the text. \n')
psihatv = exp(z(:,2)*ahat(2,1)); % /* diag. elements */
psihat = diagrv(eye(20), psihatv); % /* diagonal matrix */
invpsi = invpd(psihat); %/* inverse */
fprintf('Estimate GLS. \n')
begls = (x'*invpsi*x)\(x'*invpsi*y); %/* est. gls */
fprintf('Equation 9.3.65: \n')
disp(begls') %/* Eq. 9.3.65 */
fprintf('These parameters could alternatively be estimated by using ordinary least squares on transformed data (also called weighted least squares). \n')
ystar = y ./ sqrt(psihatv);
xstar = x ./ repmat(sqrt(psihatv), 1, cols(x));
begls = xstar\ystar;
disp(begls')
fprintf('Estimate paramater 2 and the covariance matrix for b. \n')
ehatg = y - x*begls;
sighatg2 = ehatg'*invpsi*ehatg/(t-k);
covegls = sighatg2*invpd(x'*invpsi*x);
fprintf('Equation 9.3.66: \n')
disp(covegls) %/* Eq. 9.3.66 */
fprintf('Summarize your results, with standard errors reported underneath the coefficients Equation (9.3.67). \n')
disp(begls')
disp(sqrt(diag(covegls))') %/* Eq. 9.3.67 */

fprintf('9.4 Exercises on Heteroskedasticity \n')
fprintf('The numercial exercises in this section can be carried out using the skills you \n')
fprintf('have learned in Section 9.3. \n')

fprintf('9.5 Autocorrelation \n')
fprintf('In this section of the text the problem of autocorrelation is defined. Procedures \n')
fprintf('for implementing EGLS are presented and tests for autocorrelation given. Begin \n')
fprintf('by considering the Example in Section 9.5.3c of ITPE2. \n')
fprintf('Type in the data used in Section 9.5.3c in the text. \n')

y = [4 7 7.5 4 2 3 5 4.5 7.5 5]';
x1 = [2 4 6 3 1 2 3 4 8 6]';
t = rows(y);
x = [ones(t,1) x1];
k = cols(x);
fprintf('Compute the least squares parameter estimates and the least squares residuals. \n')
b = x\y;
ehat = y - x*b;
fprintf('Assuming a first-order autoregressive process, compute the least squares estimate of rho given in Equation 9.5.40. \n')
et = ehat(2:10,1);
el = ehat(1:9,1);
rhohat = el\et;
display(rhohat)

fprintf('An asymptotic test for first-order autoregressive errors is described in Section \n')
fprintf('9.5.3a in the Text. \n')
fprintf('The test statistic z has an approximate standard normal distribution under the \n')
fprintf('null hypothesis. The null hypothesis is rejected at the 5 percent level if the absolute \n')
fprintf('value of Z is greater than 1.96. \n')

z = sqrt(t)*rhohat;
display(z)
fprintf('The Durbin-Watson test is described in Section 9.5.3b of the text. Compute the Durbin-Watson statistic using Equation 9.5.45. \n')
fprintf('For the numerical result refer to page 401 of ITPE2. \n')
d = (et-el)'*(et-el)/(ehat'*ehat);
display(d)

fprintf('To compute the exact critical value, use the procedure EXACTDW which is \n')
fprintf('given in section 9.6 begining on page 82. The theory behind this procedure \n')
fprintf('is beyond the scope of this course, so don�t worry about �how� it works for \n')
fprintf('now. It takes three arguments: d, the Durbin-Watson statistic; x, the matrix \n')
fprintf('of explanatory variables; and rho, the hypothesized value of rho. To compute the \n')
fprintf('probability that d is less than 1.037 given rho = 0, enter the following: \n')
fprintf('EXACTDW(d,x,0); \n')

fprintf('Matlab function \n')
[~,~,r] = regress(y,x);
[p,dw] = dwtest(r,x, 'Method', 'exact');
display(p)
display(dw)

fprintf('Mittelhammer et al Econometric foundations function. Pages 548-549. \n')
[dw1, p1] = fDW(r,x);
display(p1)
display(dw1)

% EXACTDW(d,x,0);
% EXACTDW function. Reference: Hill Adkins Using GAUSS for econometrics pages 86-87
fprintf('We were not able to replicate the function EXACTDW in Matlab. \n')
% val = fExactDW(d,x,0);

fprintf('What is the probability that DW is less than 1.037 assuming that  rho = .5? . \n')
fprintf('If you did not have a procedure such as EXACTDW, it might be useful to compute \n')
fprintf('Durbin and Watson�s (1971) approximation of the critical value. To do so, first \n')
fprintf('create the matrix A, shown in Equation 9.5.46 in the text. Do this by first \n')
fprintf('creating a matrix A1 which has 1�s on the off-diagonal. \n')
a1 = [zeros(t-1,1) eye(t-1); zeros(1,t)];

fprintf('Next create a matrix with 2�s on the diagonal, and using the matrix A1, put - \n')
fprintf('1�s on the off-diagonals. Then set the two corner elements equal to 1. \n')
a = eye(t)*2 - (a1 + a1');
a(1,1) = 1;
a(t,t) = 1;
% format 2,0; a;
fprintf('Notice that you can use the matrix A to compute the Durbin-Watson statistic, as shown in Equation 9.5.43 in the text. \n')
d = (ehat'*a*ehat)/(ehat'*ehat);
% format 8,4; d;
fprintf('Following Equations 9.5.60 and 9.5.61 compute the values P and Q. \n')
ixx = invpd(x'*x);
p1 = sum(diag(x'*a*x*ixx),1);
p = 2*(t-1) - p1;
% format 10,7; p;
q1 = sum(diag( x'*a*a*x*ixx ),1);
q2 = sum(diag( (x'*a*x*ixx)*(x'*a*x*ixx) ),1);
q = 2*(3*t-4) - 2*q1 + q2;
display(q)
fprintf('Now compute the expected value and variance of d. (See Equations 9.5.58 and 9.5.59.) \n')
exd = p/(t-k);
display(exd)
vard = 2*(q - p*exd)/( (t-k)*(t-k+2) );
display(vard)
fprintf('Using the values of EXDU and VARDU from the tables at the end of the text, compute \n')
fprintf('the parameters aa (a in the text) and bb (b in the text) Page 401 in ITPE2. \n')
exdu = 2.238;
vardu = 0.29824;
bb = sqrt(vard/vardu);
display(bb)
aa = exd - (exdu*bb);
display(aa)

fprintf('The approximate critical value is dustar is: \n')
du = 1.32;
dstar = aa + bb*du;
display(dstar)

fprintf('Compare the value of the critical value with the test statistic D. Do you accept \n')
fprintf('of reject the null hypothesis of no positive autocorrelation? \n')
fprintf('In Section 9.5.6 of ITPE2 a second example relating to autocorrelation is given. \n')
fprintf('First, load the data given in the file TABLE9.2 on the disk accompanying this \n')
fprintf('book and examine it. \n')
% load dat[20,3] = table9.2;
load mDataTable9_2
dat = mDataTable9_2;
y = dat(:,1);
x = [ones(20,1) dat(:,[2 3])];
dat=[y x];
display(dat)
fprintf('Before analyzing this data verify your understanding of the data generation \n')
fprintf('process by generating the vector y. The true parameter values are given on \n')
fprintf('page 411 of ITPE2 and refer to equation (9.6.2) \n')
beta = [10 1 1]';
sigma2 = 6.4;
rho = 0.8;
fprintf('Read in the N(0,1) random disturbances v and create the random errors e using \n')
fprintf('the �inverse� of the data transformation described in equations (9.5.31) and (9.5.32). \n')

t = rows(x); % /* define t */
k = cols(x); % /* define k */
% open f1 = nrandom.dat; /* open file */
% v = readr(f1,t); /* read t obs. */
% f1 = close(f1); /* close file */
load nrandom200
v = nrandom200(1:t);

v = sqrt(sigma2) .* v; % /* adjust variance */
e = zeros(t,1); % /* create e */
e(1,1) = v(1,1)./ sqrt(1-rho^2); % /* first element */
ind = 2; % /* begin loop */
while ind <= t;
    e(ind,1) = rho*e(ind-1,1) + v(ind,1); % /* t�th element */
    ind = ind + 1; % /* increment index */
end %/* end loop */
fprintf('Create the vector y and compare it to the data in Table 9.2. \n')

y = x*beta + e;
display([y dat(:,1)])
fprintf('Compute the least squares estimates. \n')
b = x\y;
display(b')
ehat = y - x*b;
t = rows(x);
k = cols(x);
sighat2 = ehat'*ehat/(t-k);
display(sighat2)
fprintf('Compute the least squares estimated covariance matrix for b. \n')
badcovb = sighat2*invpd(x'*x);
fprintf(' Compute the Durbin-Watson statistic to test for autocorrelation. \n')
edif = ehat(2:20,1) - ehat(1:19,1);
d = (edif'*edif)/(ehat'*ehat);
display(d)
fprintf('Compute the critical value of the Durbin-Watson statistic. \n')

fprintf('Matlab function \n')
[~,~,r] = regress(y,x);
[p,dw] = dwtest(r,x, 'Method', 'exact');
display(p)
display(dw)

fprintf('Mittelhammer et al Econometric foundations function. Pages 548-549. \n')
[dw1, p1] = fDW(r,x);
display(p1)
display(dw1)

% EXACTDW(d,x,0);
% EXACTDW function. Reference: Hill Adkins Using GAUSS for econometrics pages 86-87
fprintf('We were not able to replicate the function EXACTDW in Matlab. \n')
% val = fExactDW(d, x, 0);

fprintf('Compute the least squares estimate of rho. \n')
rhohat = ehat(1:19,1)\ehat(2:20,1);
display(rhohat)
fprintf('Transform the data using the estimated rho and the matrix dat containing both Y and X. \n')
dstar = dat - rhohat*dat([1 1:19],:);
dstar(1,:) = sqrt(1-rhohat^2)*dat(1,:);
fprintf('Take ystar and xstar out of the matrix dstar. \n')
ystar = dstar(:,1);
xstar = dstar(:,2:4);
fprintf('Compute the estimated generalized least squares estimator using the transformed data. \n')
bhat = xstar\ystar;
display(bhat')

fprintf('Predict the value of Yt for x2t = 20 and x3t = 20, ignoring the autocorrelation. \n')
xf = [1 20 20]';
yf = xf'*bhat;
display(yf);
fprintf('Now use the information concerning the autocorrelation. \n')
yf = yf + rhohat*(y(20,1) - x(20,:)*bhat);
display(yf);
