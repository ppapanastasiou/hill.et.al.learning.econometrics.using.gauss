function [b,covb]= fProbit(x, y, fProbitLi, iPrint, iPrintIntermediate)

if nargin <4 || isempty(iPrint)
    iPrint =1;
end

if nargin <5 || isempty(iPrintIntermediate)
    iPrintIntermediate =0;
end

% local probitli:proc;
% local t,k,b,iter,crit,pdf,cdf,g,d,h,db,bn,s,ofn1,ofn2,covb,std;
iter = 1; % /* define constants */
crit = 1;
b = x\y; % /* initial param. estimates */
while (iter < 50) && (crit > 1e-6);
    pdf = normpdf(x*b); % /* f and F */
    cdf = normcdf(x*b);
    % /* Gradient vector. See Eq. 19.2.19 */
    tmp1 = y.*(pdf./cdf);
    tmp2 = (1-y).*(pdf./(1-cdf));
    tmp1 = repmat(tmp1, 1, cols(x));
    tmp2 = repmat(tmp2, 1, cols(x));
    g = tmp1.*x - tmp2.* x;
    g = sumc(g);
    % /* Hessian Matrix. See Eq. 19.2.21 */
    % /* H = -X�DX where D is diagonal */
    d = pdf.*( (y.*(pdf+(x*b).*cdf)./cdf.^2) +((1-y).*(pdf-(x*b).*(1-cdf))./(1-cdf).^2));
    H = -(x .* repmat(d, 1, cols(x)))'*x;
    db = -inv(H)*g; % /* Full Newton-Raphson step */

    % gosub step; /* Determine step length */
    % step: /* Determine step length */
    s = 2;
    ofn1 = 0;
    ofn2 = 1;
    while ofn1 < ofn2;
        s = s/2;
        ofn1 = fProbitLi(b+s*db);
        ofn2 = fProbitLi(b+s*db/2);
    end
    % return;

    bn = b + s*db; % /* New estimates */
    crit = maxc(abs(db)); % /* Convergence criterion */

    if iPrintIntermediate ==1
    disp('iter:')
    disp(iter)
    disp('step length:')
    disp(s)
    disp('likelihood:')
    disp(fProbitLi(bn))
    disp('b:')
    disp(bn')

    end
    % gosub prnt; /* Print iteration results */
    % prnt: /* Print iteration results */
    % format 4,2; "iter = " iter;;
    % format 3,2; "step length =" s;;
    % format 10,6; "Likelihood =" probitli(bn);
    % format 10,6; " b = " bn�;?;
    % return;

    b = bn; % /* Replace old with new */
    iter = iter + 1; % /* Increment iteration */
end % /* End do-loop */

covb = -inv(H); % /* Define Covariance matrix */
stderr = sqrt(diag(covb)); % /* Asymptotic Std. Errors */
tvalues = (b./stderr)'; % /* Asymptotic t-values */

if iPrint ==1
    %print out
    disp('Final Results:')
    disp('Max Iterations:')
    disp(iter)
    disp('Estimates:')
    disp(b')

    disp('Std. Errors:')
    disp(stderr')    
    disp('t-values:')
    disp(tvalues)
end

return