function out = maxc(input)

out = max(input, [], 1);

return