function [bn, iter, dRsq] = fGNNR(bn)

global y

% local b1,num,gn,nr,flag,bn0,crit,iter;
bn0 = bn; %/* bn0 is starting value */
flag = 1;
while flag <= 2;
    bn = bn0;
    crit = 1;
    iter = 1;
    if flag ==1
        fprintf('Gauss-Newton \n')
    else
        fprintf('Newton-Raphson \n')
    end
    while (iter <= 25) && (crit > 1e-6);
        
        b1 = bn;
        % iter;; b1;; rsq(b1);
        fprintf('Iteration: %2.0f beta: %2.5f rsq: %2.5f \n', iter, bn, fRsq1(bn));
        num = fFirstDerivative(b1)'*(y-fFnb1(b1)); % /* numerator of (12.2.74) and (12.2.29) */
        gn = fFirstDerivative(b1)'*fFirstDerivative(b1); % /* denom. of (12.2.29) */
        nr = gn - (y-fFnb1(b1))'*fSecondDerivative(b1); % /* denom. of (12.2.74) */
        if flag == 1;
            bn = b1 + (num/gn); %/* full Gauss-Newton step */
        elseif flag == 2;
            bn = b1 + (num/nr); %/* full Newton-Raphson step */
        end
        iter = iter + 1;
        crit = abs(bn - b1);
    end
    flag = flag + 1;
    %?;
end

dRsq = fRsq1(bn);
%retp("");

return