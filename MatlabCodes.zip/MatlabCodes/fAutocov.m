function covb = fAutocov(param)

global x y

% local k,t,rho,b,sigmasq,dstar,ystar,xstar,varrho,varsig,data;
data = [y x];
k = rows(param)-2;
t = rows(data);
b = param(1:k,1);
rho = param(k+1,1);
sigmasq = param(k+2,1);
dstar = data - rho*[zeros(1,k+1); data(1:t-1,:)];
dstar(1,:) = sqrt( 1 - rho^2)*data(1,:);
% ystar = dstar(:,1);
xstar = dstar(:,2:k+1);
covb = sigmasq*invpd(xstar'*xstar);
varrho = (1-rho^2)/t;
varsig = 2*(sigmasq^2)/t;

fprintf('Final Results \n');
fprintf('bhat \n')
disp(b);
fprintf('rho: %2.2f \n', rho)
fprintf('sigmasq: %2.2f \n', sigmasq)
fprintf('bhat std.err: \n')
disp(sqrt(diag(covb)));
fprintf('rho std.err: %2.2f \n', sqrt(varrho))
fprintf('sigmasq std.err: %2.2f \n', sqrt(varsig))

return;