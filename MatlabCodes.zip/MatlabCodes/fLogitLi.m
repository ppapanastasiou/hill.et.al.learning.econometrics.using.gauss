function out = fLogitLi(b) % /* See Eq. 19.2.18 */

global x y

% local cdf,li;
cdf = 1 ./ (1 + exp(-x*b));
li = y .* log(cdf) + (1-y) .* log(1-cdf);

out = sumc(li);

% retp(sumc(li));
% endp;

return