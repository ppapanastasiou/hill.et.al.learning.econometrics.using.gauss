function out = fCES(b)

global x

out = nan(rows(x), cols(b));

for i = 1:cols(b)
    % local m1,m2,mid;
    m1 = x(:,1).^b(3,i);
    m2 = x(:,2).^b(3,i);
    mid = (b(2,i).*m1) + ( (1-b(2,i)).*m2 );
    out(:,i) = ( b(1,i) + (b(4,i) .* log(mid)) );
end

return