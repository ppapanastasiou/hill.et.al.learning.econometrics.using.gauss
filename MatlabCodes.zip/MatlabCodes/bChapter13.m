close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 13 \n')
fprintf('Stochastic Regressors \n')
fprintf('In this chapter the consequences of not having fixed regressors are examined \n')
fprintf('and the instrumental variable estimation technique used. \n')

fprintf('13.1 Independent Stochastic Regressor Model \n')
fprintf('When the regressor matrix is stochastic but independent of the error term then \n')
fprintf('the least squares estimator has desirable properties and is equal to the ML \n')
fprintf('estimator if the errors are normal. \n')

fprintf('13.2 Partially Independent Stochastic Regressors \n')
fprintf('If the regressors are only partially dependent on the errors, and not contemporaneously \n')
fprintf('correlated with them then the usual properties of the least squares \n')
fprintf('estimator hold asymptotically. \n')
fprintf('13.3 General Stochastic Regressor Models \n')

fprintf('When the errors are contemporaneously correlated with the error term the the \n')
fprintf('usual least squares estimator is biased and inconsistent. Instrumental variable \n')
fprintf('estimation is consistent but not asymptotically efficient, in general. \n')
fprintf('In Section 13.3.2 a numerical example is given. LOAD the data from TABLE13.1 \n')
fprintf('and check it. It consists of 20 artificial observations on x2, y and z2. \n')

% load dat[20,3] = table13.1;
load mDataTable13_1
dat = mDataTable13_1;
% format 8,4;
display(dat)

fprintf('Construct the matrices X and Z by adding an intercept variable \n')

t = rows(dat);
global x y z
fprintf('Define x y z as global variables \n')
x = [ones(t,1) dat(:,1)];
y = dat(:,2);
z = [ones(t,1) dat(:,3)];

fprintf('Compute the Instrumental Variables (IV) estimator in (13.3.24) and compare \n')
fprintf('to the OLS estimates. \n')
biv = x'*z\x'*y;
display(biv)
bols = z\y;
display(bols)

fprintf('The asymptotic covariance matrix of the IV estimator is computed in Equation \n')
fprintf('13.3.25. First calculate the residuals and then the estimated variance, without \n')
fprintf('correcting for the degrees of freedom. \n')

ehat = y - z*biv;
sig2 = ehat'*ehat/t;
display(sig2)

fprintf('Compute the estimate of the asymptotic covariance matrix. \n')
covb = sig2 * pinv(x'*z)*x'*x*pinv(z'*x);
display(covb)

fprintf('13.4 Measurement Errors \n')
fprintf('When errors of measurement exist in the X matrix a particular form of Errors \n')
fprintf('in Variables or Stochastic Regressor model is created. In this section several \n')
fprintf('estimators designed to deal with these problems are presented. A numerical \n')
fprintf('example is given in Section 13.4.3 First LOAD the data in TABLE13.2. It \n')
fprintf('consists of T = 15 observations on explanatory variables x2 and x3 and random \n')
fprintf('disturbances u and v. Examine the data. \n')

%% 
% load dat[15,4] = table13.2;
load mDataTable13_2
dat = mDataTable13_2;
t = rows(dat);

% re-define x
x = [ones(t,1) dat(:,[1 2])];
u = dat(:,3);
v = dat(:,4);
% format 10,5;
display([x u v]);

fprintf('The random disturbances u and v shown in Table 13.2 are rounded values. \n')
fprintf('Actually u and v are N(0, 0.2) and N(0, 0.5) and based on the first 30 �official� \n')
fprintf('normal random numbers. We will construct the exact values so the solutions in \n')
fprintf('the text can be reproduced exactly. \n')

% open f1 = nrandom.dat;
% u = readr(f1,15);
% v = readr(f1,15);
% f1 = close(f1);
load nrandom200
u = nrandom200(1:15,1);
v = nrandom200(16:30,1);
u = sqrt(.2)*u;
v = sqrt(.5)*v;
display([u v])

fprintf('Create the variables zstar, z and y using Equations (13.4.51)-(13.4.53). \n')
theta = [2 3 5]';
zstar = x*theta;

% re-define z
z = zstar + u;
beta = [10 0.8]';

% re-define y
y = [ones(t,1) zstar]*beta + v;
display([zstar z y])

fprintf('Regress z on x to produce (13.4.54). \n')
bz = x\z;
display(bz')

fprintf('Form the predicted value of z and regress y on this predicted value, with an intercept, to produce (13.4.55) \n')
zhat = x*bz;
binf = ([ones(t,1) zhat])\y;
display(binf)

fprintf('Alternatively, this estimate can be obtained directly from Equation 13.4.28. \n')
zmat = [ones(15,1) z];
xz = x'*zmat;
xty = x'*y;
ixx = pinv(x'*x);
binf = (xz'*ixx*xz)\(xz'*ixx*xty);
display(binf)

fprintf('To calculate the second two-stage estimator regress y on x and compute the predicted value of y, as in (13.4.58) \n')
by = x\y;
display(by)
yhat = x*by;

fprintf('Then regress z on the predicted value of y, with an intercept, following Equation 13.5.49. \n')
b0 = [ones(15,1) yhat]\z;
display(b0)
beta = 1/(b0(2,1));
alpha = -b0(1,1)*beta;
display(alpha)
display(beta)

fprintf('Or obtain the estimates directly from Equation 13.4.34. \n')
xya = x'*[ones(15,1) y];
b0 = (xya'*ixx*xz)\(xya'*ixx*xty);
display(b0)

fprintf('The third estimator is formed following (13.4.60)-(13.4.62), \n')
syy = (y - yhat)'*(y - yhat)/t; % /* Equation 13.4.38 */
display(syy)
szz = (z - zhat)'*(z - zhat)/t; % /* Equation 13.4.39 */
display(szz)
lambda = syy/szz; % /* Equation 13.4.37 */
display(lambda)

fprintf('The computation of the estimator (13.4.36b) actually assumes that the data is \n')
fprintf('in deviation from the mean form (See comments below equations (13.4.25 and \n')
fprintf('13.4.26)) so correct for the mean values at this time. \n')
yd = yhat - meanc(yhat);
zd = zhat - meanc(zhat);
yy = yd'*yd;
zz = zd'*zd;
zy = zd'*yd;
blam = (yy - lambda*zz + sqrt((lambda*zz - yy).^2 + 4*lambda*zy^2 ))/(2*zy);
display(blam)

fprintf('To obtain Goldberger�s Maximum Likelihood estimator the log-likelihood function \n')
fprintf('in Equation 13.4.44 must be maximized. The following PROC STOCHLI \n')
fprintf('computes the value of the log-likelihood function assuming y, x and Z are in \n')
fprintf('memory. The argument is a vector of initial estimates of Pi_z, as given in Equation \n')
fprintf('13.4.27, and consistent estimates of alpha and beta in Equation (13.4.20), which are \n')
fprintf('found by regressing y on hat(z), and an intercept, as in Equation 13.4.28. The proc \n')
fprintf('returns the value of the log-likelihood, which can be maximized using PROC \n')
fprintf('MAXM, which appears on page 133. \n')


fprintf('Run the procedure and make sure MAXM is in memory. Then, obtain initial \n')
fprintf('estimates as suggested above and form the vector p0 of initial values. \n')
bz = x\z;
zhat = x*bz;
binf = [ones(t,1) zhat]\y;
p0 = [bz; binf];

fprintf('Minimize the objective funtion to obtain ML estimates of the parameters. \n')
p = fMaxm(p0,@fStochli);
display(p)
