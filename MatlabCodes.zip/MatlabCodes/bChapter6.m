clear;close all;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 6 \n')
fprintf('The Normal General Linear \n')
fprintf('Model \n')
fprintf('In this Chapter of ITPE2 the linear statistical model of Chapter 5 is analyzed \n')
fprintf('with the additional assumption that the random disturbances follow a normal \n')
fprintf('distribution. \n')
fprintf('6.1 Maximum Likelihood Estimation \n')
fprintf('The maximum likelihood estimators of the parameters and 2 of the normal \n')
fprintf('linear model are presented in Sections 6.1-6.1.4. We begin by examining the \n')
fprintf('Monte Carlo results in Section 6.1.5. These simulations will use the 10,000 \n')
fprintf('random numbers in the GAUSS data file NRANDOM.DAT. In the experiments \n')
fprintf('the variance of the disturbance term is to be .0625. Thus the N(0,1) random \n')
fprintf('numbers will be multiplied by sqrt(.0625). The X matrix is the same one used \n')
fprintf('in Chapter 5 and is in the file JUDGE.X. The true betas are 10.0, 0.4 and 0.6 \n')
fprintf('as in Chapter 5. \n')
fprintf('First, create one sample of size T = 20, print out the sample values y, the N(0,1) \n')
fprintf('deviates and X, as in Equation 6.1.27. \n')


t = 20; %/* number of obs. */
k = 3; %/* number of regressors */
nsam = 1; %/* number of samples */
nr = t*nsam; % /* total obs. to read */
% open f1 = nrandom.dat; /* open file */
% e = readr(f1,nr); /* read nr obs. */
% f1 = close(f1); /* close file */

load nrandom200
e = nrandom200;
e = e(1:nr,1);

fprintf('In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape \n')
fprintf('reshape(Data,N,T))Transpose in GAUSS is equivalent to reshape(Data,T,N) in MATLAB \n')
u1 = (reshape(e,t,nsam)); %/* u1 is (T x NSAM) */
e1 = sqrt(.0625)*u1; %/* adjust variance */
%load x[t,k] = judge.x; %/* load X */
load mDataJudge
x = mDataJudge;
beta = [10.0 0.4 0.6]'; %/* true beta */
y1 = x*beta + e1; %/* create y */
%format 9,6; /* print */
% y1~u1~x; /* Eq. 6.1.27 */
disp([y1 u1 x])

fprintf('Now carry out a Monte Carlo experiment using NSAM = 10 samples. Do the \n')
fprintf('Monte Carlo experiments using PROC MC written for Chapter 5. You must \n')
fprintf('place the proc in memory or it must be in a file (MC.G) that can be found by \n')
fprintf('the GAUSS auto-loading feature. \n')
nsam = 10; %/* number of samples */
nr = t*nsam; %/* number of obs. */
% open f1 = nrandom.dat; /* open file */
load nrandom200
e = nrandom200;
e = e(1:nr, 1);%; /* read nr obs. */
% f1 = close(f1); /* close file */

fprintf('In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape \n')
fprintf('reshape(Data,N,T))Transpose in GAUSS is equivalent to reshape(Data,T,N) in MATLAB \n')
u = (reshape(e,t,nsam)); %/* u is (T x 10) */
e = sqrt(.0625)*u; %/* adjust variance */
[b, sighat2] = fMc(x,beta,e); %/* execute monte carlo */

fprintf('Print out the estimates and compare them to Table 6.1 in ITPE2. \n')
%format 8,5;
disp([b' sighat2])

%Calculate the true covariance matrix and examine it.
ixx = invpd(x'*x);
disp(ixx); %/* Eq. 6.1.28 */
truecov = .0625 * ixx;
disp(truecov) %/* Eq. 6.1.30 */

fprintf('Calculate the estimated variances of the parameter estimators for these samples \n')
fprintf('and compare the true and estimated variances to those in Table 6.2. \n')
truevar = diag(truecov);
tmp1=repmat(diag(ixx)',rows(sighat2),1);
tmp2= repmat(sighat2,1,cols(tmp1));
estvar = tmp1 .* tmp2;
disp(truevar')

disp(estvar) %/* Table 6.2 */
fprintf('Now carry out the experiment using NSAM = 500 samples, breaking the computations \n')
fprintf('into two parts as we did in Chapter 5. First construct, and SAVE, \n')
fprintf('the matrices of N(0,1) random numbers in this convenient form for later use. \n')
fprintf('They will be given a .FMT extension and can be LOADed when needed in later \n')
fprintf('chapters. \n')
nsam = 250; %/* number of samples */
nr = t*nsam; %/* obs. to read */
%open f1 = nrandom.dat; %/* open file */
f1 = randn(10000,1);
e1 = f1(1:nr); %/* read 250 samples */
e2 = f1(nr+1:nr+nr); %/* read 250 samples */
%f1 = close(f1); /* close file */

fprintf('In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape \n')
fprintf('reshape(Data,N,T))Transpose in GAUSS is equivalent to reshape(Data,T,N) in MATLAB \n')
e1 = (reshape(e1,t,nsam)); %/* e1 is (T x 250) */
e2 = (reshape(e2,t,nsam)); %/* e2 is (T x 250) */
%save e1nor = e1; /* saved to e1nor.fmt */
%save e2nor = e2; /* saved to e2nor.fmt */
%Transform the errors to have the desired variances
e1 = sqrt(.0625)*e1; %/* change variances */
e2 = sqrt(.0625)*e2;
%Execute the Monte Carlo.
[b1, s1] = fMc(x,beta,e1);%/* execute monte carlo */
[b2, s2] = fMc(x,beta,e2);

fprintf('Stack the regression parameter estimates into one (K x NSAM) matrix and the \n')
fprintf('estimates of the error variance into a (1 x NSAM) vector for use throughout the \n')
fprintf('rest of this chapter. \n')
b = [b1 b2]; %/* b is (K x 500) */
sighat2 = [s1' s2']; %/* sighat2 is (1 x 500) */

fprintf('Stack all the estimates into one matrix and clear memory of unneeded matrices. \n')
param = [b; sighat2];
e1 = 0; e2 = 0; %/* clear memory */
b1 = 0; b2 = 0;
s1 = 0; s2 = 0;

fprintf('Print out a summary of the Monte Carlo results using PROC MCSUM written \n')
fprintf('in Chapter 5, and compare the results to those on page 232 of ITPE2. \n')
fMcSum(param,x,beta,.0625); %/* summarize results */

fprintf('Use GAUSS�s QUICK GRAPHICS to construct histograms similar to Figures \n')
fprintf('6.1 - 6.4 in ITPE2. Use 30 intervals. Your graphs will not look exactly like \n')
fprintf('those in text as GAUSS will form partitions of the data that are not the same \n')
fprintf('as those in the text. \n')
fprintf('library qgraph; \n')

fig=figure(1);
set(fig, 'Color', 'white')
title('Histogram of the parameters')
subplot(2,2,1);
hist(param(1,:),30);
legend('\beta_1');
subplot(2,2,2);
hist(param(2,:),30)
legend('\beta_2');
subplot(2,2,3);
hist(param(3,:),30)
legend('\beta_3');
fprintf('The histogram for the estimated variances uses the Chi-squared random variable \n')
fprintf('(T - K)* sigma^2/.0625. \n')
chi2var = (t - k)*(sighat2')/0.0625;
subplot(2,2,4);
hist(chi2var,30)
%see http://www.mathworks.com/matlabcentral/answers/103035-how-do-i-add-a-hat-on-a-character-which-is-displayed-in-the-legend-of-a-figure-in-matlab-7-0-r14
% Create a blank legend
h = legend('');
% hchild is the handle to the children of the axes object.
% In this case it is a 3 by 1 vector and hchild(3) is the
% handle to the string in the legend
hchild = get(h,'children');
% Set LaTeX as the interpreter
set(hchild(2),'Interpreter','LaTeX');
% Add x with a hat to the legend in the current figure
set(hchild(2),'String','$$(T-K)\hat{\sigma^{2}}/\sigma^{2}$$');


%%
fprintf('6.2 Restricted Maximum Likelihood Estimation \n')
fprintf('In this Section exact linear restrictions are imposed on the Maximum Likelihood \n')
fprintf('or Least Squares estimators and the consequences studied. Write a procedure, \n')
fprintf('PROC RLS, that computes the restricted least squares parameter estimates \n')
fprintf('given b, the least squares estimates, r the (J x K) information design matrix, \n')
fprintf('rr a (J x 1) vector of known constants (the right-hand-side of Equation 6.2.1, \n')
fprintf('and the design matrix x. \n')

fprintf('Use PROC RLS to calculate restricted least squares estimates for the example \n')
fprintf('in Section 6.2.3 in ITPE2 using the NSAM = 500 ML/LS estimates b from the \n')
fprintf('Monte Carlo experiment in Section 6.1. \n')
r= [0 1 1];
rr = 1;
bstar = fRls(b,r,rr,x);

fprintf('Calculate the mean values of the RLS estimates and compare them to the true \n')
fprintf('values. The average value of the restricted intercept in the text is incorrect due \n')
fprintf('to a typographical error. \n')

disp(mean(bstar'));
fprintf('Calculate the average value of the estimated RLS covariance matrices. As an \n')
fprintf('estimator of the error variance used the unbiased estimates sighat2. Use a \n')
fprintf('DO-LOOP to carry out the computations. To speed up execution compute the \n')
fprintf('�fixed� part of the covariance matrix (See Equation 6.2.17) outside the loop. \n')

c = ixx - ixx*r'*invpd(r*ixx*r')*r*ixx;
ind = 1;
covbstar = zeros(k,k);
while ind < 500
    covbstar = covbstar + (sighat2(1,ind) .* c)/500;
    ind = ind+1;
end

fprintf('Print out the average covariance matrix and compare it to (6.2.22). \n')
disp(covbstar)

fprintf('Compute the true covariance matrix of the restricted least squares estimator \n')
fprintf('and compare it to the average. \n')
covrls = .0625 * c;
disp(covrls)

fprintf('Finally compute the �empirical� estimator variances and compare them to the \n')
fprintf('true and average values. \n')
disp(std(bstar').^2)

fprintf('6.3 Interval Estimation \n')
fprintf('6.3.1 Single Linear Combination of the Beta Vector \n')
fprintf('For interval estimation the inverse of the cumulative distribution function is \n')
fprintf('typically needed. Write a function to estimate the inverse of the Student�st \n')
fprintf('distribution. Within the function a sequence of t-values will be computed, \n')
fprintf('and the value closest to the specified alpha will be found using the MININDC \n')
fprintf('function. The corresponding t-value is then computed. \n')

fprintf('Use the function to compute the t-statistic for level = 0.025 and T - K degrees \n')
fprintf('of freedom with T = 20 and K = 3, and check it using CDFTC. \n')
alpha=0.025;
t=20;
k=3;
tstat = fInvt(t - k,.025);
disp([tstat tcdf(-tstat,t - k,'upper')])

fprintf('Compute the 95(6.1.26) using the estimates b from the 500 Monte Carlo samples. \n')
fprintf('See Equation 6.3.7b. Note that these statements compute the intervals for all \n')
fprintf('500 samples but can be used for a single sample as well. \n')
akk = sqrt(diag(ixx));
tmp1=repmat(tstat * akk,1,cols(b));
tmp2=repmat(sqrt(sighat2),rows(b),1);
width = tmp1 .* tmp2;
lb = b - width;
ub = b + width;

fprintf('Print out the point estimates and confidence intervals for 1 and 2 for the first \n')
fprintf('10 samples, as in Table 6.3 \n')
disp([b(1,1:10); ub(1,1:10); lb(1,1:10)]'); %/* table 6.3 */
disp([b(2,1:10); ub(2,1:10); lb(2,1:10)]');

fprintf('Compute the percent of the 500 samples in which the true value of the parameter \n')
fprintf('is contained within the interval for each parameter. \n')
within = (lb <= repmat(beta,1,cols(lb))) & (ub >= repmat(beta,1,cols(ub)));
disp(mean(within')')

fprintf('6.3.2 Two or More Linear Combinations of the Beta Vector \n')
fprintf('We will compute and graph a joint confidence interval for 2 and 3 using PROC \n')
fprintf('CONFID written in Chapter 3. \n')
fprintf('To compute the necessary F-statistic write a function to compute the inverse of \n')
fprintf('the F-distribution c.d.f. \n')

fprintf('Use the function to compute the .05 critical value for 2 and T - K degrees of \n')
fprintf('freedom, and check it using CDFFC. \n')

fstat = fInvf(2,t - k,.05);
disp([fstat fcdf(fstat,2,t - k,'upper')]);
fprintf('Use the estimates from the first Monte Carlo sample and compute the values \n')
fprintf('needed for the joint confidence interval for 2 and 3. \n')
b1 = b(:,1);
sig1 = sighat2(1,1);
cov1 = sig1*ixx;
pos = [3 2]';
d = fConfid(b1,cov1,fstat,pos);
% So that the scale of the graph will be consistent with that in the text use the
% QUICK GRAPHICS function SCALE.
% library qgraph;
% xx = [0 1.1];
% yy = [0 1.1];
% scale(xx,yy);
% Graph the confidence ellipse.
figure(2)
set(fig, 'Color', 'white')
scatter(d(:,1),d(:,2));
% Reset the default QUICK GRAPHICS parameter values using GRAPHSET.
% graphset;

fprintf('6.3.3 Interval Estimation of 2 \n')
fprintf('Write a function to compute the inverse of the Chi-square distribution. \n')
fprintf('Compute the critical values of the Chi-square distribution with T - K degrees \n')
fprintf('of freedom for alpha = .025 and .975 and check them. \n')
chi1 = fInvchi(t - k,.025);
chi2 = fInvchi(t - k,.975);
disp([chi1 chi2]);
disp([chi2cdf(chi1,t - k,'upper') chi2cdf(chi2,t - k,'upper')]);

fprintf('Compute the confidence intervals for 2 (See Equation 6.3.15) and print out the \n')
fprintf('point estimates and intervals for the first 10 samples, as in Table 6.4. \n')
lb = (t - k)*sighat2/chi1;
ub = (t - k)*sighat2/chi2;
disp([sighat2(1,1:10);[lb(1,1:10); ub(1,1:10)]]'); %/* table 6.4 */

fprintf('Compute the percent of the 500 intervals that contain the true value of 2. \n')
within = (lb <= 0.0625) & (ub >= 0.0625);
mean(within');

fprintf('6.3.4 Prediction Interval Estimator \n')
fprintf('Compute the 95 percentage prediction interval for y0 if x1 = x2 = x3 = 1. See Equation \n')
fprintf('6.3.21 in the text. Use the first Monte Carlo sample. \n')
x0 = [1 1 1]';
tstat = tinv(0.025, t - k);
tstat=abs(tstat);
width = tstat*sqrt(x0'*ixx*x0 + 1) .* sqrt(sighat2(1,1));
y0hat = x0'*b(:,1);

fprintf('Print out the lower bound, point estimate and upper bound. \n')
disp([y0hat-width y0hat y0hat+width])

fprintf('6.4 Hypothesis Testing \n')
fprintf('6.4.1 The Likelihood Ratio Test Statistic \n')
fprintf('Test the joint hypotheses that beta2 = 0.4 and beta3 = 0.6. First construct the matrix \n')
fprintf('r and the vector rr that describe the constraint to test. \n')
r= [0 1 0; 0 0 1];
rr = [0.4 0.6]';

fprintf('Write the function LAMBDA to compute the F-statistic for a given r, rr, b and \n')
fprintf('ixx (the inverse of xTx). See Equation 6.4 7 in the text. \n')

fprintf('Compute the F-statistic and its significance level for the first Monte Carlo sample. \n')
lam = fLambda(r,rr,b(:,1),ixx,sighat2(1,1));
j = rows(rr);
disp([lam fcdf(lam,j,t - k,'upper')]);

fprintf('What conclusion about the hypothesis would you make on the basis of this \n')
fprintf('sample of data? \n')
fprintf('The function LAMBDA computes the value of the likelihood ratio test statistic \n')
fprintf('for a single sample of data. In order to calculate the values of the test statistic \n')
fprintf('for all 500 Monte Carlo samples use a DO-LOOP. \n')
lam = zeros(500,1); %/* storage matrix */
ind = 1; %/* begin loop */
while ind < 500
    lam(ind,1) = fLambda(r,rr,b(:,ind),ixx,sighat2(1,ind));
    ind = ind + 1;
end
fprintf('Print out the values for the first 11 samples and compare with the 5value of a \n')
fprintf('F(2,17) distribution, 3.59. \n')
lam(1:11,1)';

fprintf('Compute the percent of test statistic values that are less than or equal to 3.59 \n')
mean(lam <= 3.59);

fprintf('Plot the histogram for the test statistics as in Figure 6.9. \n')
v = seqa(1,1,7);
figure(3)
set(fig, 'Color', 'white')
hist(lam,v);
[nelements,centers]=hist(lam,v);
fprintf('Compute the percent of test statistic values that fall in the intervals [0,1], (1,2], \n')
fprintf('..., (6,7]. The percentages reported in the text appear to be incorrect. \n')
disp(nelements'/500)

fprintf('6.4.2 A Single Hypothesis \n')
fprintf('A t-test is used to test a single hypothesis. Write a function to compute the \n')
fprintf('test statistic given in Equation 6.4.25. \n')

fprintf('Test the hypothesis that 1 is 10 using the first Monte Carlo sample. \n')
r = [1 0 0];
rr = 10;
ts = fTtest(r,rr,b(:,1),ixx,sighat2(1,1));
disp([ts tcdf(ts,t - k,'upper')]);
fprintf('Test the hypothesis that the sum of 2 and 3 is one. \n')
r =[ 0 1 1 ];
rr = 1;
ts = fTtest(r,rr,b(:,1),ixx,sighat2(1,1));
disp([ts tcdf(ts,t - k, 'upper')]);

fprintf('Do you reject, or not, the hypothesis? \n')
fprintf('Perform t-tests for the hypotheses that each of the parameters are equal to their \n')
fprintf('true values for the 500 Monte Carlo samples. \n')
tmp1=repmat(diag(ixx),1,length(sighat2));
tmp2=repmat(sighat2,length(diag(ixx)),1);
stderr = sqrt(tmp1.*tmp2);
tval = (b - repmat(beta,1,cols(b))) ./ stderr;

fprintf('Print out the t-values for the first 10 samples. \n')
disp(tval(:,1:10)');

fprintf('Compute the percent of test values that exceed the 5 percentage critical value, 2.11. \n')
disp(mean((abs(tval) >= 2.11)')');

fprintf('Graph a histogram of the test statistic values for each parameter and compare \n')
fprintf('to Figures 6.10 - 6.12. Once again your graphs will not be exactly the same as \n')
fprintf('those in the text due to different partitioning of the horizontal axis. \n')
figure(4)
set(fig, 'Color', 'white')
subplot(3,1,1);
hist(tval(1,:)',30);
subplot(3,1,2);
hist(tval(2,:)',30);
subplot(3,1,3);
hist(tval(3,:)',30);

fprintf('6.4.3 Testing a Hypothesis about sigma^2 \n')
fprintf('Test the hypothesis that sigma^2 = .0625, using Equation 6.4.28 in the text for the \n')
fprintf('first Monte Carlo Sample. \n')
chistat = (t - k)*sighat2(1,1)/.0625;
disp([chistat chi2cdf(chistat,t - k,'upper')]);

fprintf('Repeat the test for all the Monte Carlo samples and print out the test statistic \n')
fprintf('values for the first 10 samples. \n')
chistat = (t - k)*sighat2'/.0625;
disp(chistat(1:10,1));

fprintf('Compute the fraction of the sample values in which the hypothesis is not rejected. \n')
mean( (chistat > 7.56) & (chistat < 30.19) );

fprintf('Graph the empirical distribution of the test statistic. \n')
figure(5)
set(fig, 'Color', 'white')
hist(chistat,30);

fprintf('6.5 Summary Statement \n')
fprintf('Section 6.5 contains a summary of the contents of Chapter 6. It is a convenient \n')
fprintf('place to update PROC MYOLS written in Chapter 5. Add t-statistics to test \n')
fprintf('the hypotheses that the parameters, individually, are zero. \n')
fprintf('Your program should look something like the following. \n')

fprintf('6.6 Asymptotic Properties of the Least Squares \n')
fprintf('Estimator \n')
fprintf('In this Section the asymptotic or large sample distributions of the Least Squares \n')
fprintf('estimator are studied. Under certain conditions the least squares estimator has \n')
fprintf('a normal distribution in large samples no matter what the distribution of the \n')
fprintf('original population. \n')
fprintf('To examine this phenomenon we will use the Monte Carlo design from Chapter \n')
fprintf('5.10 which was based on uniform random disturbances with mean zero and \n')
fprintf('variance 2. Create T = 500 Monte Carlo samples and the least squares estimates \n')
fprintf('from Equation 5.10.1 using PROC MC. Recall that uniform (0,1) random \n')
fprintf('numbers have been SAVEed to the files E1UNI.FMT and E2UNI.FMT. \n')

t = 20; % /* define parameters */
k = 3;
nsam = 250;
nr = t*nsam;
%open f1 = urandom.dat;
f1 = rand(10000,1);
e1 = f1(1:nr); %/* read 1st 5000 obs. */
e2 = f1(nr+1:nr+nr); %/* read 2nd 5000 obs. */
% f1 = close(f1);
fprintf('In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape \n')
fprintf('reshape(Data,N,T))Transpose in GAUSS is equivalent to reshape(Data,T,N) in MATLAB \n')
e1 = (reshape(e1,t,nsam)); %/* 250 random vectors */
e2 = (reshape(e2,t,nsam)); %/* 250 random vectors */
e1 = sqrt(12)*(e1-0.5); %/* adjust to U(0,1) */
e2 = sqrt(12)*(e2-0.5);

beta = [10.0 0.4 0.6]';
load mDataJudge %/* create X */
x=mDataJudge;

e1 = sqrt(2)*e1; %/* create errors */
e2 = sqrt(2)*e2;
[b1, s1] = fMc(x,beta,e1); %/* execute Monte Carlo */
[b2, s2] = fMc(x,beta,e2);
b = [b1 b2]; %/* stack parameters */
sighat2 = [s1' s2'];
b1 = 0; b2 = 0; %/* clear */
s1 = 0; s2 = 0;

fprintf('Compute the means of the parameter estimates and compare them to the results \n')
fprintf('in Section 5.10 to verify that they are the same. \n')
disp([mean(b') mean(sighat2')]);

fprintf('The asymptotic distribution result for b in Equation 6.6.21 is made operational \n')
fprintf('by dropping the �limit� from Q and simplifying. The result is that b is "approximately" \n')
fprintf('normal in large samples with the usual mean and covariance matrix. \n')
fprintf('Consider the asymptotic distribution of the estimator for 2. Standardize the \n')
fprintf('random variable by subtracting beta2 from its estimator and dividing by the \n')
fprintf('true standard error. \n')
ixx = invpd(x'*x);
z2 = (b(2,:)' - beta(2,1))/(sqrt(2*ixx(2,2)));

fprintf('Calculate the mean and standard deviation of the standardized variable. \n')
disp([mean(z2) std(z2)])

fprintf('Now the question is, what is the probability distribution of z2? If the asymptotic \n')
fprintf('theory �works� the distribution should be N(0,1), if T = 20 is sufficiently large. \n')
fprintf('Write a procedure PROC ZGOF to carry out a simple Chi-square �goodnessof- \n')
fprintf('fit� test, which you studied in your basic statistics course. It compares the \n')
fprintf('observed to expected frequencies. The test statistic has a Chi-square distribution \n')
fprintf('if the observed values come from the distribution used to form the expected \n')
fprintf('frequencies. The hypothesis is rejected if the test statistic is too large. The \n')
fprintf('PROC ZGOF takes as argument the vector of observed values and prints the \n')
fprintf('value of the Chi-square statistic (21 degrees of freedom) and the p-value of the \n')
fprintf('test for a N(0,1) distribution. \n')

fprintf('Place PROC ZGOF in memory and use it to test the distribution of z2, and \n')
fprintf('clear memory. \n')
fZgof(z2);
b = 0; z2 = 0; sighat2 = 0;

fprintf('As the sample size increases the asymptotic approximation to the distribution \n')
fprintf('should get better. Try the experiment again for T = 40. Construct the larger x \n')
fprintf('by stacking x on top of itself. Larger vectors of errors are obtained by stacking \n')
fprintf('as well. \n')
t = 40;
x = [x;x]; %/* construct X */
e1 = [e1(:,1:125); e1(:,126:250)]; %/* construct errors */
e2 = [e2(:,1:125); e2(:,126:250)];
[b1, s1] = fMc(x,beta,e1); %/* run Monte Carlo */
[b2, s2] = fMc(x,beta,e2);
b = [b1 b2]; %/* stack */
b1=0; b2=0; s1=0; s2=0; %/* clear */
ixx = invpd(x'*x);
z2 = (b(2,:)'-beta(2,1))/sqrt(2*ixx(2,2)); %/* create z2 */

fZgof(z2); %/* carry out test */
b = 0; z2=0; %/* clear */
%Repeat for T = 10.
t = 10;
x=x(1:10,:); %/* use 10 rows of X */

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t = 20;
k = 3;
nsam = 250;
nr = t*nsam;
%open f1 = urandom.dat;
f1 = rand(10000,1);
e1 = f1(1:nr); %/* read 1st 5000 obs. */
e2 = f1(nr+1:nr+nr); %/* read 2nd 5000 obs. */
% f1 = close(f1);
% In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape
% reshape(Data,N,T))' in GAUSS is equivalent to reshape(Data,T,N) in MATLAB
e1 = (reshape(e1,t,nsam)); %/* 250 random vectors */
e2 = (reshape(e2,t,nsam)); %/* 250 random vectors */
e1 = sqrt(12)*(e1-0.5); %/* adjust to U(0,1) */
e2 = sqrt(12)*(e2-0.5);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

e1 = sqrt(2)*e1; % /* create errors */
e2 = sqrt(2)*e2;
e1 = [e1(1:10,:) e1(11:20,:)];
e2 = [e2(1:10,:) e2(11:20,:)];
[b1, s1] = fMc(x,beta,e1);
[b2, s2] = fMc(x,beta,e2); %/* run Monte Carlo */
b = [b1 b2]; %/* stack */
b1 = 0; b2 = 0; s1 = 0; s2 = 0; %/* clear */
ixx = invpd(x'*x);
z2 = (b(2,:)' - beta(2,1))/sqrt(2*ixx(2,2)); %/* create z2 */
fZgof(z2);
b = 0; z2 = 0; %/* carry out test */

fprintf('At this point you may be questioning how big the sample must be before the \n')
fprintf('asymptotic distribution starts to take effect. When the errors are independent \n')
fprintf('and identically distributed uniform random numbers it doesn�t take a very large \n')
fprintf('sample. But be assured that in most situations you will encounter �asymptotic \n')
fprintf('normality� does not occur in such small samples. To convince yourself that the \n')
fprintf('distribution is not approximately normal in samples of all sizes, let T = 5. \n')
t = 5;
x = x(1:5,:);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t = 20;
k = 3;
nsam = 250;
nr = t*nsam;
%open f1 = urandom.dat;
f1 = rand(10000,1);
e1 = f1(1:nr); %/* read 1st 5000 obs. */
e2 = f1(nr+1:nr+nr); %/* read 2nd 5000 obs. */
% f1 = close(f1);

fprintf('In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape \n')
fprintf('reshape(Data,N,T))Transpose in GAUSS is equivalent to reshape(Data,T,N) in MATLAB \n')
e1 = (reshape(e1,t,nsam)); %/* 250 random vectors */
e2 = (reshape(e2,t,nsam)); %/* 250 random vectors */
e1 = sqrt(12)*(e1-0.5); %/* adjust to U(0,1) */
e2 = sqrt(12)*(e2-0.5);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

e1 = sqrt(2)*e1;
e2 = sqrt(2)*e2;
e1 = [e1(1:5,:) e1(6:10,:) e1(11:15,:) e1(16:20,:)];
e2 = [e2(1:5,:) e2(6:10,:) e2(11:15,:) e2(16:20,:)];

[b1, s1] = fMc(x,beta,e1);
[b2, s2] = fMc(x,beta,e2);
b = [b1 b2];
b1 = 0; b2 = 0; s1 = 0; s2 = 0;
ixx = invpd(x'*x);
z2 = (b(2,:)'-beta(2,1))/sqrt(2*ixx(2,2));
fZgof(z2);


