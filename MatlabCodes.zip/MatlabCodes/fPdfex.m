function vOut=fPdfex(x)
vOut=3*exp(-3*x);
return