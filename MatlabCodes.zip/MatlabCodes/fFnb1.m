function out = fFnb1(beta)

global x1 x2

out = x1 .* beta + x2 .* (beta^2);
return