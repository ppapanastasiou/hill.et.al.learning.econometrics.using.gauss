close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 2 \n')
fprintf('2.1 \n')
fprintf('In this chapter we will use GAUSS to explore the concepts of probability and distribution theory discussed in Chapter 2 of ITPE2 \n')


u1=rand(20,1);
display(u1)

% rng(1);
u1=rand(20,1);
display(u1)

% 2.2
heads=(u1 <= 0.5);
sum(heads)


fprintf('2.3 \n')
fprintf('Random variables and Probability distributions \n')

u=rand(20,2);
heads=(u(:,1) <= 0.5) + (u(:,2) <= 0.5);
display(heads);

fprintf('Alternative using SUMC on the matrix transpose to obtain sum \n')
heads = sum(u <= 0.5,2);
display(heads);

n = 4000;
u = rand(n,2);
heads = sum(u <= 0.5,2);
v =[ 0 1 2]';
fx = hist(u,v)/n;
display(fx)

fprintf('Clear memory by setting u to zero \n')
u=[];

fprintf('A histogram of the simulated outcome can be constructed using GASSs Quick Graphics \n')
figure(1)
% [freq,centers] = hist(heads,v); %/* observed freq. */
hist(heads,v); %/* observed freq. */

pdfx = [0.25 0.50 0.25];
cumsum(pdfx,2);

x =seqa(0, 0.05, 41);
pdfx=fPdfex(x);

figure(2)
scatter(x, pdfx);
xval = [0.25 0.5];
cdfval=fCdfx(xval);
display([xval cdfval]);

fprintf('the c.d.f can be graphed for a vector of X-values \n')
cdfval=fCdfx(x);
figure(3)
scatter(x, cdfval);

fprintf('2.3a. Numerical integration \n')
x1= [xval; zeros(1,2)];
cdfex(1) = integral(@fPdfex,0,xval(1));
cdfex(2) = integral(@fPdfex,0,xval(2));
display([xval cdfex])

fprintf('The numerical integration can also be the basis of graphing the c.d.f \n')
fprintf('by repeating the integral for many value of x \n')
xl = [x'; zeros(1,41)];
for i=1:size(x1,2)
    cdfval(i) = integral(@fPdfex,0,xl(1,i));
end

figure(4)
scatter(x, cdfval);

fprintf('2.3b Simulating values of continuous random variables \n')
fprintf('Here we note a very useful property of c.d.fs of continuous random \n')
fprintf('variables. C.d.fs are continuous one-to-one monotonic and have an \n')
fprintf('inverse function. That means that for every value x of the random \n')
fprintf('variable X there is just one value of F(x) and for every value of F(x) \n')
fprintf('there is a unique value of X that corresponds to it. For the example 2.9 \n')
fprintf('we can determine the inverse function and use it to calculate the values \n')
fprintf('of X that correspond to given value of the c.d.f. It is assumed that the \n')
fprintf('matrices created at the end of Section 2.3 are still in memory. \n')

display([cdfex fInvcdfx(cdfex)])

fprintf('This knowledge is useful in several ways, one of which is that this makes \n')
fprintf('"simulating" the experiment (whatever it is) underlying the random \n')
fprintf('variable X easy. We can obtain random numbers taht follow this particular \n')
fprintf('p.d.f. as follows. Generate a vector of uniform random numbers, which \n')
fprintf('fall in the unit interval and let these random values represent c.d.f. \n')
fprintf('values. Then simply we use the inverse function of the c.d.f ti obtain \n')
fprintf('the corresponding X values and there you have it. The values of X \n')
fprintf('obtained are guaranteed to "come from" or "follow" the probability law \n')
fprintf('implied by the p.d.f (or c.d.f.) because that is the way they were \n')
fprintf('constructed. Construct a random sample of 20 values from the distribution \n')
fprintf('in Example 2.9 as follows: \n')

u1 =  rand(20,1);
vOut=fInvcdfx(u1);
% display(vOut)

fprintf('2.4 Mathematical Expectation \n')
fprintf('In Chapter 2.4. of ITPE2 the mathematical expectation of a random \n')
fprintf('variable X is defined to be the "average" value of X if the underlying \n')
fprintf('experiment is repeated an infinite number of times. \n')

fprintf('The mathematical expectation of a uniform random variable is E(X) (a +b)/2. \n')
fprintf('For a = 0 and b = 1 the random variable X has mathematical \n')
fprintf('expectation 0.5. \n')  

n=8000;
u1 = rand(n,1);
fprintf('%6s %6s %6s\n', 'avgx', 'min', 'max')
fprintf('%6.2f %6.2f %6.2f\n', mean(u1) , min(u1), max(u1))

fprintf('Now divide the unit interval into increments of 0.05 length, find the percent of values that fall in each interval \n')
x=seqa(0.05, 0.05, 20);
fx = hist(u1,x)/n;
display([x fx'])

fprintf('Compare your results to the true probability X falling in an interal of \n')
fprintf('length 0.05 \n')

fprintf('In Chapter 2.4.4. of ITPE2 the variance of a random variable is defined \n')
fprintf('to be the average squared difference between the values of the random \n')
fprintf('variable and tis mathematical expectation. In Exercise 2.14 you are asked \n')
fprintf('to determine the variance of a uniform random variable. For the uniform \n')
fprintf('random variable X on the unit interval compare the true value to its \n')
fprintf('numerical counterpart \n')

display(sum((u1 - 0.5).^2)/n)

fprintf('The variance of X is the average squared value of X from its true \n')
fprintf('expectation of mean. If the sample mean is used instead of the true mean, \n')
fprintf('and the divisor is (n-1) rather than n, we have the "sample variance. \n')

sampvar = sum((u1-mean(u1)).^2)/(n-1);
display(sampvar)

fprintf('The square root of the sample variance is the sample standard deviation, \n')
fprintf('just as the square root of the true variace of X is the standard \n')
fprintf('deviation of X. \n')

display(sqrt(sampvar))

fprintf('or using the function STDC \n')
display(std(u1))

fprintf('Alternatively, the basic sample statistics can be obtained by using the \n')
fprintf('GAUSS function DSTAT \n')

[wNam, wMean, wVar, wStd, wMin, wMax, wValid, wMis]= fDstat(u1);

fprintf('2.5 Some special distribution \n')

fprintf('Write a procedure to calculate descriptive statistics \n')

fprintf('Use the procedure STAT to compute descriptive statistics of u1 a (20 x 1) \n')
fprintf('vector of uniform random variable \n')

u1 = rand(20,1);
fStat(u1)

fprintf('Bernoulli and Binomial Random variables \n')

fprintf('Now use u1 to create a (20 x 1) matrix of Bernoulli (0,1) variables \n')
fprintf('equalt to 1 if the element of u1 <= (p=0.7). Then compute descriptive \n')
fprintf('statistics. \n')

p = 0.7;
x1 = (u1 <= p);
fStat(x1)

fprintf('Compare these sample statistics to the ture values of the mean and \n')
fprintf('standard deviation. Create 1000 values of the random variable and again \n')
fprintf('compare the sample statistics to the true values \n')

u1 = rand(1000,1);
fStat(u1)

p = 0.7;
x1 = (u1 <= p);
fStat(x1)

fprintf('A "binomial" random variable with parameters n and p is the sum of n \n')
fprintf('independent Bernoulli random variables each with parameter p. Thus to \n')
fprintf('create 20 values from a binomial distribution wth parameters n = 5 and p \n')
fprintf('= 0.7. To implements this idea create a (20 * 5) matrix of x1 Bernoulli \n')
fprintf('valeus and sum the columns. The SUMC function sums the elements in the \n')
fprintf('columns of a matrix so we will apply it to the transpose of the matrix \n')
fprintf('x1. \n')

u = rand(20,5);
x1 = u <=p;
x =sum(x1');
fStat(x')

fprintf('Do the sample values resemble the true mean and variance? Create 1000 \n')
fprintf('values and repeat the experiment. When you are done set the value of u \n')
fprintf('and x1 to zero to clear memory. \n')

u = rand(1000,5);
x1 = u <=p;
x =sum(x1');
fStat(x')

u=[];
x=[];

fprintf('It is very useful to have a "picture" of various probability \n')
fprintf('distributions in mind. For the binomial distribution write a function \n')
fprintf('that computes binomial probabilities \n')

fprintf('Now graph an example of the binomial p.d.f. First set n = 10 and p = \n')
fprintf('0.6.The binomial random variable X can take the values x=0,1,...10. \n')
fprintf('Create the vector of values starting with 0 ad increasing by increments \n')
fprintf('of 1 with total length of n+1 = 11 elemets. Compute the list the binomial \n')
fprintf('p.d.f. for these values. \n')

n = 10;
p = 0.6;
x = seqa(0,1,n+1);

pdfx = fPdfbn(x, n, p);
disp('------------x------------fx----')
disp([x pdfx])

fprintf('Now create a bar graph the p.d.f \n')

figure(5)
bar(x, pdfx)

fprintf('Change the value of n to 20 and 100 and repeat the exercise. Your graph \n')
fprintf('should become more symmetric and "bell-shaped".The reason for this \n')
fprintf('phenomenon willbe discussed in Chapter 3.3.3b in ITPE2. \n')

n = 100;
p = 0.6;
x = seqa(0,1,n+1);

pdfx = fPdfbn(x, n, p);
disp('------------x------------fx----')
disp([x pdfx])

fprintf('Now create a bar graph the p.d.f \n')

figure(6)
bar(x, pdfx)

fprintf('Normal, Chi-squared, Students t and F Random Numbers \n')

fprintf('The normal distributio is the most importnat distribution in statistics. \n')
fprintf('Its p.d.f is given in Equation 2.5.5. in ITPE2. Write a function to \n')
fprintf('calculate p.d.f. values \n')


fprintf('Graph the p.d.f. of a N(3,9) distribution. The true mathematical \n')
fprintf('expectation (or mean) of this random variable is 3 and its true standard \n')
fprintf('deviation is 3. \n')

x = seqa(-6, 0.18, 101);
y = fPdfNorm(x, 3, 9);
figure(7)
scatter(x,y)

fprintf('GAUSS has an internal function PDFN to calculate the pdf of a N(0,1) or \n')
fprintf('standard normal, random variable. Plot is p.d.f. \n')

x = seqa(-3, 0.06,101);
y = normpdf(x);
figure(8)
scatter(x,y)

fprintf('The function PDFN can also be used to compute the p.d.f. values of other \n')
fprintf('normal random variables by using the change of variable tehcnique. If X \n')
fprintf('is a N(0,1) random variable then Y = sig*X+mu is a N(mu, sg2) random \n')
fprintf('variable. To convert the p.d.f. if Z we solve for X = (Y-mu)/sig2. Verify \n')
fprintf('this by calculating several values of a N(3,) p.d.f. using the function PDFNORM  \n')
fprintf('you have written and using PDFN. \n')

x1 = seqa(-3, 0.18, 10);
y1 = fPdfNorm(x, 3, 9);
x = (x-3)/3;
y2 = normpdf(x)/3;
disp([x y1 y2])

fprintf('The c.d.f. of a normal random variable cannnot be obtained in a closed \n')
fprintf('form expression and thus normal probability calculations must be done \n')
fprintf('numerically. Students have relied on Tables of standard normal \n')
fprintf('probabilities until recent times. Computer packages like GAUSS make the \n')
fprintf('Tables obsolete. Normal probability calculations are made simple by the \n')
fprintf('fact that the c.d.f. of the N(0,1) is given by the function CFDN. For \n')
fprintf('example, calculate the probability that a N(3,9) random variable X falls \n')
fprintf('in the interval [0,1]. \n')

z1 = (0-3)/3;
z2 = (1-3)/3;
prob = normcdf(z2) -normcdf(z1);
display(prob)

fprintf('GAUSS also has a random number generator build in, RNDN or RNDNS that \n')
fprintf('creates random values from a standard normal N(0,1) distribution. The \n')
fprintf('disk accompanying this book contains the GAUSS data set NRANDOM.DAT that \n')
fprintf('contains 10,000 "official" N(0,1) values that will be used frequently in \n')
fprintf('later chapters. \n')

fprintf('Create a (20 x 1) vector of independently distributed standard normal \n')
fprintf('variables and print them out with their descriptive statistics. Compare \n')
fprintf('the mean and standard deviation of the sample with the true mean of the \n')
fprintf('distribution (0) and the true standard deviation (1). \n')

z1 = randn(20,1);
fStat(z1)

fprintf('Create a (500 x 1) matrix of standard normal numbers, and again compute \n')
fprintf('their descriptive statistics \n')

z = randn(500,1);
fStat(z)

fprintf('Create a (5000 x 1) matrix of standard normal numbers, and again compute \n')
fprintf('their descriptive statistics \n')

z = randn(5000,1);
fStat(z)

fprintf('The chi-square distribution is a special case of a gamma random variable. \n')
fprintf('The chi-square has a special place in statistics since it is closely \n')
fprintf('related to the normal distribution. The sum ofsquares of r independent \n')
fprintf('N(0,1) varaibles has a chi-square distribution with r degrees of freedom. \n')

fprintf('Write a function for the gamma p.d.f. given in Equation 2.5.4. in ITPE2. \n')

fprintf('Plot the gamma distribution for the special case of a = 1, the exponential  \n')
fprintf('distribution. Here the parameter b is set to 2. You might try alternative \n') 
fprintf('values of the parameter b. \n')

a = 1;
b = 2;
x = seqa(0, 0.2, 76);
pdfx = fPdfg(x, a, b);
figure(9)
scatter(x, pdfx)

fprintf('The gamma distribution for the special case of a = r/2 and b = 2, is the \n')
fprintf('chi-square distribution with r degrees of freedom. Set r = 4 and graph \n')
fprintf('the pdf. Try other values like r = 10, 30. \n')

r =4;
a = r/2;
b = 2;
x = seqa(0, 0.2, 76);
pdfx = fPdfg(x, a, b);
figure(10)
scatter(x, pdfx)

fprintf('Probabilities involving chi-squared random variables can be calculated \n')
fprintf('using a GAUSS function. For reasons that will become clear later that \n')
fprintf('GAUSS function DFCHIC calculates one minus the c.d.f. value. Calculate \n')
fprintf('the probability that a chi-square random variable with r = 7 degrees of \n')
fprintf('freedom is less than 3. \n')

prob = 1 - chi2cdf(3,7);
display(prob)

fprintf('Random values that follow a chi-square distribution can be created by \n')
fprintf('using the relation of the chi-square distribution to the standard normal. \n')
fprintf('Create a (20 x 1) vector of independently distributed Chi-square variables \n')
fprintf('with 5 degrees of freedom. Note that the true mean of a Chi-squared \n')
fprintf('random variable is equal to its degrees of freedom, and that its \n')
fprintf('variance is twice the degrees of freedom. How do the sample descriptive \n')
fprintf('statistics compare to with the true values? \n')

n = 20;
r = 5;
z = randn(n,r);
c1 =sum((z.^2)');
display(c1');
fStat(c1')

fprintf('Another important distribution related to the normal is the \n')
fprintf('t-distribution. The p.d.f. for a t-distribution is not given in Chapter 2 \n')
fprintf('of ITPE2. It is given in Chapter 4 as it is important for Bayesian \n')
fprintf('inference. A function to compute the p.d.f. a a t-random variable with n \n')
fprintf('degrees of freedom is given here. \n')

fprintf('Graph the p.d.f. for n = 10 degrees of freedom. \n')

x = seqa(-5,0.1,101);
pdfx = fPdft(x,10);
figure(11)
scatter(x, pdfx)

fprintf('Probabilities for the t-distribution are calculated using the c.d.f. The \n')
fprintf('students t c.d.f. is computed using CDFTC, which gives the value of (1 - \n')
fprintf('CDF of the t- distribution). The arguments are the data (x) and the \n')
fprintf('degrees of freedom (n). Calculate the probability that a t-random \n')
fprintf('variable with n = 10 degrees of freedom is greater than 2.0. \n')

x = 2;
n = 10;
prob = tcdf(x, n, 'upper');
display(prob)

fprintf('Random values from a t-distribution are created using its relation to the \n')
fprintf('normal and chi-square random variables. Create a (20 x 1) vector of \n')
fprintf('t-random values with df = 5 degrees of freedom, using a vector of \n')
fprintf('standard normal random values and independent vector independent vector \n')
fprintf('of chi-square random valuew with 5 degrees of freedom. Use the values in \n')
fprintf('z1 and c1 constructed earlier in this Section. \n')

df = 5;
t = z1 ./sqrt(c1'./df);
display(t)

fprintf('A t-random variable has true mean equal to 0, E[T]=0 and \n')
fprintf('variance that is df/(df-2). Calculate the sample statistics for sample \n')
fprintf('and compare. \n')

fStat(t);
display(df/(df-2))

fprintf('The final distribution to consider is the F-distribution. Its p.d.f. for \n')
fprintf('n1 and n2 degrees of freedom is given here for your convenience. \n')

fprintf('Graph the F(4,10) distribution \n')

x = seqa(0, 0.05, 76);
pdfx = fPdff(x, 4, 10);
figure(12)
scatter(x, pdfx)

fprintf('F probabilities are calculated using the CDFFC function that computes one \n')
fprintf('minus the c.d.f. value. Calcul;ate the probability that an F(4,10) random \n')
fprintf('variable is greater than 4.0. \n')

display(fcdf(4.0, 4, 10, 'upper'))

fprintf('Random F-values are created using chi-square random numbers. To create a \n')
fprintf('(20 x 1) vector of F-distribution values with 5 and 7 degrees of freedom. \n')
fprintf('The vector c1 from above is used for the numerator. The F distribution is \n')
fprintf('the ratio of two independent Chi-squares divided by their degrees of \n')
fprintf('freedom. An F-distribution with df1 and df2 degrees of freedom has a mean \n')
fprintf('equal to (df2/(df2-2)) and variance \n')
fprintf('(2*df2*df2*(df1+df2-2))/(df1*(df2-2)*(df2-2)*(df2-4). Again compare the \n')
fprintf('true values with the sample statistics \n')

q = randn(20,7);
c2 =sum((q.^2)');
df1 = 5;
df2 = 7;
f1 = (c1/df1)./(c2/df2);
% display(f1');
fStat(f1')
mn = df2/(df2-2);
var = (2*df2*df2*(df1+df2-2))/(df1*(df2-2)*(df2-2)*(df2-4));
display( [mn var]);




