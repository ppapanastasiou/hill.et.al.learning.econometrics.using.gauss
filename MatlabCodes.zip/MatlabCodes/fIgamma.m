function dOut = fIgamma(sigma, v, s)

dOut = 2/(gamma(v/2))*(v*s*s/2).^(v/2)...
    *(1./sigma.^(v+1)).*exp(-v*s*s./(2*sigma.*sigma));

return