function results=fStat(mInput, iResults)

if( nargin < 2 || isempty(iResults))
    iResults = 0;
end

wMean =mean(mInput,1);
wStd = nanstd(mInput,1);
wVar = wStd.^2;
wMin = nanmin(mInput,[],1);
wMax = nanmax(mInput,[],1);

if iResults == 1
    results.wMean = wMean;
    results.wStd = wStd;
    results.wVar = wVar;
    results.wMin = wMin;
    results.wMax = wMax;
end

disp('          mean          std          var            min          max')
disp([wMean' wStd' wVar' wMin' wMax'])

return