function c=counts(x, v, iMethod)

if nargin <3 || isempty(iMethod)
    iMethod = 1;
end

switch iMethod
    case 1
        [c,~]=hist(x,v);
        c = c';
    case 2
        % http://www.mathworks.com/matlabcentral/fileexchange/173-gauss/content/gauss/counts.m
        % COUNTS counts the number of elements of x that fall within v
        % COUNTS(x,v) returns the number of elements such that
        % v(1)<=x, ....v(n-1)<x<=v(n)
        c=[]; 
        nv=[-Inf; v];
        for i=2:rows(nv);
           t=sum(x<=nv(i) & x>nv(i-1));
           c(i-1,1)=t;
        end
    otherwise
        error('no method selected for count')
end

return