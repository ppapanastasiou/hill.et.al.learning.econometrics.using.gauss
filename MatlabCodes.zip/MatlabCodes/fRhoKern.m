function store = fRhoKern(rho)

global nu 

% local m,n,store,i,j,bstar,sse,xstar;
m = rows(rho); % /* define dimensions of rho */
n = cols(rho);
store = zeros(m,n); % /* initialize storage matrix */
i = 1;
while i <= m;
    j = 1;
    while j <= n;
        [bstar,sse,xstar] = fNewb(rho(i,j)); %/* gls */
        %/* Equation 12.3.41 */
        store(i,j) = sqrt(1 - rho(i,j)^2)*(sse^(-nu/2))/sqrt(det(xstar'*xstar));
        j = j + 1;
    end
    i = i + 1;
end
% retp(store);

return