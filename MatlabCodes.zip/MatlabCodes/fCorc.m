function [b,sse,covb]= fCorc(rho)

global t k

%local iter,crit,b,rho1,sse,sighat2,covb;
iter = 1;
crit = 1;
while (iter <= 25) && (crit > 1e-6)
    % "iteration " iter " rho " rho " crit " crit;

    [b,sse,xstar] = fNewb(rho);
%     fprintf(' iter: %2.0f \n', sse);
%     fprintf(' rho: %2.2f \n', rho);
%     fprintf(' crit: %2.2f \n', crit);
    rho1 = fNewRho(b);
    crit = abs(rho1 - rho);
    rho = rho1;
    iter = iter + 1;
end
sighat2 = sse/(t - k);
covb = sighat2 * invpd(xstar'*xstar);

% "SSE" sse;
% "Est " b�;;rho;;sighat2;
% "Std err" sqrt(diag(covb))�;;sqrt((1-rho^2)/t);;
% sqrt(2*(sighat2^2)/t);

fprintf('SSE: %2.2f \n', sse);
fprintf('bhat \n')
disp(b);
fprintf('rho: %2.2f \n', rho)
fprintf('sighat2: %2.2f \n', sighat2)
fprintf('bhat std.err: \n')
disp(sqrt(diag(covb)));
fprintf('rho std.err: %2.2f \n', sqrt((1-rho^2)/t))
fprintf('sighat2 std.err: %2.2f \n', sqrt(2*(sighat2^2)/t))

% retp(b,sse,covb);
return