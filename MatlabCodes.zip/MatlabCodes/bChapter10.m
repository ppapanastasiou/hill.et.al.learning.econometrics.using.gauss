close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Varying Parameter Models \n')
fprintf('10.1 Introduction \n')
fprintf('In this chapter you will learn how to use dummy variables to permit some \n')
fprintf('parameters in a regression model to change within the sample period and to \n')
fprintf('test for such a strucural change. You will also be introduced to varying and \n')
fprintf('random coefficient models. \n')

fprintf('10.2 Use of Dummy Variables in Estimation \n')
fprintf('The first application of dummy varibles is to account for a change in an intercept \n')
fprintf('value. Equation 10.2.11 describes an investment function which has a larger \n')
fprintf('intercept during the years 1939-1945 which are taken to be the period of World \n')
fprintf('War II. \n')

fprintf('The values of the exogenous variables x2 and x3 are found in the file labelled \n')
fprintf('TABLE10.1 on the disk accompanying this book. LOAD this data, and create \n')
fprintf('the dummy variable which is one during the war years and zero otherwise. \n')
% load xvar[20,2] = table10.1;
load mDataTable10_1
xvar = mDataTable10_1;

year = seqa(1935,1,20);
d = (year >= 1939) & (year <= 1945);

fprintf('We note in passing that GAUSS has three built-in functions that aid in the \n')
fprintf('construction of dummy variables. See your GAUSS manual for descriptions of \n')
fprintf('the functions DUMMY, DUMMYBR, DUMMYDN. These will not be used in \n')
fprintf('this Chapter. \n')

fprintf('Construct the intercept variable, and add it and the dummy varible as columns \n')
fprintf('one and two of the X matrix. \n')
x = [ones(20,1) d xvar];
t = rows(x);
k = cols(x);

fprintf('Construct a (20 x 1) vector of N(0,100) disturbances using the first 20 "official" \n')
fprintf('random numbers1 \n')
sig2 = 100;
% open f1 = nrandom.dat;
% e = readr(f1,t);
% f1 = close(f1);
load nrandom200
e = nrandom200(1:t);
e = sqrt(sig2)*e;
fprintf('Create the variable ya in Table 10.1 of the text using the parameter values in Equation 10.2.11. \n')
beta = [-10.0 20.0 0.03 0.15]';
ya = x*beta + e;
% Check the data.
% format 14,6;
fprintf('The vector ya can be found in page 424 of ITPE2. \n')
display([ya x])
fprintf('At the end of chapter 6 we updated our PROC MYOLS. Run that PROC now \n')
fprintf('to place in memory so that we can use it in this chapter. Obtain the OLS \n')
fprintf('parameter estimates for the model described by Equation 10.2.11 and compare \n')
fprintf('to the second column of Table 10.2. \n')

[b, covb] = fMyOls(x,ya, 0);
display(b)
display(covb)
fprintf('Repeat the regression omitting the dummy variable and compare to column 1 of Table 10.2. \n')
x1 = [ones(20,1) xvar];
[b1, covb1] = fMyOls(x1,ya, 0);
display(b1)
display(covb1)
fprintf('Now create the dummy variable Ct = 1 - Dt and include it in the model with the dummy variable Dt but excluding the overall intercept. Examine the data. \n')
c = 1 - d;
x2 = [d c xvar];
% format 14,6;
disp([ya x2])
fprintf('Obtain the OLS estimates of this model and compare to column 3 of Table 10.2. \n')
[b2, covb2] = fMyOls(x2,ya, 0);
display(b2)
display(covb2)
fprintf('As noted in the text Equations 10.2.3 and 10.2.8 are equivalent forms. Using the \n')
fprintf('coefficient estimates b2 we can calculate the coefficient of the dummy variable \n')
fprintf('Dt in (10.2.3) as follows. \n')

r = [1 -1 0 0];
delta = r*b2;
display(delta)
fprintf('Since delta is a linear combination of be, we can compute the standard error of the estimator as \n')
disp(sqrt(r*covb2*r'))
fprintf('Now consider the possibility that not only is the intercept different during the \n')
fprintf('war years but there is a difference in one or more slope parameters as well. \n')
fprintf('Construct yb in Table 10.1 using Equation 10.2.15 and examine the data. \n')
x = [ones(20,1) d xvar (xvar(:,2).* d)];
beta = [-10.0 20.0 0.03 0.15 -0.09]';
yb = x*beta + e;

fprintf('This will not work for us since we do not have the exact vector e (i,e the official normal random numbers) used. Hence define ya. The data can be found in page 424 of ITPE2. \n')
yb = [41.718 61.093 68.616 77.193 105.879 101.432 85.355 97.424 77.058 66.419 91.745 110.411 114.447 122.085 86.129 143.956 167.543 162.048 175.922 214.173]';
% format 10,6;
disp([yb x])
fprintf('Obtain the OLS results and compare to column 2 of Table 10.4. \n')
[b, covb] = fMyOls(x,yb, 0);
display(b)
display(covb)
fprintf('Now construct the �sets of equations� equivalent model and examine. \n')
x1 = [d c xvar(:,1) (xvar(:,2) .* d) (xvar(:,2) .* c)];
%format 10,6;
display(x1)
fprintf('Obtain the OLS results and compare to column 3 in Table 10.4. \n')
[b1, covb1] = fMyOls(x1,yb, 0);
display(b1)
display(covb1)

fprintf('10.3 The Use of Dummy Variables to Test for a \n')
fprintf('Change in the Location Vector \n')
fprintf('Assuming that XVAR, the dummy variables Dt and Ct and the random disturbances \n')
fprintf('E are still in memory, construct the values yc in Table 10.1 using \n')
fprintf('Equation (10.3.1) and examine the data. \n')

x = [ones(20,1) d xvar(:,1) (xvar(:,1) .* d) xvar(:,2) (xvar(:,2).* d)];
beta =[ -10 20 0.03 0.03 0.15 -0.09]';
yc = x*beta + e;
% format 10,6;
disp([yc x])

fprintf('This will not work for us since we do not have the exact vector e (i,e the official normal random numbers) used. Hence define yc. The data can be found in page 424 of ITPE2. \n')
yc = [41.718 61.093 68.616 77.193 173.565 165.398 140.378 145.064 129.540 117.035 151.976 110.411 114.447 122.085 86.129 143.956 167.543 162.048 175.922 214.173]';

fprintf('Compute the unrestricted and restricted regressions as in Table 10.6 using fMyOls and compute the test statistic u in Equation 10.3.2. \n')
fprintf('Unrestricted model page 434 ITPE2 \n')
[bu, covbu] = fMyOls(x,yc,0); %/* unrestricted model */
sseu = sum((yc - x*bu).^2,1);
df = rows(x) - cols(x);
sighat2 = sseu./df;

display(bu)
display(covbu)
display(sseu)
display(df)
display(sighat2)

fprintf('Restricted model page 434 ITPE2 \n')
xr = [ones(20,1) xvar]; % /* restricted model */
[br, covbr] = fMyOls(xr,yc,0);
sser = sum((yc - xr*br).^2,1);
dfr = rows(xr) - cols(xr);
sighat2r = sser./dfr;

u = (sser - sseu)./(3*sighat2); %/* test statistic */
pval = fcdf(u,3,df,'upper'); %/* p-value */
Fcritval = finv(0.99, 3, 14);

fprintf('The F critical value is (Page 434 ITPE2): %2.2f \n', Fcritval);
display(br)
display(covbr)
display(sser)
display(dfr)
display(sighat2r)

display(u)
display(pval)

fprintf('10.4 Systematically Varying Parameter Models \n')
fprintf('This section contains a discussion a general way to incorporate both systematic \n')
fprintf('and/or random parameter variation. To illustrate we will consider an alternative \n')
fprintf('way to model the data generation process of the dependent variable yb \n')
fprintf('which was introduced in Section 10.2. Instead of including intercept and slope \n')
fprintf('dummy variables we will consider the possiblity that these coefficients vary systematically \n')
fprintf('over time. In particular we will �model� the parameter variation as \n')
fprintf('beta_1 = delta_1 + delta_2*year_t and beta2 = gamma_1 + gamma_2*yeart. It should be stressed that this \n')
fprintf('specification is incorrect and we are using it only for illustration purposes. \n')
fprintf('Construct the matrix of explanatory variables following Equations 10.4.2 - 10.4.5. \n')

xa = [ones(20,1) year xvar(:,1) (xvar(:,1).*year) xvar(:,2)];

fprintf('Estimate this "unrestricted" model and calculate the sum of squared residuals. \n')
[ba, covba] = fMyOls(xa,yb,0);
sseu = (yb - xa*ba)'*(yb - xa*ba);
display(sseu)

fprintf('Now estimate the "restricted" model, which assumes that delta_2 = gamma_2 = 0. \n')
x = [ones(20,1) xvar];
[b, covb] = fMyOls(x,yb,0);

fprintf('Compare the restricted and unrestricted estimates. Compute the sum of squared \n')
fprintf('residuals for the restricted model and test the hypothesis that the parameters \n')
fprintf('in question do not vary linearly with time. \n')

sser = (yb - x*b)'*(yb - x*b);
display(sser)
df = rows(xa) - cols(xa);
u = (sser - sseu)/(2*sseu/df);
pval = fcdf(u,2,df,'upper');
display(u)
display(pval)

fprintf('Thus despite the apparantly substantial changes in the parameter estimates \n')
fprintf('caused by including the variable time, their inclusion does not significantly \n')
fprintf('affect the fit of the model. \n')

fprintf('10.5 Hildreth-Houck Random Coefficient Models \n')
fprintf('In this section the essentials of the Hildreth-Houck random coefficient model are \n')
fprintf('presented and an estimation procedure outlined. To illustrate the computational \n')
fprintf('procedure consider the dependent variable yc considered in Section 10.3. This, \n')
fprintf('of course, is an incorrect assumption for the data generation process and we are \n')
fprintf('using it only for illustration purposes. \n')
fprintf('Assuming the variable yc is still in memory, obtain the least squares estimates \n')
fprintf('of the model assuming no parameter variation. \n')
x = [ones(20,1) xvar];
[b, covb]= fMyOls(x,yc,0);
fprintf('Follow the procdure for estimating the parameter covariance matrix Sigma discussed \n')
fprintf('below Equation 10.5.7. First calculate the OLS residuals and square them to \n')
fprintf('form edot. \n')
ehat = yc - x*b;
edot = ehat .* ehat;
fprintf('Construct the idempotent matrix m, and square its elements to form mdot. \n')
m = eye(20) - x*invpd(x'*x)*x';
mdot = m .* m;
fprintf('Form the matrices z and f. \n')
z = [ones(20,1) (2*x(:,2)) (2*x(:,3)) (x(:,2).^2) (2*x(:,2) .* x(:,3)) (x(:,3).^2)];
f = mdot * z;
fprintf('Estimate the parameters alpha by regressing edot on f. \n')
ahat = f\edot;
fprintf('Form the estimate of the matrix Sigma and examine it. \n')

