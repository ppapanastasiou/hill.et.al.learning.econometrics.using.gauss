function dOut=fStdig(v, s)

dOut=sqrt(fM2ig(v, s)- (fMlig(v, s).^2));

return