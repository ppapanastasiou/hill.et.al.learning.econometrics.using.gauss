function  out = fMcg(x, beta, rho, estar)
% local t,k,nsam,psi,i,e1,y,b,sighat2,ipsi,bhat,sighatg2;
t = rows(x); %/* define constants */
k = cols(x);
nsam = cols(estar);
psi = eye(t); %/* create psi */
i = 1;
while i <= t
    j = i+1;
    while j <= t;
        psi(i,j) = rho^(j - i);
        psi(j,i) = psi(i,j);
        j = j+1;
    end
i = i+1;
end
psi = psi ./ (1-rho^2);
e1 = estar(1,:)/sqrt(1 - (rho^2)); % /* create e */
y = repmat(x*beta,1,cols(estar)) + recserar(estar,e1,rho*ones(1,nsam)); %/* create y */ 
b = x\y; %/* ols */
sighat2 = sumc((y-x*b).*(y-x*b))./(t-k);
ipsi = invpd(psi); %/* gls */
bhat = (x'*ipsi*x)\(x'*ipsi*y);
sighatg2 = sumc( (ipsi*(y - x*bhat)).*(y - x*bhat))./(t - k);
% retp(b|sighat2�|bhat|sighatg2�);
b = b';
bhat = bhat';
out = [b sighat2 bhat sighatg2];

return
