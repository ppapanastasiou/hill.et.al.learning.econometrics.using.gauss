function dOut=fMlig(v, s)

dOut=sqrt(v/2)*gamma((v-1)/2)*s/gamma(v/2);

return