% bDemoGradientApprox.m: Demoskript fuer fGradApprox
% Version: Februar 2014
%
% Copyright (c) 2013, Th. Poddig, A. Varmaz, Ch. Fieberg
%
% Bestandteil des Buchs: 
% Computational Finance von Th. Poddig, A. Varmaz, Ch. Fieberg

% Alles loeschen
clear; clc; close all;

% Punkt setzten
vX = [2;3];

% Gradient vektorielle Funktion
mGrad = fGradApprox( @fTestGradVec, vX, 1e-5, 1 );