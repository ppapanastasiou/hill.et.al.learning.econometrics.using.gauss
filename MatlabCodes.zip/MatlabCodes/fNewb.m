function [bstar,sse, xstar] = fNewb(rho)
global y x k t 

% /* Transform the data */
data = [y x];
dstar = data - rho*[zeros(1,k+1); data(1:t-1,:)];
dstar(1,:) = sqrt( 1 - rho^2)*data(1,:);
ystar = dstar(:,1);
xstar = dstar(:,2:k+1);
% /* Obtain the estimates */
bstar = xstar\ystar;
sse = (ystar - xstar*bstar)'*(ystar - xstar*bstar);
% retp( bstar,sse,xstar );
% endp;

return