clear;close all;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 4 Bayesian Inference \n')

fprintf('In this Chapter the elements of Bayesina inference are presented and used \n')
fprintf('to make inferences about the mean and variance of a normal population. \n')
fprintf('Informative and noninformative "prior" distributions are introduced as \n')
fprintf('ways of incorporating nonsample information. \n')

fprintf('4.2 Bayesian inference for the mean of a Normal distribution (Known \n')
fprintf('Variance) \n')

fprintf('In this Section prior and posterior distributions for the mean of a \n')
fprintf('normal population are introduced under the assumption that the variance \n')
fprintf('of the distribution is known. In Section 4.2.1 the example concerns \n')
fprintf('weekly receipts (in thousands of dollars) at Louisiana Fried Chicken \n')
fprintf('oulet. A sample of 10 weekly receipts is taken. \n')

fprintf('Put the data into the vector y. \n')

y = [4.74 7.11 5.31 6.28 6.09 8.52 2.78 7.38 5.44 5.72]';

fprintf('The sample mean is the point estimator of the population mean \n')
fprintf('introduced in Chapter 3. Recall that its properties were based on the \n')
fprintf('notion of repeated sampling, or Sampling Theory. \n')

t = rows(y);
b = sum(y)/t;
fprintf('b is %5.2f \n', b);

fprintf('Assuming that the receipts are normally distributed with a variance of \n')
fprintf('4, compute the 95 percentage confidence interval. (See Equation 4.2.2.) \n')

sigma2 =4;
interval = 1.96*sqrt(sigma2/t);
fprintf('lower 95 perc. interval: %5.2f \n', (b - interval));
fprintf('upper 95 perc. interval: %5.2f \n', (b + interval));


fprintf('Suppose that there is a 0.95 probability that mean weekly receipts falls \n')
fprintf('between $5000 and $11,000. The Bayesian appproach uses this information \n')
fprintf('to construct a "prior" distribution. Again assumig a normal \n')
fprintf('distribution, the assumption can be translated in two equations: bbar - \n')
fprintf('1.96*sigbar = 5  and bbar + 1.96*sigbar = 11. To solve this system of \n')
fprintf('linear simultaneous equaton, first rewrite them in matrix notation: A*p \n')
fprintf('= C, where p = [bbar sigbar] \n')

a = [1 -1.96; 1 1.96];
c = [5 11]';

fprintf('Solve the above equation for p and print out the values of bbar and \n')
fprintf('sigbar \n')

% p = inv(a)*c;
p = a\c;
bbar = p(1,1);
sigbar = p(2,1);
fprintf('bbar: %2.2f \n', bbar);
fprintf('sigbar: %2.2f \n', sigbar);
fprintf('sigbar^2: %2.2f \n', sigbar^2);

fprintf('We note in passing that matrix division could havebeen used p = a\c;  \n')

fprintf('Given the mean and standard deviation computed above, other probability \n')
fprintf('statements about the mean can be made by using the standard normal \n')
fprintf('distribution. Compute the probability that beta is less than 8. \n')

z = (8 - bbar)/sigbar;
fprintf('probability that beta is less than 8: %2.2f \n',  normcdf(z));

fprintf('Compute the probability that beta is between 6 and 10. \n')

z1 = (6 - bbar)/sigbar;
z2 = (10 - bbar)/sigbar;
fprintf('probability that beta is between 6 and 12: %2.2f \n',  (normcdf(z2) - normcdf(z1)));

fprintf('Compute the probability that beta is between 4 and 12 \n')

z1 = (4 - bbar)/sigbar;
z2 = (12 - bbar)/sigbar;
fprintf('probability that beta is between 4 and 12: %2.2f \n',  (normcdf(z2) - normcdf(z1)));

fprintf('Next we compute the posterior distribution by combining the prior \n')
fprintf('information with the sample informaton using Bayes theorem (4.2.6). The \n')
fprintf('posterior distribution is normal (See Equation 4.2.15) with mean and \n')
fprintf('variance given in Equations 4.2.11 and 4.2.12. \n')

fprintf('To calculate these values first calculate the precision of the prior \n')
fprintf('information (h0) and the precision of the sample information (hs) using \n')
fprintf('the variances defined above. See Equation 4.2.13. \n')

h0 = 1/(sigbar.^2);
fprintf('h0: %2.2f \n', h0);
hs = t/sigma2;
fprintf('hs: %2.2f \n', hs);

fprintf('The posterior mean (bdb) is a weighted average of the sample mean (b) \n')
fprintf('and the prior mean (bbar) with weights given by the precision. \n')

bdb = (hs*b + h0*bbar)/(hs + h0);   % Eq. 4.2.11
fprintf('bdb: %2.2f \n', bdb);

fprintf('The precision of the posterior distribution (h1) is the sum of the prior \n')
fprintf('and sample precisions, and is equal to the inverse of the variance \n')
fprintf('(sigdb2) \n')

h1 = h0 +hs;                        % Eq. 4.2.13
sigdb2 = 1/h1;                      % Eq. 4.2.12
fprintf('sigdb2: %2.2f \n', sigdb2);

fprintf('The posterior distribution can be used to make probability statements \n')
fprintf('about the mean just as with the prior. Compute the probability that the \n')
fprintf('mean is grater than 6 using the posterior distribution. \n')

sigdb = sqrt(sigdb2);
z = (6 - bdb)/sigdb;
fprintf('mean is greater than 6 using the posterior distribution: %2.2f \n', normcdf(z, 'upper'));

fprintf('The  prior and posterior distributions can be compared by graphing them \n')
fprintf('together. Since the prior and posterior distributions are both normal, \n')
fprintf('write a function to compute the probability density function of the \n')
fprintf('normal random variable (See Equation 4.2.4). \n')

fprintf('Create a vector of values b (bvec) in the relevant range. Then compute \n')
fprintf('the prior and posterior probability densities for those values. \n')

bvec = seqa(3, 0.1, 101);
pdfprior = normpdf(bvec, bbar, sigbar);
pdfpost = normpdf(bvec, bdb, sigdb);

fprintf('Graph both the prior (pdfprior) and posterior (pdfpost) values aginst the \n')
fprintf('values in bvec (See Figure 4.1 in the text) \n')

fig1 = figure(1);
set(fig1, 'Color', 'white')
p1 = plot(bvec, pdfprior, bvec, pdfpost);
set(p1, 'LineStyle', '-', 'LineWidth' , 2)
title('Figure 4.1: Prior and posterior densities for \beta when \sigma is known')
legend('Prior','Posterior')
xlabel('\beta')

fprintf('Different versions of pdf norm \n')
dPdf = fPdfNorm(bvec, bbar, sigbar^2);
dPdf1 = fPdfNorm1(bvec, bbar, sigbar);
dPdf2= normpdf(bvec, bbar, sigbar);
dPdf3 = norm_pdf(bvec, bbar, sigbar^2);
wPdfs =[dPdf dPdf1 dPdf2  dPdf3];
disp(wPdfs)

fprintf('Examine how the distribution change when you increase the precision \n')
fprintf('(decrease the variance) of the prior information. Let sbara equal the new \n')
fprintf('standard deviation of the prior distribution, equal to half of that of \n')
fprintf('the old prior distribution. Recompute the values for the precisions and \n')
fprintf('the posterior mean and standard error. \n')

sbara =  sigbar/2;
h0a = 1/(sbara^2);
h1a = h0a + hs;
bdba = (hs*b + h0a*bbar)/(hs + h0a);
fprintf('bdba: %2.2f \n', bdba);
sigdb2a = 1/h1a;
fprintf('sigdb2a: %2.2f \n', sigdb2a);
sdba = sqrt(sigdb2a);

fprintf('Compute the probability densities for the values in bvec for the new \n')
fprintf('prior and posterior distributions, and then graph them. \n')

pdfpria = normpdf(bvec, bbar, sbara);
pdfposta = normpdf(bvec, bdba, sdba);

fig2 = figure(2);
set(fig2, 'Color', 'white')
p1 = plot(bvec, pdfpria, bvec, pdfposta);
set(p1, 'LineStyle', '-', 'LineWidth' , 2)
title('Prior and posterior densities for \beta when \sigma is known with decreased variance')
legend('Prior','Posterior')
xlabel('\beta')

fprintf('In Section 4.2.2 inference using a noninformative prior is introduced. \n')
fprintf('With a noninformative prior for beta, the posterior p.d.f. is normal with \n')
fprintf('a mean equal to the sample mean (b computed above), and variance equal to \n')
fprintf('the population variance (sigma2) divided by the sample size (T). See \n')
fprintf('Equation 4.2.18. \n')

fprintf('Compute values of the posterior p.d.f for bvec, and plot them with the \n')
fprintf('prior and posterior distributions in the presence of an informative \n')
fprintf('prior. (See Figure 4.2). \n')

pdfnon = normpdf (bvec, b, sqrt(sigma2/t));

fig3 = figure(3);
set(fig3, 'Color', 'white')
p1 = plot(bvec, pdfnon, bvec, pdfprior, bvec, pdfpost);
set(p1, 'LineStyle', '-', 'LineWidth' , 2)
title('Prior and posterior densities for \beta when \sigma is known')
legend('noninformative', 'prior', 'posterior')
xlabel('\beta')

fprintf('Interval estimates (Section 4.2.2) can be used as a summary of the \n')
fprintf('posterior distribution. Using the example above, compute the highest \n')
fprintf('posterior density interval with a probabilty content of 0.95 (See \n')
fprintf('Equation 4.4.25 in the text). \n')

fprintf('posterior interval (lower): %2.2f \n', -1.96*sigdb + bdb);
fprintf('posterior interval (upper): %2.2f \n', 1.96*sigdb + bdb);

fprintf('Hypothesis testing (Section 4.2.4) within the Bayesian framework is \n')
fprintf('carried out using a posterior odds ratio. Consider the hypothesis in \n')
fprintf('Equation 4.2.27. First use sampling theory to test the hypothesis that \n')
fprintf('average weekly earnings from the chicken outlet are greater than $5000. \n')
fprintf('The standard normal test statistic is (4.2.28). Calculate it and the \n')
fprintf('"p-value" or area in the tail of the standard normal beyond the value of \n')
fprintf('the test statistic. \n')

z = (b - 5)/(2/sqrt(t));
fprintf('z: %2.2f \n', z);
fprintf('normcdf (upper): %2.2f \n', normcdf(z, 'upper'));

fprintf('Now compute the posterior odds that weekly earnings are less than $5000. \n')
fprintf('Your answer will be slightly different from (4.2.29) because of rounding \n')
fprintf('error in the text. \n')

p1 = normcdf((bdb - 5)/sigdb, 'upper'); %errata
fprintf('p1: %2.2f \n', p1);
k10 = (1 - p1)/p1;
fprintf('k01: %2.2f \n', k10);


fprintf('Compute the posterior odds, this time assuming a noninformative prior. \n')

p1 = normcdf(z, 'upper');
fprintf('p1: %2.2f \n', p1);
k = (1 - p1)/p1;
fprintf('k: %2.2f \n', k);

fprintf('Prediction (Section 4.2.5) in the Bayesian framework is based on a \n')
fprintf('predictive p.d.f. Compute the mean (mny) and variance (sigy) for \n')
fprintf('predicted weekly receipts using the (errata) posterior distribution \n')
fprintf('derived from the infomative prior. Recall that bdb is the mean of the \n')
fprintf('posterior, sigb2 is the variance, and the variance of weekly receipts is \n')
fprintf('equal to 4. \n')

mny = bdb;
sigy = sigdb2 +4;

fprintf('Compute the probability that sales willbe greater than 5 next week. \n')
fprintf('Sales will be greater than 5 next week: %2.2f \n', normcdf((5 - mny)/sqrt(sigy), 'upper'));

fprintf('Compute the probability that sales willbe gerater than 8 next week. \n')
fprintf('Sales will be greater than 8 next week: %2.2f \n', normcdf((8 - mny)/sqrt(sigy), 'upper'));

fprintf('4.3 Point Estimation \n')

fprintf('This section introduces Bayesian approaches to point estimation. \n')
fprintf('Estimator choice in a Bayesian world is made within a decision theoretic \n')
fprintf('context. Which estimator one uses depends on the loss function adopted. \n')

fprintf('To illustrate, four estimators of the mean of a normal population are \n')
fprintf('considered. (errata) Compute the mean square errors for the four \n')
fprintf('alternative estimators (See Section 4.4.3 in the text). The first \n')
fprintf('estimator is prior mean of the natural conjugate prior, bbar. The secon, \n')
fprintf('b, is the sample mean. The third, bdb, is the posterior mean derived from \n')
fprintf('a natural conjugate prior. Last is an artifical estimator set equal to b \n')
fprintf('+1. (NOte that this last estimator is different from that used in the \n')
fprintf('text.) Write function to compute the mean square errors of each of these \n')
fprintf('estimators. In the second function, mse2, a vector of zeros with the \n')
fprintf('length of beta is added to the scalar sigma2/T so that the function will \n')
fprintf('return a vector of values the same length as beta. This device is also \n')
fprintf('used in the fourth function, mse4. \n')

fprintf('Now graph the mean square errors of the alternative estimators for a range \n')
fprintf('of betas, beginning with 6 and incrementing by 0.04; \n')

beta = seqa(6, 0.04, 101);
mse = [fMse1(beta, bbar) fMse2(beta, sigma2) fMse3(beta, bbar, sigma2, sigbar) fMse4(beta, sigma2)];

vMSE1 = mse(:,1);
vMSE2 = mse(:,2);
vMSE3 = mse(:,3);
vMSE4 = mse(:,4);

% fig4 = figure(4);
% set(fig4, 'Color', 'white')
% [hAx,hLine1,hLine2] = plotyy([beta, beta], [vMSE1, vMSE4], [beta', beta'], [vMSE2', vMSE3']);
% set(hLine1, 'LineStyle', '-', 'LineWidth' , 2)
% set(hLine2, 'LineStyle', '-', 'LineWidth' , 2)
% legend([hLine1; hLine2], 'MSE1','MSE2','MSE4', 'MSE3');
% title('MSE')
% xlabel('\beta')

fig4 = figure(4);
set(fig4, 'Color', 'white')
[AX,H1,H2] = plotyy(beta, [vMSE1 vMSE4], beta, [vMSE2,vMSE3],'plot','plot');
legend([H1;H2],'MSE1','MSE4','MSE2','MSE3', 'Location', 'SouthEast');
set(H1, 'LineStyle', '-', 'LineWidth' , 3)
set(H2, 'LineStyle', '-', 'LineWidth' , 3)
title('MSE')
xlabel('\beta')

fprintf('4.4 Bayesian Inference fo the Mean and Standard Deviation of a Normal \n')
fprintf('Distribution \n')

fprintf('In this Section the assumption that the variance is known is dropped. \n')
fprintf('First consider an informative prior for the mean and standard deviation \n')
fprintf('of a normal distribution. \n')

fprintf('Write a function to compute the probability density function of an \n')
fprintf('inverted gamma distribution. See Equations 4.4.7 and 4.4.9 in the text. \n')

fprintf('The function to compute the probabilty density function of the normal \n')
fprintf('distribution should still be in memory (from Section 4.2.1). If not, type \n')
fprintf('it in now. \n')

fprintf('Using the LFC example from above, the subjective prior probability \n')
fprintf('density function for average weekly receipts has mean (bbar) of 8 and \n')
fprintf('variance (sigbar2) of 2.3427. We now use this information, conditioned on \n')
fprintf('sigma2 equal to 4, to compute the parameters of the joint prior \n')
fprintf('distribution. See Equation 4.4.11 in the text. \n')

bbar = 8;
sigbar2 = 2.3427;
sigma2 = 4;
tau = sigma2/sigbar2;
fprintf('tau: %2.2f \n', tau);

fprintf('Suppose that we believe that there is a 1 in 20 chance (0.05 probability) \n')
fprintf('that weekly receipts are in the range of plus or minus 2.55 from the \n')
fprintf('mean. Using the Chi-square distribution, we can compute the implied \n')
fprintf('parameters, v and s of the gamma distribution. First create a sequence of \n')
fprintf('vs and ssqs in the relevant range. Then create the matrix r which \n')
fprintf('contains all of the possible products of these two vectors. \n')

v = seqa(1, 1, 10);
ssq = seqa(1, 0.01, 100);
r = v*ssq';

fprintf('Next we want to solve the two nonlinear simultaneous equations: \n')
fprintf('cdfchic(r/0.7225, v) = 0.05 and cdfchic(r/16, v) = 0.95. To do so, create \n')
fprintf('matrix q. The further cdfchic(r/0.7225, v) is from 0.05 and the further  \n')
fprintf('cdfchic(r/16, v) is from 0.95 the higher the value of the element of q \n')
fprintf('corresponding to that r and that v. An element of q is equal to 0 (its \n')
fprintf('minimum value) if and only if the two equations hold. Thus to solve these \n')
fprintf('two equations simultaneously, we can find the values of ssq (sbar2) and v \n')
fprintf('(vbar) that correspond to the minimum value of q. Use the fMinindc \n')
fprintf('function to find these values. \n')

q = abs(chi2cdf(r/0.7225, kron(ones(1,cols(r)), v), 'upper') - 0.05)...
  + abs(chi2cdf(r/16,     kron(ones(1,cols(r)), v), 'upper') - 0.95);
i = fMinindc(min(q, [], 1));
j = fMinindc(min(q, [], 2));
vbar = v(j, 1);
sbar2 = ssq(i,1);
fprintf('vbar: %2.2f \n', vbar);
fprintf('sbar2: %2.2f \n', sbar2);

fprintf('Given the computed parameters, vbar and sbar2, graph the marginal prior \n')
fprintf('probability density function for a range of sigmas using the function for \n')
fprintf('the inverted gamma distribution. \n')

sigma = seqa(0.2, 0.1, 50);
priors =fIgamma(sigma, vbar, sqrt(sbar2));

fig5 = figure(5);
set(fig5, 'Color', 'white')
p1 = plot(sigma, priors);
set(p1, 'LineStyle', '-', 'LineWidth' , 2)
title('Marginal prior probability density function')
legend('prior');
xlabel('\sigma')

fprintf('The graph of the marginal prior will be delayed until after a discussion \n')
fprintf('of posterior distribution \n')

fprintf('In Section 4.4.2 the joint posterior density from an informative prior is \n')
fprintf('determined to be of the normal-gamma type. See Equations 4.4.23-4-4.4.25. \n')
fprintf('The parameters for joint posterior distribution are given in Equations \n')
fprintf('4.4.19 and 4.4.22. If the vector y entered at the beginning of this \n')
fprintf('chapter is not still in memomry then re-enter it now. Compare your \n')
fprintf('results to those on p.146 of ITPE2. \n')

t = rows(y);
bhat =mean(y);
fprintf('bhat: %2.2f \n', bhat);

bdb = (bbar*tau + bhat*t)/(tau +t); % Equation 4.4.19
fprintf('bdb: %2.2f \n', bdb);

vdb = vbar +t;
vsdb = vbar*sbar2 + y'*y - (tau +t)*bdb*bdb+tau*bbar*bbar; % Equation 4.4.22
fprintf('vsdb: %2.2f \n', vsdb);

sdb2 = vsdb/vdb;
fprintf('sdb2: %2.2f \n', sdb2);

fprintf('The marginal posterior densities for the mean and standard deviation are \n')
fprintf('derived in Section 4.4.3. \n')

fprintf('Using Equations 4.4.25 the marginal posterior for sigma is an \n')
fprintf('inverted-gamma p.d.f. with parameters vdb and sdb2. Compute the values of \n')
fprintf('this distribution for the range of sigmas specified above. Graph these \n')
fprintf('values (posts) agains sigma and compare them with the marginal prior \n')
fprintf('distribution. Compare your graph to Figure 4.5. \n')

posts = fIgamma(sigma, vdb, sqrt(sdb2));

fig6 = figure(6);
set(fig6, 'Color', 'white')
p1 = plot(sigma, priors, sigma, posts);
set(p1, 'LineStyle', '-', 'LineWidth' , 2)
t1 = title('Figure 4.5 Prior and posterior inverted-gamma distributions for $\sigma$.');
set(t1, 'Interpreter', 'latex', 'FontSize', 11 );
l1 = legend('$g(\sigma)$', '$g(\sigma|y)$');
set(l1, 'Interpreter', 'latex', 'FontSize', 11 );
xlabel('\sigma')

fprintf('Write function to compute the first two moments and the mode of the gamma \n')
fprintf('distribution. See Equation 4.4.8 in the text. \n')

fprintf('Now write a function to compute the standard deviation, using the first \n')
fprintf('two moments. \n')

fprintf('Use these functions to compute the mean, mode, and standard deviation of \n')
fprintf('the prior and posterior marginal distribution for sigma. Check your \n')
fprintf('results with Table 4.1 in the text. \n')

disp('----------Prior---------Posterior')
disp([fMlig(vbar, sqrt(sbar2)) fMlig(vdb, sqrt(sdb2))])
disp([fModeig(vbar, sqrt(sbar2)) fModeig(vdb, sqrt(sdb2))])
disp([fStdig(vbar, sqrt(sbar2)) fStdig(vdb, sqrt(sdb2))])

fprintf('The conditional density of beta, given sigma, is normal with mean bdb = \n')
fprintf('6.238 and variance sigma2/(T + tau) = sigma2/11.7074. As shown in \n')
fprintf('Equation 4.4.27 the marginal distribution of beta is a weighted average \n')
fprintf('of conditional density values weighted by the marginal posterior density \n')
fprintf('of sigma. We will use this relationship to graph the conditional density \n')
fprintf('for beta. First create a matrix of the values of the conditional normal \n')
fprintf('density. Each row has fixed sigma and each column a fixed beta. \n')

fprintf('To prevent unusually large of small values being passed to PDFN we will \n')
fprintf('set values of the standardized variable grater than 10 in absolute value \n')
fprintf('equal to 10. This will have no effect on the final as the ordingate of a \n')
fprintf('N(0,1) p.d.f. 10 standard deviations from the mean is essentially zero. \n')

iCols = length(bvec);
iRows = length(sigma);
mBdb = repmat(bdb, iRows, iCols);
mBVec = repmat(bvec',iRows,1);
vStd = sqrt(sigma.*sigma/(tau + t));
mStd = repmat(vStd, 1, iCols);

z = (mBdb - mBVec)./mStd;
zok = abs(z) <= 10;
z = (zok.*z) + 10*(1-zok);
n1 =normpdf(z)./mStd;

fprintf('Now weight all the elemens in each row by the posterior density values \n')
fprintf('for sigma. \n')
n2 = n1.*repmat(posts, 1, iCols);

fprintf('Sum the columns of the resulting matrix to yield values of the posterior \n')
fprintf('density for the range of beta values and graph the posterior density. \n')

postb = sum(n2,1);

fig7 = figure(7);
set(fig7, 'Color', 'white')
p1 = plot(bvec, postb);
set(p1, 'LineStyle', '-', 'LineWidth' , 2)
t1 = title('Posterior density for $\beta$.');
set(t1, 'Interpreter', 'latex', 'FontSize', 11 );
l1 = legend('$g(\beta|y)$');
set(l1, 'Interpreter', 'latex', 'FontSize', 11 );
xlabel('\beta')

fprintf('To determine the marginal prior probability density function for beta we \n')
fprintf('use the same procedure with the conditional normal prior for beta and the \n')
fprintf('inverted gamma prior for sigma. Compute the marginal prior density \n')
fprintf('forbeta ad graph it with the marginal posterior density for beta. \n')
fprintf('Compare to Figure 4.4. in the text \n')

bvec = seqa(3, 0.1, 101);

vStd = sqrt(sigma.*sigma/tau);
mStd = repmat(vStd, 1, iCols);
mBbar = repmat(bbar, iRows, iCols);

priorb = sum(normpdf(mBVec, mBbar, mStd).*repmat(priors, 1, iCols));

fig8 = figure(8);
set(fig8, 'Color', 'white')
p1 = plot(bvec, priorb, bvec, postb);
set(p1, 'LineStyle', '-', 'LineWidth' , 2)
t1 = title('Prior and Posterior distributions for $\beta$.');
set(t1, 'Interpreter', 'latex', 'FontSize', 11 );
l1 = legend('$g(\beta)$', '$g(\beta|y)$');
set(l1, 'Interpreter', 'latex', 'FontSize', 11 );
xlabel('\beta')

fprintf('Now repeat the graph, this time using the analytic result that the \n')
fprintf('marginal posterior p.d.f. for beta is a t-distribution with mean bdb, \n')
fprintf('precision (tat + T)/sdb2, and degrees of freedom vdb. The first step is \n')
fprintf('to write a function for the t-probability density given by Equation \n')
fprintf('4.4.31 and 4.4.32, where u is the man, h is the precision, and v is the \n')
fprintf('degrees of freedom. \n')

fprintf('The marginal prior for beta is also a t-distribution with mean bbar, \n')
fprintf('precision tau/sbar2 and degrees of freedom vbar. Now compute the values \n')
fprintf('and graph. \n')

postbt = fPdft2(bdb,(tau + t)/sdb2, vdb, bvec);
priorbt = fPdft2(bbar, (tau/sbar2), vbar, bvec);

fig9 = figure(9);
set(fig9, 'Color', 'white')
p1 = plot(beta, postbt, beta, priorbt);
set(p1, 'LineStyle', '-', 'LineWidth' , 2)
t1 = title('Prior and Posterior t distributions for $\beta$.');
set(t1, 'Interpreter', 'latex', 'FontSize', 11 );
l1 = legend('$g(\beta)$', '$g(\beta|y)$');
set(l1, 'Interpreter', 'latex', 'FontSize', 11 );
xlabel('\beta')

