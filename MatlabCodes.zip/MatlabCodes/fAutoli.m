% /***************************************************************/
% /* */
% /* PROC AUTOLI -- Log-likelihood with AR(1) errors */
% /***************************************************************/
function out = fAutoli(param0)

global x y

% local l1,k,T,b,rho,e,elag,estar,zz,phi,sigmasq;
% /* Take apart the parameter vector */
k = rows(param0);
t = rows(y);
b = param0(1:k-2,1);
rho = param0(k-1,1);
sigmasq = param0(k,1);
% /* Compute the transformed error term */
e = y - x*b;
elag = [0; e(1:t-1,1)];
estar = e - (rho*elag);
estar(1,1) = sqrt(1 - (rho^2))*e(1,1);
% /* Compute the components of the likelihood function */
phi = 1/(1 - (rho^2));
l1 = log(2*pi*sigmasq) + log(phi)/t;
out = ( - l1 - ((estar.*estar)/sigmasq) );


return