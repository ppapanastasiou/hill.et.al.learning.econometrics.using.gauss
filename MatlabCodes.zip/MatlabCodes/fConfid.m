function mOut=fConfid(b, varcov, fstat, pos)

[iRows, iCols] =size(b);
if iRows ~=1 && iCols ~=1;
    error('b is not a vector')
end

[iRows, iCols] =size(varcov);
if iRows ==1 || iCols ==1;
    error('varcov is not a matrix')
end

[iRows, iCols] =size(fstat);
if iRows ~=1 || iCols ~=1;
    error('fstat is not a scalar')
end

[iRows, iCols] =size(pos);
if iRows ~=1 && iCols ~=1;
    error('pos is not a vector')
end

if size(b,1)==1
    b = b';
    fprintf(' transpose b so it is a column vector \n')
end

if size(pos,1)==1
    pos = pos';
    fprintf(' transpose pos so it is a column vector \n')
end

if rows(varcov) ~= cols(varcov)
    error('the varcov matrix should be symmetric')
end

if rows(b) ~= rows(varcov)
    error('the rows of b should be equal the rows (and columns) of the varcov maxtrix')
end


b1 = b(pos(1,1),1);
b2 = b(pos(2,1),1);
r = zeros(2,rows(b));
r(1,pos(1,1))=1;
r(2, pos(2,1))=1;

a = inv(r*varcov*r');

q = a(1,1)*a(2,2)-a(1,2)*a(1,2);
lb = b2 - sqrt(2*fstat*a(1,1)/q);
ub = b2 + sqrt(2*fstat*a(1,1)/q);
beta2 = seqa(lb,(ub-lb)/100,101);

csq =(b2-beta2).^2*(-q/a(1,1).^2)...
    + fstat*2/a(1,1);

c = sqrt(abs(csq));

beta1a = b1+(b2-beta2)*a(1,2)/a(1,1)+c;
beta1b = b1+(b2-beta2)*a(1,2)/a(1,1)-c;


mOut = [[beta2;rev(beta2)] [beta1a;rev(beta1b)]];

return
