% /* PROC BCT -- Computing the Box-Cox Transformation */
function zbc= fBct(z,lambda)

lambda = lambda';

% local z1,z2,idx,zbc;
idx = lambda == 0;
if length(lambda)==1
    %then it is a scalar do nothing
else
    lambda = repmat(lambda, rows(z),1);
end
z1 = ((z.^lambda) - 1)./lambda;
z2 = log(abs(z));

if length(idx)==1
    %then it is a scalar do nothing
else
    idx = repmat(idx, rows(z2),1);
end

zbc = (z2 .* idx) + (z1 .* (1-idx));
% retp(zbc);
% endp;

return