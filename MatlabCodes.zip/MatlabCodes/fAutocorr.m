function [rk, rkbar] = fAutocorr(y,kmax)
% local t,ybar,yd,c0,rk,rkbar,k,yt,ytk,ck,ckbar;
t = rows(y);
ybar = meanc(y); % /* center data */
yd = y-ybar;
c0 = yd'*yd/t; % /* estimate variance - c0 */
rk = zeros(kmax,1); % /* define storage matrices */
rkbar = zeros(kmax,1);
k = 1; % /* begin loop */
while k <= kmax;
    yt = yd(1:t-k,1); % /* y in period t */
    ytk = yd(1+k:t,1); % /* y in period t+k */
    ck = yt'*ytk/t; % /* Eq. 16.4.10 */
    ckbar = yt'*ytk/(t-k); % /* Eq. 16.4.12 */
    rk(k,1) = ck/c0; % /* Eq. 16.4.9 */
    rkbar(k,1) = ckbar/c0; % /* Eq. 16.4.11 */
    k = k+1;
end
% retp(rk,rkbar);
% endp;

return