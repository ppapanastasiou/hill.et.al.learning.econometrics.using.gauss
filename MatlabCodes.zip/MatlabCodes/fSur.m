function [bg, xx, xty, std1]=fSur(x,y,shat)
k = cols(x)/cols(y);
ishat = invpd(shat);
xx = (x'*x) .* (kron(ishat,ones(k,k)));
xty = (x'*y) .* (kron(ishat,ones(k,1)));
bg = xx\sumc(xty');
std1 = sqrt(diag(invpd(xx))); % use std1 instead of std since it colludes with the std function of matlab

% iphi=kron(ishat,ones(k,k));
% iphi1=kron(ishat,ones(k,1));

return