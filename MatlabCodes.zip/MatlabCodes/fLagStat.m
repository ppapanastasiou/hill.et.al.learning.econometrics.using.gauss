function [sse, sig2, aic, sic] = fLagStat(y,x)
%local t,k,n,b,sse,sig2,aic,sic;
t = rows(x);
k = cols(x);
n = k-2; % /* n is the lag length */
b = x\y;
sse = (y - x*b)'*(y - x*b);
sig2 = sse/(t-k); % /* Eq. 17.2.5 */
aic = log(sse/t) + 2*n/t; % /* Eq. 17.2.11 */
sic = log(sse/t) + n*log(t)/t; % /* Eq. 17.2.12 */
% retp(sse~sig2~aic~sic);
% endp;

return