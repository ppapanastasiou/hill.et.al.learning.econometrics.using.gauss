% ***************************************************************/
% * PROC NLSG --- Non-linear Least Squares */
% * using analytic derivatives */
% ***************************************************************/
function [b0, z] = fFNLSG(b0, FI, GRAD, x, y, iPrint)

if nargin <6 || isempty(iPrint)
    iPrint =1;
end

%local FI:proc, GRAD:proc;
%local *;
crit = 1; %/* Initialize values */
iter = 1;
k = rows(b0);
s = 0;
while (iter <= 25) && (all(crit > 1e-8)); % /* Begin loop */
    % z = GRAD(b0); /* Evaluate derivatives */
    z = GRAD(b0); % /* Evaluate derivatives */
    % u = y - FI(b0); /* Compute residuals */
    u = y - FI(b0); % /* Compute residuals */
    sse = u'*u; % /* Compute sum of sqrd res.*/
    % crit = solpd(z�u,z�z); /* Compute full step adjust*/
    crit = z'*z\z'*u; % /* Compute full step adjust*/
    % gosub step; %/* Compute step length */
    % step: /* Subroutine for step length */
    s = 2;
    ss1 = 2; 
    ss2 = 1;
    while ss1 >= ss2;
        s = s/2;
        % u1 = y - FI(b0 + s*crit);
        u1 = y - FI(b0 + s*crit);
        % u2 = y - FI(b0 + s*crit/2);
        u2 = y - FI(b0 + s*crit/2);
        ss1 = u1'*u1;
        ss2 = u2'*u2;
    end
    % return;  
    b = b0 + s*crit; % /* Update parameters */
    % gosub prnt; % /* Print iteration results */
    iter = iter + 1; % /* Update for iteration */
    crit = abs(b - b0); % /* check convergence */
    b0 = b; % /* store new value of est. */
end % /* end loop */

% /* Compute covariance matrix */
sighat2 = sse/(rows(y) - k);
covb = sighat2*invpd(z'*z);

% /* Print out final results */
% ?;
% "Final Results: ";
% ?;
% "Coefficients : " b0�;
% "Std. Errors : " sqrt(diag(covb))�;
% "Sighat2 : " sighat2;
% retp(b0,z);

if iPrint ==1
    %print out
    disp('Final Results:')
    disp('Coefficients:')
    disp(b0)
    disp('Std. Errors:')
    disp(sqrt(diag(covb)))    
    disp('Sighat2:')
    disp(sighat2)
end

% prnt: /* Subroutine for printing */
% format 4,2; " i = " iter;;
% format 4,2; " Steplength = " s;;
% format 10,6; " SSE = " sse;
% " b = " b0�;?;
% return;
% endp;

return