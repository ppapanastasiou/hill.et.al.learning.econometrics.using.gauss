close all;clear;clc
format bank; % two decimal points
% format compact; 


fprintf('Chapter 22 \n')
fprintf('Robust Estimation \n')

fprintf('In this chapter estimation procedures are considered which are �robust� to \n')
fprintf('changes in the data generation process. In particular stress is placed on robustness \n')
fprintf('to nonnormal errors. A variety of regression diagnostics are introduced and \n')
fprintf('illustrated. \n')

fprintf('22.1 The Consequences of Nonnormal Disturbances \n')
fprintf('In this section the properties of estimators under assumptions of finite and \n')
fprintf('infinite error variances are summarized. \n')

fprintf('22.2 Regression Diagnostics \n')
fprintf('This section introduces the algebraic forms of a list of regression diagnostics. \n')
fprintf('These will be illustrated in Section 22.4 \n')

fprintf('22.3 Estimation Under Multivariate-t Errors \n')
fprintf('Multivariate-t errors are given as an example of nonnormal errors. The difference \n')
fprintf('between independent and uncorrelated errors is noted and maximum \n')
fprintf('likelihood estimation for the independent error case is described. This estimator \n')
fprintf('is illustrated in the following Section. \n')

fprintf('22.4 Estimation Using Regression Quantiles \n')
fprintf('To introduce the concept of a regression quantile the simple model of the mean \n')
fprintf('is used, Equation 22.4.1. Construct a vector y containing the data at the bottom \n')
fprintf('of page 900 of ITPE2. \n')

y = [2 3 5 8 9 9 11 12 15]';

fprintf('Obtain an estimate of the 0.25 quantile as shown on the top of page 901. \n')
t = rows(y);
theta = .25;
n = fix(theta*t) + 1;
display(n)
est = y(n,1);
display(est)

fprintf('To illustrate that the 0.25 quantile can also be defined as a solution to the \n')
fprintf('minimization problem in Equation 22.4.3, calculate the objective function as \n')
fprintf('the sum of two components as in Table 22.1 for various values of beta. For each \n')
fprintf('value of beta the values of y that are greater than or equal to it are defined and the \n')
fprintf('component of the objective function calculated. The results are accumulated in \n')
fprintf('the matrix store. The objective function is minimized for beta = 5. \n')

store = zeros(9,4);
beta = 2;
while beta <= 10;
    select = y >= beta;
    term1 = sumc(select .* (theta.* abs(y - beta)));
    term2 = sumc( (1-select) .* ( (1-theta) .* abs(y - beta)));
    fnval = term1 + term2;
    store(beta-1,:) = [beta term1 term2 fnval];
    beta = beta + 1;
end
display('Table 22.1')
disp(store)

fprintf('To illustrate the use of regression diagnostics and robust estimation data based \n')
fprintf('on independent t-errors, with 1 degree of freedom, is used. First, let us see what \n')
fprintf('this p.d.f. looks like. The equation for the p.d.f. is given in Equations 22.5.2 \n')
fprintf('and 22.5.3. Write a proc to compute the p.d.f. values given the values of v and sigma \n')

fprintf('Set the values of v and sigma, calculate the p.d.f. values of the t distribution and \n')
fprintf('plot them \n')

nu = 1;
sig = 2;
e = seqa(-8,.02,801);
t = fPdft3(e,nu,sig);
% library qgraph;
% xy(e,t);

fig = figure(1);
set(fig, 'Color', 'white')
plot(e, t, 'Color', 'black', 'LineWidth' , 3)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
% titel='Plot of the data in Table 16.1';
% legend('RSS')
% title(titel,'FontSize',10);
% ylabel( '$y_t$', 'FontSize', 14, 'Interpreter', 'latex');
% xlabel( 't', 'FontSize', 12);

fprintf('Note that the t-distribution with 1 degree of freedom is very flat and has thick \n')
fprintf('tails. Thus the probability of getting large absolute errors is greater than with \n')
fprintf('normal errors. \n')

fprintf('Table 22.2 in the text gives values of the dependent variable y generated from \n')
fprintf('the model in Equation 22.5.1 with true parameter values beta1 = 0, beta2 = 1 and \n')
fprintf('beta3 = 1, the given x values and independent t-errors. To construct the t-errors \n')
fprintf('use equation 22.5.4 with z1 the first 40 observations from file NRANDOM.DAT \n')
fprintf('and z2 the second group of 40 observations. Construct the errors and compare \n')
fprintf('them to the last column of Table 22.2 in the text. \n')
% open f1 = nrandom.dat;
% e = readr(f1,80);
% f1 = close(f1);
fprintf('Define e as a global variable \n')
global e


load nrandom200
e = nrandom200(1:80);

z1 = e(1:40,:);
z2 = e(41:80,:);
e = (sig .* z1) ./ sqrt(z2.^2);
display(e)

fprintf('Now LOAD the data in file TABLE22.2 on the data disk, construct X and y \n')
fprintf('and examine. \n')
% load dat[40,4] = table22.2;
load mDataTable22_2
dat = mDataTable22_2;
t = 40;
x = [ones(t,1) dat(:,[2 3])];
beta = [0 1 1]';
y = x*beta + e;
display(y)
display(x)

fprintf('Use PROC MYOLS which was written in Chapter 6 to obtain least squares estimates \n')
fprintf('of the parameters. Calculate estimated standard errors in the usual way, \n')
fprintf('though we know that with t(1) errors the OLS estimator has neither mean nor \n')
fprintf('variance. See Table 22.4. \n')
[b, covb] = fMyOls(x,y);
display(b)
display(covb)

fprintf('The first regression diagnostic considered is teh Bera-Jarque test for normally \n')
fprintf('distributed errors. The test statistic is given in Equation 22.2.7 and is based \n')
fprintf('on the moment estimators described in Equation 22.2.6. Write a proc that will \n')
fprintf('compute the test statistic and p-value given X and y. \n')

fprintf('Use PROC BERAJAR to test the normality of the regression errors. \n')
fBerajar(x,y);

fprintf('As noted, the hypothesis that the errors are normal is rejected at usual significance \n')
fprintf('levels. \n')
fprintf('The other regression diagnostics illustrated are the leverage of an observation, \n')
fprintf('studentized residuals, DFBETAS and DFFITS. Write a proc to calculate these \n')
fprintf('values and print out a table, like Table 22.3 in the text, in which observations \n')
fprintf('selected using the rule of thumb cutoffs (Section 22.2.2 and page 908) are displayed. \n')
fprintf('This proc is long so place it in a convenient file and run it to store it \n')
fprintf('into memory. \n')

fprintf('Use PROC DIAGNOSE to print out a table like Table 22.3 in the text. It will not \n')
fprintf('be identical due to the fact that the table in the text identifies other observations \n')
fprintf('as well. \n')
table223 = fDiagnose(x,y);

fprintf('Given that nonnormal errors have been identified the use of robust estimators \n')
fprintf('may be called for. Regression quantiles and trimmed least squares use linear \n')
fprintf('programming techniques which will not be covered here. Instead we will use the \n')
fprintf('maximum likelihood estimation technique, under the assumption of independent \n')
fprintf('t-errors as described in Section 22.3. The maximum likelihood estimates satisfy \n')
fprintf('the four equations 22.3.9 to 22.3.12. To obtain estimates that satisfy those \n')
fprintf('constraints we will iterate using the OLS estimates as starting values. \n')
bmle = b;
crit = 1;
nu = 1;
iter = 1;
while (crit > 1.e-6) && (iter < 25);
    emle = y - x*bmle;
    sig2mle = emle'*emle/t;
    nusig2 = (nu + 1) * sig2mle; % /* Eq. 22.3.12 */
    wt = 1 ./ ( 1 + (emle.^2)./nusig2 ); % /* Eq. 22.3.11 */
    wx = repmat(wt, 1, cols(x)) .* x; % /* Weight obs */
    wy = wt .* y;
    newb = pinv(x'*wx)*x'*wy; % /* Eq. 22.3.9 */
    crit = maxc(abs(bmle-newb));
    bmle = newb;
    iter = iter + 1;
    display('          iter         crit          bmle')
    disp([iter crit bmle'])
end

fprintf('Calculate the asymptotic covariance matrix as given in Equation 22.3.13 and \n')
fprintf('print the results. \n')
covml = ((nu + 3)*nusig2 / (nu+1)) * invpd(x'*x);
se = sqrt(diag(covml));
display('bmle') 
disp(bmle')
display('se') 
disp(se')