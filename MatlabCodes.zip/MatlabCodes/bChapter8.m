close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 8 \n')
fprintf('General Linear Statistical \n')
fprintf('Model \n')
fprintf('In this chapter the classical linear regression model is generalized by considering \n')
fprintf('situations where the error covariance matrix is not equal to a scalar times an \n')
fprintf('identity matrix, i.e., Cov(e) 6 =/ sigma^2 It \n')
fprintf('8.1 The Statistical Model and Estimators \n')
fprintf('In this chapter you will create a data set in which the error terms are first- order \n')
fprintf('autoregressive. The parameters are then estimated using ordinary least squares \n')
fprintf('and generalized least squares. A Monte Carlo study allows you to carefully \n')
fprintf('compare the characteristics of the two procedures and to see the pitfalls in \n')
fprintf('using ordinary least squares inappropriately. \n')
fprintf('The Monte Carlo experiment will be set up as in Section 8.1.5 in ITPE2. The \n')
fprintf('design matrix X and the true parameter vector are as in Chapter 6. \n')
t = 20;
k = 3;
% load x[t,k] = judge.x;
load mDataJudge
x = mDataJudge;
beta = [10.0 0.4 0.6]'; % Matlab define vectors as row vectors Gauss as column vectors hence we need to transpose to get a column vector
fprintf('Set the parameter  = 0.9 and sigma^2 = .0625. \n')
rho = 0.9;
sigma2 = .0625;

fprintf('Create the underlying covariance matrix for the error terms, following Equation \n')
fprintf('8.8.21 in the text. While there are no doubt more clever ways to proceed, \n')
fprintf('define Psi to be a (T x T) identity matrix and then simply fill in the off-diagonal \n')
fprintf('elements with powers of rho, using nested DO-LOOPS, and taking advantage of \n')
fprintf('the symmetry of Psi. \n')

psi = eye(t); % /* (T x T) identity */
i = 1; % /* begin "row" loop */
while i <=t
    j = i + 1; % /* begin "col" loop */
    while j <= t;
        psi(i,j) = rho^(j - i); % /* i,j-th element */
        psi(j,i) = psi(i,j); % /* j,i-th element */
        j = j+1;
    end; % /* end column loop */
    i = i+1;
end;
psi = psi ./ (1 - rho^2); % /* See Eq. 8.1.21 */

fprintf('With X given and knowledge of 	 and 2 you can compute the true covariance \n')
fprintf('matrices of both the ordinary least squares and generalized least squares estimators \n')
fprintf('of the parameters. For the ordinary least squares covariance use Equation \n')
fprintf('8.1.24 in the text: \n')
ixx = invpd(x'*x);
covb = sigma2*ixx*x'*psi*x*ixx;
fprintf('Compare these estimates to Equation 8.1.24 in the text. \n')
display(covb)

fprintf('The covariance of the generalized least squares estimator is computed by Equation \n')
fprintf('8.1.23 in the text. \n')
ipsi = invpd(psi);
covbhat = sigma2*invpd(x'*ipsi*x);
fprintf('Compare these estimates to Equation 8.1.23 in the text. \n')
display(covbhat)

fprintf('Note that the variances (shown on the diagonals of the covariance matrices) \n')
fprintf('of the generalized least squares estimator are smaller than those of the OLS \n')
fprintf('estimator. \n')
fprintf('You can also compute the expected value of the usual estimator of the error \n')
fprintf('variance, given your special knowledge of the true sigma^2, as in Equation 8.1.25 of \n')
fprintf('ITPE2. \n')

tr1 = sumc(diag(psi));
tr2 = sumc(diag(x'*psi*x*ixx));
esighat2 = sigma2*(tr1 - tr2)/(t - k);
fprintf('Compare these estimates to Equation 8.1.25 in the text. \n')
display(esighat2)


fprintf('How does the expected value of the biased estimator of the variance compare \n')
fprintf('with the true value of sigma^2 = 0.0625? \n')
fprintf('The most complicated part of simulating the data generation process is creating \n')
fprintf('the error terms. Make use of the fact that the autocorrelated error, et = et?1 + \n')
fprintf('vt, can be created using a normally distributed error term, estar, with mean 0 \n')
fprintf('and variance 2. First create a vector estar using the first 20 �official� normal \n')
fprintf('random numbers, which have a N(0,1) distribution. \n')
% open f1 = nrandom.dat; /* open file */
load nrandom200
% estar = readr(f1,t); % /* read T obs. */
estar = nrandom200(1:t);
% f1 = close(f1); % /* close file */
estar = sqrt(sigma2)*estar; %/* change variance */
fprintf('Next use the transformation outlined below Equation 8.1.21 in the text, and \n')
fprintf('apply it to e. The first element in e is constructed using a special formula. \n')
fprintf('The remainder can be constructed iteratively using a first order autocorrelation \n')
fprintf('process. \n')
e = zeros(t,1); %/* initialize vector */
e(1,1) = estar(1,1)/sqrt( 1 - (rho^2)); % /* create element 1 */
i = 2; % /* begin loop */
while i <= t;
    e(i,1) = rho*e(i-1,1) + estar(i,1); % /* e(i) */
    i = i+1;
end; % /* end loop */
display(e); %/* print */

fprintf('Given e[1,1] the function RECSERAR, which creates an autoregressive recursive \n')
fprintf('series, could also be used. \n')
e = recserar(estar,e(1,1),rho);
display(e);

fprintf('Now create the vector y. \n')
y = x*beta + e;

fprintf('Compute least squares estimates, b and sigma�2. \n')
b = x\y;
display(b)
ehat = y - x*b;
sighat2 = ehat'*ehat/(t - k);
display(sighat2)

fprintf('Use the usual (and in this case, incorrect) formula to compute the covariance \n')
fprintf('matrix for b. Compare it to the true covariance, E[(b ? E(b))(b ? E(b))0]. \n')
badcovb = sighat2*ixx;

fprintf('Compute the covariance matrix for b. Compare it to the true covariance \n')
display(badcovb)
display(covb)

fprintf('Compute generalized least squares estimates, betahat and sigma�2_g \n')
ipsi = invpd(psi);
bhat = invpd(x'*ipsi*x)*(x'*ipsi*y);
eghat = y - x*bhat;
sighatg2 = eghat'*ipsi*eghat/(t - k);
display(sighatg2)

fprintf('As with LS estimation the GLS estimates could be obtained efficiently using \n')
fprintf('GAUSS division, � / �. \n')
bhat = (x'*ipsi*x)\(x'*ipsi*y);
display(bhat)

fprintf('In the Monte Carlo experiment below, it will be useful to know that an alternative \n')
fprintf('way to compute sigma�2_g is: \n')
sighatg2 = sumc( (ipsi*eghat) .* eghat)/(t - k);

fprintf('In the Monte Carlo experiment below, it will be useful to know that an alternative way to compute sigma�2_g is \n')
display(sighatg2)

fprintf('Now compute the covariance matrix for the generalized least squares coefficient \n')
fprintf('estimates, and compare with the true values in covbhat. \n')
ecovbhat = sighatg2*invpd(x'*ipsi*x);

fprintf('Now compute the covariance matrix for the generalized least squares coefficient estimates, and compare with the true values in covbhat.\n')
display(ecovbhat) 
display(covbhat)

fprintf('Compare your estimates to correspondents in the first row of Table 8.1 in ITPE2. \n')
fprintf('They should be the same. \n')

fprintf('In order to carry out a Monte Carlo study of generalized least squares first write \n')
fprintf('a procedure to simulate NSAM data sets at one time, compute the least squares \n')
fprintf('and generalized least squares estimates. The alternative is to use many DOLOOPS, \n')
fprintf('which would take considerably longer to execute. PROC MCG takes \n')
fprintf('as arguments x, beta, rho, and a (T x NSAM) matrix of N(0,2) random \n')
fprintf('disturbances. It returns all the estimates stacked into one matrix. It is long so \n')
fprintf('place it in a separate file, and then run it. \n')

fprintf('Use the procedure to compute estimates for 250 samples. Create the matrix \n')
fprintf('estar. \n')
% load estar = e1nor.fmt;
estar = randn(rows(x),250);
estar = sqrt(sigma2)*estar;
est = fMcg(x,beta,rho,estar);

fprintf('Print out to the screen the estimates of the first ten samples, where each row \n')
fprintf('represents the estimates for one sample. Compare these estimates to the values \n')
fprintf('in Table 8.1. \n')
fprintf('Compare these estimates to the values in Table 8.1. \n')
% format 6,4;
% est[.,1:10]�;
disp(est(1:10, [3 7 4 8]))

fprintf('Add another 250 samples and stack them next to the estimates from the first \n')
fprintf('250 samples. Then clear estar from memory. \n')
% load estar = e2nor.fmt;
estar = randn(rows(x),250);

estar = sqrt(sigma2)*estar;
est = [est; fMcg(x,beta,rho,estar)];
estar = 0;

fprintf('Calculate the mean values of the parameter estimates from the 500 samples and \n')
fprintf('compare them to the true values. \n')

fprintf('Calculate the mean values of the parameter estimates from the 500 samples and compare them to the true values. \n')
disp(mean(est(:, [3 7 4 8]),1));

fprintf('Compute the true variances of the estimated coefficients using covb and covbhat \n')
fprintf('computed above. Compare them with the sampling variances from the Monte \n')
fprintf('Carlo study. Note, the GAUSS function STDC uses divisor NSAM - 1, and \n')
fprintf('thus we deflate the estimated variances to make them strictly comparable to \n')
fprintf('the diagonal elements of Equation 8.1.26. \n')
fprintf('Compare results to the diagonal elements of Equation 8.1.26. \n')
var = [diag(covb); diag(covbhat)];
disp(var')
b = est(:, [1 2 3 5 6 7]);
disp((std(b).^2).*(499/500))

fprintf('Now compute the estimated standard errors using the ordinary least squares \n')
fprintf('formula. \n')
tmp1 = est(:,4);
tmp2 = diag(ixx)';
tmp1 = repmat(tmp1, 1, cols(tmp2));
tmp2 = repmat(tmp2, rows(tmp1), 1);
badse = sqrt( tmp1.* tmp2 );

fprintf('Do the same for the generalized least squares estimated coefficients. \n')
tmp1 = est(:,8);
tmp2 = diag(invpd(x'*ipsi*x))';
tmp1 = repmat(tmp1, 1, cols(tmp2));
tmp2 = repmat(tmp2, rows(tmp1), 1);
bhatse = sqrt( tmp1.* tmp2 );

fprintf('Compare mean estimated standard deviations to truth. \n')
fprintf('Compare mean estimated standard deviations to truth. \n')
display(sqrt(var)')
display(mean(badse,1))
display(mean(bhatse,1))

fprintf('8.2 The Normal Linear Statistical Model \n')
fprintf('In this Section it is shown that if the random vector of disturbances has a \n')
fprintf('multivariate normal distribution then the GLS estimator is the same as the \n')
fprintf('maximum likelihood estimator. The ML estimator of sigma^2 has the divisor T \n')
fprintf('rather than T - K. \n')

fprintf('8.3 Sampling distributions of the Maximum Likelihood \n')
fprintf('Estimators \n')
fprintf('If PSI is known, the ML estimator of has a normal distribution with the usual \n')
fprintf('mean and covariance. Likewise the unbiased estimator of sigma^2 has a multiple of \n')
fprintf('a chi-square distribution with (T - K) degrees of freedom. \n')

fprintf('8.4 Interval Estimators \n')
fprintf('Given the results in Sections 8.2 and 8.3 it is not surprising that all usual \n')
fprintf('estimation procdures may be applied, with substitution of the GLS estimators \n')
fprintf('and the appropriate covariance matrix. \n')

fprintf('8.5 Hypothesis Testing \n')
fprintf('Linear hypotheses may be tested in the usual way, again with substitutions of \n')
fprintf('proper estimators and covariance matrices. Continue the Monte Carlo experiment. \n')
fprintf('Perform t-tests at the 5 percent level of significance for each coefficient for each sample. \n')
fprintf('(See Section 8.5 of the text.) Remember that the computed t-statistic for the \n')
fprintf('ordinary least squares estimates do not in fact have a t-distribution. \n')
tmp1 = [beta' beta'];
tmp2 = [badse bhatse];
tmp1 = repmat(tmp1, rows(tmp2),1);

tstat = (est(:, [1 2 3 5 6 7]) - tmp1./tmp2);
mean( (abs(tstat) >= 2.11));
fprintf('How close are the percentages of times the hypotheses are rejected to the true \n')
fprintf('probability of 5 percent ? \n')
fprintf('Graph the distribution of the least squares estimate of beta_3. \n')
% library qgraph
% { c1,m1,freq1 } = histp(est[3,.]�,30);
fig1 = figure(1);
set(fig1, 'Color', 'white')
hist(est(:,3), 30)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Distribution of the least squares estimate of $\beta_3$';
title(titel,'FontSize',10,'Interpreter', 'latex');

fprintf('Graph the distribution of the generalized least squares estimate of beta_3. \n')
% { c2,m2,freq2 } = histp(est[7,.]�,30);

fig2 = figure(2);
set(fig2, 'Color', 'white')
hist(est(:,7), 30)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Distribution of the generalized least squares estimate of $\beta_3$';
title(titel,'FontSize',10,'Interpreter', 'latex');

fprintf('Graph the distribution of the least squares t-statistics. \n')
% { c3,m3,freq3 } = histp(tstat[3,.]�,30);

fig3 = figure(3);
set(fig3, 'Color', 'white')
hist(tstat(:,3), 30)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Distribution of the least squares t-statistics of $\beta_3$';
title(titel,'FontSize',10,'Interpreter', 'latex');

fprintf('Graph the distribution of the generalized least squares t-statistics. \n')
% { c4,m4,freq4 } = histp(tstat[6,.]�,30);

fig4 = figure(4);
set(fig4, 'Color', 'white')
hist(tstat(:,6), 30)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Distribution of the generalized least squares t-statistics of of $\beta_3$';
title(titel,'FontSize',10,'Interpreter', 'latex');

fprintf('You can do the same for other parameters. \n')
fprintf('8.6 The Consequences of Using Least Squares \n')
fprintf('This section summarizes the material in Chapter 8 regarding the consequences \n')
fprintf('of using Least Squares estimation rules when Generalized Least Squares is appropriate. \n')

fprintf('8.7 Prediction \n')
fprintf('In the context of the Generalized Least Squares model it is sometimes possible \n')
fprintf('to improve predictions by taking into account relationships, if any, between \n')
fprintf('current and future observations. The algebra is presented here in some detail \n')
fprintf('and will be applied in Chapter 9.5.5. \n')


