close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 16 \n')

fprintf('Time-Series Analysis and \n')
fprintf('Forecasting \n')

fprintf('16.1 Introduction \n')
fprintf('In this Chapter �pure� time series models are presented. Observations on a \n')
fprintf('random variable are considered a realization from a stochastic process. Thus \n')
fprintf('the purposes of this Chapter are to discuss ways to model stochastic processes, \n')
fprintf('to estimate the parameters of such a model and to use the estimated model to \n')
fprintf('forecast future values of the variable. \n')

fprintf('16.2 A Mathematical Model for Time-Series and \n')
fprintf('Its Characteristics \n')
fprintf('In this Section stochastic processes are defined and definitions of the autocovariance \n')
fprintf('and autocorrelation functions given. The concept of stationarity is \n')
fprintf('discussed and lag operator notation defined. \n')

fprintf('16.3 Autoregressive Processes \n')
fprintf('Autoregressive processes use past values of a random variable to explain present \n')
fprintf('and future values. To illustrate several data sets are examined. First an artificially \n')
fprintf('constructed sample is considered. \n')

fprintf('LOAD the data in file TABLE16.1. It consists of 100 observations on a random \n')
fprintf('variable y generated from an AR(2) process described on page 685 of ITPE2. \n')
fprintf('Examine the data; \n')

load mDataTable16_1
y = mDataTable16_1;
display(y)

fprintf('Plot the data against time. \n')
t = rows(y);
x = seqa(1,1,t);
% library qgraph;
% xy(x,y);

fig1 = figure(1);
set(fig1, 'Color', 'white')
plot(x, y, 'Color', 'black', 'LineWidth' , 3)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Plot of the data in Table 16.1';
% legend('RSS')
title(titel,'FontSize',10);
ylabel( '$y_t$', 'FontSize', 14, 'Interpreter', 'latex');
xlabel( 't', 'FontSize', 12);

fprintf('Write a proc that computes the partial autocorrelations for a data series, given \n')
fprintf('the data series and the maximum lag to be considered. The partial autocorrelations \n')
fprintf('are estimated by using the least squares estimator in (16.3.4) for model \n')
fprintf('(16.3.3). The maximum lag included is increased sequentially and the corresponding \n')
fprintf('coefficient is the partial autocorrelation coefficient for that lag value. \n')
fprintf('The programming difficulty is that the number of complete observations changes \n')
fprintf('as the lag length is increased. Place PROC PARTIAL in a convenient file and \n')
fprintf('run it. \n')


fprintf('Use PROC PARTIAL to estimate the partial autocorrelations for the data y and \n')
fprintf('compare the results to Table 16.2 in ITPE2. \n')
thetakk = fPartial(y,12);
display(thetakk)

fprintf('The approximate 95% bounds are given in (16.3.12). If the absolute value \n')
fprintf('of a partial autocorrelation coefficient is greater than 2/sqrt(t) then it is deemed \n')
fprintf('significantly different from zero. \n')

bound = 2/sqrt(t);
display(bound)

fprintf('On the basis of the sample partial autocorrelations we (correctly) identify the \n')
fprintf('process as AR(2). The estimation results are \n')
p = 2;
yp = y(p+1:t,1);
xp = [y(p:t-1,1) y(p-1:t-p,1)];
thetap = xp\yp;
display(thetap)
sig2 = (yp - xp*thetap)'*(yp - xp*thetap)/(t-2*p);
display(sig2)
fprintf('Compare the resulting estimates to the true values. \n')
fprintf('A second data set is given in Table 16.3. It is artificial data generated from \n')
fprintf('a MA(1) process. The file TABLE16.3 contains the 100 values of the actual, \n')
fprintf('unobservable errors and the observable random variable y. LOAD the data and \n')
fprintf('define y. \n')

% load dat[100,2] = table16.3;
load mDataTable16_3
dat = mDataTable16_3;
t = rows(dat);
y = dat(:,2);
display(y);

fprintf('Graph y against time. \n')
x = seqa(1,1,t);
% xy(x,y);

fig2 = figure(2);
set(fig2, 'Color', 'white')
plot(x, y, 'Color', 'black', 'LineWidth' , 3)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Plot of the data in Table 16.1';
% legend('RSS')
title(titel,'FontSize',10);
ylabel( '$y_t$', 'FontSize', 14, 'Interpreter', 'latex');
xlabel( 't', 'FontSize', 12);

fprintf('Obtain the partial autocorrelations for lags 1 - 15 and compare the the bound value. \n')
thetakk = fPartial(y,15);
display(thetakk);

fprintf('There are �significant� partial autocorrelations for relatively high lags. \n')

fprintf('16.4 Moving Average Processes \n')
fprintf('In this section moving average processes are defined. Identification of a MA \n')
fprintf('processs involves the autocorrelation function. Two different estimators for \n')
fprintf('autocorrelations are given in (16.4.9) and (16.4.11). Write a proc to obtain both \n')
fprintf('of these estimators of autocorrelation given the data series and the maximum \n')
fprintf('lag length. Place PROC AUTOCORR in a convenient file and run it. \n')


fprintf('Use PROC AUTOCORR to obtain the autocorrelation function for the data y from \n')
fprintf('Table 16.3 for 15 lag periods. Compare the values to the bound value. \n')

[rk,rkbar] = fAutocorr(y,15);
display(rk)
display(rkbar)

fprintf('Based on these autocorrelations the data series is identified to be a MA(1) \n')
fprintf('process. \n')

fprintf('To estimate the parameters of a MA(q) process the sum of squares objective \n')
fprintf('function in (16.4.18) must be minimized. In practice (16.4.21) is minimized. \n')
fprintf('Write a proc to calculate this objective function given the data series y and \n')
fprintf('a value of the single parameter, a. The ojective function is complicated by \n')
fprintf('the fact that the number of terms in the summed quantity increases as the \n')
fprintf('index of summation changes. Place PROC MA1SUM in a file and run it. In \n')
fprintf('general, the data should be centered by subtracting the mean of the data prior \n')
fprintf('to minimization. The solutions in the text assume that the data has zero mean \n')
fprintf('and thus that centering is not required. For that reason PROC MA1SUM includes \n')
fprintf('the centering step as a comment and is not used. \n')

fprintf('It is possible to minimize this objective function with respect to a using a \n')
fprintf('numerical optimization algorithm like in Chapter 12. It is tedious, however, as \n')
fprintf('the objective funtion itself is cumbersome to evaluate. In this case it is simpler \n')
fprintf('to use a numerical search to obtain the minimizing value. First search over a \n')
fprintf('rough grid from -0.9 to 0.9 to find the minimizing value. \n')

avec = [seqa(-0.9,.1,9); 0; seqa(.1,.1,9)];
obj = fMa1sum(avec,y);
display(obj)
ahat = avec(minindc(obj),1);
display(ahat)

fprintf('Then search over a finer grid of values near the minimizing value to obtain a \n')
fprintf('final estimate. \n')

avec = seqa(ahat-0.1,.01,20);
obj = fMa1sum(avec,y);
ahat = avec(minindc(obj),1);
display(ahat)

fprintf('Obtain estimates of the error variance. \n')
obj = minc(obj);
sighat2 = obj/(t-1);
sigtil2 = obj/t;
display(sighat2)
display(sigtil2)

fprintf('16.5 ARIMA Models \n')
fprintf('In this section the features of AR and MA processes are combined. A model \n')
fprintf('with both MA and AR terms is called an ARMA(p,q) model. If the data must \n')
fprintf('be differenced to achieve stationarity it is called an ARIMA(p,d,q) process. \n')

fprintf('16.6 The Box-Jenkins Approach \n')
fprintf('The Box-Jenkins approach to time-series model building is given in this section. \n')
fprintf('There are separate steps for identification, estimation and diagnostic checking. \n')
fprintf('The example used is data on corn prices which is given in Table 16.4. LOAD \n')
fprintf('file TABLE16.4 and examine the data. \n')

% load y[82,1] = table16.4;
% y�;

load mDataTable16_4
y = mDataTable16_4;

fprintf('Plot the data against time. \n')
t = rows(y);
x = seqa(1,1,t);

fig3 = figure(3);
set(fig3, 'Color', 'white')
plot(x, y, 'Color', 'black', 'LineWidth' , 3)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Plot of the data in Table 16.1';
% legend('RSS')
title(titel,'FontSize',10);
ylabel( '$y_t$', 'FontSize', 14, 'Interpreter', 'latex');
xlabel( 't', 'FontSize', 12);

% xy(x,y);

fprintf('Compute the partial autocorrelations for 10 periods and compare them to the \n')
fprintf('2 standard deviation bound. \n')
thetakk = fPartial(y,10);
display(thetakk)
bound = 2/sqrt(t);
display(bound)

fprintf('Compute the autocorrelations for 15 periods. \n')
[rk,rkbar] = fAutocorr(y,15);
display(rk)
display(rkbar)

fprintf('Based on these calculations the series is identified as an AR(1) process. Obtain \n')
fprintf('the parameter estimates for model (16.6.1). \n')
yt = y(2:t,1);
yl = y(1:t-1,1);
x = [ones(t-1,1) yl];
t = rows(x);
k = cols(x);
bhat = x\yt;
sighat2 = (yt - x*bhat)'*(yt - x*bhat)/(t-k);
covb = sighat2 * invpd(x'*x);
stderr = sqrt(diag(covb));
display(bhat)
display(stderr)
display(sighat2)

fprintf('Using these values calculate an estimate of mu as in (16.6.3) and calculate its \n')
fprintf('approximate asymptotic standard error. Your values will differ from those in \n')
fprintf('the text, which are based on the �rounded� values in Equation 16.6.2. \n')
nu = bhat(1,1);
rho = bhat(2,1);
mu = nu/(1-rho);
sdmu = sqrt(sighat2/((1-rho)^2 * t));
display(mu)
display(sdmu)

fprintf('In order to check the AR(1) specification obtain the least squares residuals and \n')
fprintf('calculate the autocorrelations. No distinct pattern should be present. \n')
ehat = yt - x*bhat;
[rk,rkbar] = fAutocorr(ehat,15);
display(rk)
display(rkbar)

fprintf('Calculate the portmanteau test statistic Q in (16.6.4) as a further check. If the \n')
fprintf('AR(1) process is correctly specified the statistic Q is approximately chi-square \n')
fprintf('with K-1 = 14 degrees of freedom. \n')
kvec = seqa(1,1,15);
q = t*(t+2)*sumc( rk.^2 ./(t-kvec));
display(q)
% cdfchic(q,15-1);
P = chi2cdf(q,15-1,'upper');
display(P)

fprintf('16.7 Forecasting \n')
fprintf('The estimated model can be used to generate forecasts of future values of the \n')
fprintf('stochastic process. Use Equation 16.7.14 to forecast one-step ahead. Your values \n')
fprintf('will differ from those in the text which uses the rounded parameter estimates \n')
fprintf('in Equation 16.6.2. \n')
x1 = [1 1114]';
yhat1 = x1'*bhat;
display(yhat1)

fprintf('Now repeat the process, using the past forecasts to generate the next future \n')
fprintf('value. \n')
x2 = [1 yhat1];
yhat2 = x2*bhat;
x3 = [1 yhat2];
yhat3 = x3*bhat;
x4 = [1 yhat3];
yhat4 = x4*bhat;
x5 = [1 yhat4];
yhat5 = x5*bhat;

fprintf('Store the forecasts in a vector for future use. \n')
yhat = [yhat1; yhat2; yhat3; yhat4; yhat5];

fprintf('In order to construct forecast intervals for these values a forecasting mean square \n')
fprintf('error must be constructed for each. As Equation 16.7.11 illustrates the forecast \n')
fprintf('MSE depends on the coefficents of the MA representation. The i�th MA coefficient \n')
fprintf('is shown to be .8i in the middle of page 711. Construct the first five of \n')
fprintf('these terms. \n')
phi0 = 1;
phi1 = .8;
phi2 = .8^2;
phi3 = .8^3;
phi4 = .8^4;

fprintf('Use Equation 16.7.11 to construct forecast MSEs for 5 periods into the future. \n')
sig1 = sighat2;
sig2 = sig1*(1 + phi1^2);
sig3 = sig1*(1 + phi1^2 + phi2^2);
sig4 = sig1*(1 + phi1^2 + phi2^2 + phi3^2);
sig5 = sig1*(1 + phi1^2 + phi2^2 + phi3^2 + phi4^2);
sigvec = [sig1; sig2; sig3; sig4; sig5];

fprintf('Obtain 95 percentage confidence bounds and construct Table 16.5 \n')
lb = yhat - 1.96*sqrt(sigvec);
ub = yhat + 1.96*sqrt(sigvec);
display(yhat)
display(sigvec)
display(lb)
display(ub)


