function out = meanc(input)

out = mean(input,1);

return