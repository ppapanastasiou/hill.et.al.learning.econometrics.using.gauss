function [sse, blam]= fSselam(y,x,lam)
% local *;
t = rows(x);
zlam = ones(t,3);
obs = 1;
while obs <= t;
    if obs == 1;
        zlam(obs,2) = x(1,1);
        zlam(obs,3) = lam;
    else
        zlam(obs,2) = x(obs,1) + zlam(obs-1,2)*lam;
        zlam(obs,3) = lam^obs;
    end
obs = obs + 1;
end

yt = y(2:t,1);
zt = zlam(2:t,:);
blam = zt\yt;
sse = (yt - zt*blam)'*(yt - zt*blam);
% retp(sse,blam);
% endp;

return
