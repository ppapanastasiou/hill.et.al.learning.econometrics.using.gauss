function li = fTobitLi(p0)

global x y

% local k1,b,sig,z,t1,l1,l2,li;
k1 = rows(p0); % /* sort out estimates */
b = p0(1:k1-1,1);
sig = sqrt(p0(k1,1));
z = (y > 0); % /* number of complete obs */
t1 = sumc(z);
l1 = log(1-normcdf(x*b/sig)) .* (1-z); % /* first term */
l2 = (((y-x*b).^2)./(2*sig.^2) ) .* z; % /* last term */
li = sumc(l1)-.5*t1*(log(2*pi)+log(sig.^2))-sumc(l2);

% retp(li);
% endp;

return