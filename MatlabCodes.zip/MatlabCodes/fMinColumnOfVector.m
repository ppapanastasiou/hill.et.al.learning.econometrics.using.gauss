function index = fMinColumnOfVector(x)
%finds column vector containing the index of the smallest element in the
%vector x

[n,k]=size(x);

if min([n k])~=1
    error('only column or row vectors are allowed as input to this function')
end

dMin=min(x);
index=find(x==dMin);

return
