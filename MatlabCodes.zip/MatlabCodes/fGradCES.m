function out = fGradCES(b)

global x y
%local g2,g3,mid;
mid = (b(2,:) .* (x(:,1).^b(3,:))) + ((1 - b(2,:)).* x(:,2).^b(3,:));
g2 = b(4,:) .* (x(:,1).^b(3,:) - x(:,2).^b(3,:)) ./ mid;
g3 = b(4,:).* (log(x(:,1)).*b(2,:).*x(:,1).^b(3,:)+ log(x(:,2)).* (1-b(2,:)).*x(:,2).^b(3,:)) ./ mid;
out = [ ones(rows(y),1) g2 g3 log(mid) ];

return