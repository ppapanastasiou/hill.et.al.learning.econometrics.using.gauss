function [bm,covbm]= fMixed(x,y,R,rr,psi)
% local t,k,b,sse,sighat2,covbm,bm;
t = rows(x);
k = cols(x);
b = x\y;
sse = (y-x*b)'*(y-x*b);
sighat2 = sse/(t-k);
covbm = invpd(x'*x./sighat2 + R'*pinv(psi)*R);
bm = covbm*(x'*y./sighat2 + R'*invpd(psi)*rr);
% ?;
display('Mixed Estimation Results')
% ?;
display('R || rr')
disp([R rr])
display('Est :"') 
disp(bm')
display('Std. Err. :')
disp(sqrt(diag(covbm))');
% retp(bm,covbm);
% endp;

return