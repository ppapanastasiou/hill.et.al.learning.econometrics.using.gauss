function z = minindc(x)
%finds column vector containing the index of the smalles element in each column of a matrix

[n,k]=size(x);
z=zeros(k,1);
y=min(x)';
for col=1:k;
   index=find(x(:,col)==y(col,1));
   index=index(1,1);
   z(col,1)=index;
end;
