function out = fFirstDerivative(beta)

global x1 x2

out = x1 + 2*beta*x2;

return