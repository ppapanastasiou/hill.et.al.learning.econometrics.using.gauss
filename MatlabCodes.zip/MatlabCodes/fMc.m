function  [b, sighat2]= fMc(x,beta,e)

y0 = x*beta;
y0=repmat(y0,1,cols(e));
y=y0+e;
t = rows(x);
k = cols(x);
b = x\y;
ehat = y-x*b;
sighat2 = sumc(ehat.^2)/(t-k);

results.b=b;
results.sighat2=sighat2;

return