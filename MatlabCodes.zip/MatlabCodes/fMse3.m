function mse=fMse3(beta, bbar, sigma2, sigbar)

t = length(beta);

mse = (t*sigma2*sigbar.^4 + sigma2.^2*(bbar - beta).^2)/((t*sigbar.^2 + sigma2).^2);

return