function collin(x)
% local *;
% /* Calculate char. roots and vectors in descending order */
% {lam,p} = eigrs2(x'*x);
[p, lam] = eig(x'*x);% In matlab with two outputs we get first the eigenvectors and then the eigenvalues
lam=diag(lam);% only want the diagonal, since we want only a column vector containing the eigenvalues to be compatible with the Gauss function eigrs2
lam = rev(lam);
p = (rev(p'))';
% /* Calculate and print condition numbers */
ratio = lam(1,1)./ lam;
condno = sqrt(ratio);
% format 10,7;
display('Characteristic roots') 
disp(lam')
display('Ratio') 
disp(ratio')
display('Condition numbers')
disp(condno')
% /* Calculate and print variance proportions */
prop = (p.^2) ./ repmat(lam', rows(p), 1);
propsum = sumc(prop');
prop = prop ./ repmat(propsum, 1, cols(prop)) ;
% ?; format 10,3;
display('Collinearity Diagnostic Table')
disp(prop')

return