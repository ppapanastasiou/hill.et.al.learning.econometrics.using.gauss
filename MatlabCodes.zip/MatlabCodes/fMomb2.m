function store = fMomb2(rho)
% local m,n,store,rhomat,i,j,bstar,sse,xstar,ixx,c22;
m = rows(rho);
n = cols(rho);
store = zeros(m,n);
rhomat = rho .* (store + 1);
i = 1;
while i <= m;
    j = 1;
    while j <= n;
[bstar,sse,xstar] = fNewb(rhomat(i,j));
store(i,j) = bstar(2) .* fRhoPost(rhomat(i,j));
j = j + 1;
    end
i = i + 1;
end
% retp(store);
% endp;

return
