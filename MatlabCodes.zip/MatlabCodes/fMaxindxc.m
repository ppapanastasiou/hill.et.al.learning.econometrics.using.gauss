function [wMaxRowIndex, wMaxValue] = fMaxindxc(mInput)
%The function fMaxindc gives the row index of the maximum element in a column.

[wMaxValue, wMaxRowIndex] = max(mInput);

return

