function dOut = fDerv1(p)

dOut = 2.*p-3*p.^2;

return