function pdft= fPdft3(e,nu,sig)
% local *;
c1 = gamma( (nu+1)/2 ) * (nu*sig.^2)^(nu/2) ./(gamma(.5)*gamma(nu/2));
pdft = c1 .* (nu*(sig.^2) + e.*e).^(-(1+nu)/2);
% retp(pdft);
% endp;

return