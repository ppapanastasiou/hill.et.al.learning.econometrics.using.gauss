function dOut=fCdfx(x)

dOut=1-exp(-3*x);

return
