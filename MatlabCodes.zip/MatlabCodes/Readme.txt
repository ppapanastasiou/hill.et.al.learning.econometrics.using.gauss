MATLAB Code to reproduce results from the book:

Introduction to the Theory and Practice of Econometrics, 2nd Edition Hardcover  � March 17, 1988 
by George G. Judge (Author),    R. Carter Hill (Author),    William E. Griffiths (Author),    Helmut L�tkepohl (Author),    Tsoung-Chao Lee (Author) 
Amazon Link: http://www.amazon.com/Introduction-Theory-Practice-Econometrics-Edition/dp/0471624144

The code is a translation of the GAUSS code found in the book:
Learning Econometrics Using GAUSS a computer handbook to accompnay Introduction to the Theory and Practice of Econometrics, 2nd Edition
prepared by R. Carter Hill
Amazon Link: http://www.amazon.com/Learning-Econometrics-Using-GAUSS-George/dp/0471510742/ref=sr_1_5?s=books&ie=UTF8&qid=1427974664&sr=1-5&keywords=gauss+econometrics

Chapter 5 to 22 can be found freely on the internet by downloading the PDF:
Using Gauss for Econometrics
Carter Hill and Lee Adkins
August 30, 2001
Link: pages.suddenlink.net/ladkins/pdf/GAUSS.pdf

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Scripts files start with the letter "b" for batch. For example bChapter2
Most user defined functions begin with the letter "f". For example fAuto


