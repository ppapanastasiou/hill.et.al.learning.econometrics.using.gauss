function out=fPdfNorm1(b, mean, std)

out = normpdf((b-mean)./std)./std;

return