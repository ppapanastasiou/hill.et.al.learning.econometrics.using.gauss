% /* BOXFULL -- Combine BOXCOX2 and BOXCOX3 for full estimation */
function p = fBoxfull(lam0)

global y x b sigmasq

% clearg lam,bvec,sigmasq,z,H,std,p;
% /* Compute the vector of lambda�s using BOXCOX2 */
lam = fMaxl(lam0,@fBoxcox2,x,y);
% /* Create a complete parameter vector from values in memory */
p = [b; lam; sigmasq];

% /* Compute the numerical gradients using gradp and BOXCOX3 */
% z = gradp(&BOXCOX3,p);
z = fGradApprox(@fBoxcox3,p);
% /* Compute the BHHH approximation to the Hessian */
H = z'*z;
% /* Compute standard errors */
std = sqrt(diag(invpd(H)));
% /* Print out results */
% ?;
fprintf('Estimates for Complete Model with Unconditional Std. Errors: \n');
fprintf('(b, lambda, sigmasq) \n');
disp(p)
fprintf('Standard errors \n');
disp(std)

% retp(p);
% endp;

return