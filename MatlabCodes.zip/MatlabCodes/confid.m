function out = confid (b,varcov,fstat,pos)

b1 = b(pos(1,1),1);
b2 = b(pos(2,1),1);
r = zeros(2,rows(b));
r(1,pos(1,1)) = 1;
r(2,pos(2,1)) = 1;
a = inv(r*varcov*r');
q = a(1,1)*a(2,2) - a(1,2)*a(1,2);
lb = b2 - sqrt(2*fstat*a(1,1)/q);
ub = b2 + sqrt(2*fstat*a(1,1)/q);
beta2 = seqa(lb,(ub-lb)/100,101);
csq = (b2 - beta2).^2*( - q/a(1,1).^2) + fstat*2/a(1,1);
c = sqrt(abs(csq));
beta1a = b1 + (b2-beta2)*a(1,2)/a(1,1) + c;
beta1b = b1 + (b2-beta2)*a(1,2)/a(1,1) - c;
tmp1=[beta2;rev(beta2)];
tmp2=[beta1a;rev(beta1b)];

out = [tmp1 tmp2];
return