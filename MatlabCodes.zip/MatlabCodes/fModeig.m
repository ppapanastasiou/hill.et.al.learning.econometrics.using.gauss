function dOut=fModeig(v, s)

dOut=sqrt(v/(v+1))*s;

return