function out = minc(input)

out = min(input, [], 1);

return