function vOut=vec(mInput)

vOut=mInput(:);

end