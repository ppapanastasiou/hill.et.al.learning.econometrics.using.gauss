function ts=fTtest(r,rr,b,ixx,sighat2)

ts=(r*b - rr)./sqrt(sighat2*r*ixx*r');

return