function y = shiftr(x, s, f)
 %SHIFTR Shift rows of a matrix.
 %
 % SHIFTR(X, S, F) shifts the rows of X by S steps and fills any empty
 % elements with the elements of F. X must be a two-dimensional matrix.
 % S must be a scalar or a column vector with the same number of rows as X.
 % F must be a scalar or a matrix with the same size as X.

 % Author: Peter J. Acklam
 % Time-stamp: 2001-10-23 14:13:24
 % E-mail: pjacklam@online.no
 % URL: http://home.online.no/~pjacklam

 error(nargchk(3, 3, nargin));

 if ndims(x) ~= 2
    error('X must be a two-dimensional matrix.');
 end

 sx = size(x);
 ss = size(s);
 sf = size(f);

 if (ndims(s) ~= 2) | (ss(2) ~= 1) | all(ss(1) ~= [1 sx(1)])
    error('S must be a scalar or a column with the same number of rows as X.');
 end

 if any(s(:)) < 0
    error('S must contain non-negative integers only.');
 end

 if ~all(sf == 1) & ~isequal(sf, sx)
    error('F must be a scalar or a matrix with the same size as X.');
 end

 % initialize output
 y = x;
 y(:) = f(:);

 if ss(1) == 1 % "s" is a scalar
    y(:,1:sx(2)-s) = x(:,s+1:end);
 else % "s" is a vector
    cols = repmat((1:sx(2)).', [1 sx(1)]);
    shft = repmat(s.', [sx(2) 1]);
    I = (cols + shft) <= sx(2);
    J = (cols - shft) >= 1;
    x = x.';
    y = y.';
    y(I) = x(J);
    y = y.';
 end