function [b, covb, results]=fMyOls(x, y, iPrint)

if nargin <3 || isempty(iPrint)
    iPrint = 0;
end

T = rows(x);
k=cols(x);
df = T - k;

b = x\y;
ehat = y - x*b;
sse = ehat'*ehat;
sighat2 = sse/df;

covb = sighat2*invpd(x'*x);
stderr = sqrt(diag(covb));
tstat = b./stderr;

ybar = mean(y,1);
sst = y'*y - T*(ybar.^2);
r2 = 1 - (sse/sst);
rbar2 = 1 - (T-1)*(1-r2)/df;

results.T = T;
results.df = df;
results.b = b;
results.stderr = stderr;
results.sse = sse;
results.sst = sst;
results.tstat = tstat;
results.r2=r2;
results.rbar2=rbar2;
results.sighat2 = sighat2;
results.covb = covb;

%other way to compute sighat2
sighat2_1 = sumc(ehat.^2)/(T-k);
results.sighat2_1=sighat2_1;

if iPrint ==1
    %print out
    disp('Number of observations:')
    disp(T)
    disp('Degrees of freedom:')
    disp(df)
    disp('Sum of Squared Errors:')
    disp(sse)
    disp('Total Sum of Squares:')
    disp(sst)
    disp('R-squared:')
    disp(r2)
    disp('R-bar-squared:')
    disp(rbar2)
    disp('Sigmahat^2:')
    disp(sighat2)
    disp('Standard Error:')
    disp(sqrt(sighat2))
    disp('          Coeffs       Stderr        T-Stats     P-value')
    disp([b stderr tstat tcdf(tstat,df)])
    disp('Variance-Covariance Matrix for b:')
    disp(covb)
end


return