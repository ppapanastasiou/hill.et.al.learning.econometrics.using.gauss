% /***************************************************************/
% /* */
% /* MAXM.PRC -- Maximum likelihood estimation using the */
% /* Newton-Raphson Algorithm (Data in Memory) */
% /***************************************************************/

function b0 = fMaxm(b0, ofn)

% ofn is the objective function see also fMaxl.n function
% local ofn:proc;
% local t,std,tol,H,g,b,db,iter,ofn1,ofn2,z,s,converge;
db = 1;
iter = 1;
converge = 0;
tol = 1e-5;
while converge ~= 1;
    % g = gradp(@ofn,b0);
    g = fGradApprox(ofn,b0);
    % H = hessp(@ofn,b0);
    H = fHessian(ofn,b0);
    db = -inv(H)*g; % /* -solpd(g,m) is much faster */
    
    % gosub step;
    % step:
    s = 2;
    ofn1 = 0;
    ofn2 = 1;
    while ofn1 < ofn2;
        s = s/2;
        ofn1 = ofn(b0 + s*db);
        ofn2 = ofn(b0 + s*db/2);
    end
    b = b0 + s*db;
    % gosub prnt;
    % prnt:
    % format 4,2; " i = " iter;;
    % format 4,2; " Steplength = " s;;
    % format 10,6; " Likelihood = " ofn(b0);
    % format 10,6; " b = " b0�;
    % ?;
    
    db = abs(b-b0);
    b0 = b;
    if abs(db) < tol; 
        converge = 1;
    else
        iter = iter + 1;
    end
end

fprintf('Final Results \n');
fprintf('Coefficients \n')
disp(b0);
std = sqrt(diag(-inv(H)));
fprintf('Standard errors \n')
disp(std);

% retp(b0);

return