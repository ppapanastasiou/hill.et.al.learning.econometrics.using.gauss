function out = stdc(input)

out = std(input,[],1);

return