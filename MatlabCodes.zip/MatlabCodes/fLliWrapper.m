function mLik = fLliWrapper(y, bvec, sigmavec, iAlternative)
% Wrapper function for the likelihood

if (nargin<4 || isempty(iAlternative))
    iAlternative=0;
end

if length(bvec)~=length(sigmavec)
    error('the length of bvec and sigmavec should be equal')
end

mLik = zeros(length(bvec), length(sigmavec));
for i = 1:length(bvec)
    for j = 1:length(sigmavec)
        mLik(i, j) = fLli(y, bvec(i), sigmavec(j), iAlternative);
    end
end

return
