function [br,covbr]= fRls1(x, y, R, rr, iPrint)

if nargin <5 || isempty(iPrint)
    iPrint =1;
end

% local t,b,sinv,q,br,sser,sig2,covbr,stderr,sseu,
% sighat2,fstat;
t = rows(x); k = cols(x); j = rows(R);
b = x\y;
sinv = invpd(x'*x);
q = invpd(R*sinv*R');
br = b + sinv*R'*q*(rr - R*b);
sser = (y - x*br)'*(y - x*br);
sig2 = sser/(t-k+j);
covbr = sig2 * (sinv - sinv*R'*q*R*sinv);
stderr = sqrt(diag(covbr));
sseu = (y - x*b)'*(y - x*b);
sighat2 = sseu ./ (t - k);
fstat = (sser - sseu)/(j * sighat2);

if iPrint ==1
    %print out
    disp('RLS results:')
    disp([R rr])
    disp('Est:')
    disp(br)
    disp('Std. Err.:')
    disp(stderr)
    disp('Fstatistic:')
    disp(fstat)
    disp('pvalue:')
    disp(fcdf(fstat,j,t-k, 'upper'))
end
% 
% format 10,4;
% "RLS results";
% ?;
% "R || rr";
% r~rr;
% ?;
% "Est :" br�;
% "Std. Err. :" stderr�;
% sseu = (y - x*b)�(y - x*b);
% sighat2 = sseu ./ (t - k);
% fstat = (sser - sseu)/(j * sighat2);
% ?;
% " F-statistic " fstat;
% " pval= " cdffc(fstat,j,t-k);
% retp(br,covbr);
% endp;

return