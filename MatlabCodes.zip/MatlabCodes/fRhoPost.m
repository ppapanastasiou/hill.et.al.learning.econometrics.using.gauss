function out = fRhoPost(rho)

global rhoconst

out = (rhoconst * fRhoKern(rho));

return