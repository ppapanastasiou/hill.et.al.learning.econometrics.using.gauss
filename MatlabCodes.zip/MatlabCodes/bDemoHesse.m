% bDemoHesse.m : Demoskript fuer fHessApprox
%
% Copyright (c) 2013, 2014 Th. Poddig, A. Varmaz, Ch. Fieberg
%
% Bestandteil des Buchs: 
% Computational Finance von Th. Poddig, A. Varmaz, Ch. Fieberg

% Alles loeschen
clear; clc; close all;

% --- Erste Beispiel: Funktion mit zwei Argumenten

% Punkt setzten
vX = [2;3];

% Hesse-Matrix und Gradient berechnen
[ mHess, vGrad ] = fHessApprox( @fTestHessian, vX );

% ---- Zweite Beispiel: Sinus-Funktion, Ableitung leicht zu ueberpruefen

% Punkt setzten
dX = 2;

% Hesse-Matrix und Gradient berechnen
[ dHess, dGrad ] = fHessApprox( @sin, dX );

% Kontrolle Analytisch
% Gradient:
dGrad1 = cos(dX);
dDiffGrad = abs(dGrad-dGrad1);
% Hesse: 
dHess1 = -sin(dX);
dDiffHess = abs(dHess-dHess1);