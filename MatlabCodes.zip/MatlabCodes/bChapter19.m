close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 19 \n')
fprintf('Qualitative and Limited \n')
fprintf('Dependent Variable Models \n')

fprintf('19.1 Introduction \n')
fprintf('In this Chapter some very useful models are considered. Probit and Logit \n')
fprintf('are designed for situations when the dependent variable takes only two values, \n')
fprintf('usually 1 and 0, indicating that some event did, or did not, occur. Tobit is \n')
fprintf('appropriate when the dependent variable is truncated. That is, for example, it \n')
fprintf('may only be observable if it is positive. \n')

fprintf('19.2 Binary Choice Models \n')
fprintf('An example of Maximum Likelihood estimation of the probit model is given on \n')
fprintf('pages 793-794. The data for the example is generated as follows. First, LOAD \n')
fprintf('the design matrix in Equation 5.10.2. It is in the file JUDGE.X. Then stack it \n')
fprintf('four times to produce a design matrix with T = 80 observations. \n')

% load x[20,3] = judge.x;
load mDataJudge

fprintf('define x as a global variable')
global x

x = mDataJudge;

x = [x; x; x; x];
t = rows(x);
k = cols(x);

fprintf('Create an error vector of N(0,1) disturbances using the �official� normal random \n')
fprintf('disturbances in NRANDOM.DAT. \n')
% open f1 = nrandom.dat;
% e = readr(f1,80);
% f1 = close(f1);

load nrandom200
e =  nrandom200(1:80);

fprintf('Let beta take the indicated values (0,3,-3) and construct the variable ystar, \n')
fprintf('which is unobservable to the economic researcher. \n')

beta = [0 3 -3]';
ystar = x*beta + e;

fprintf('What is observable is the binary variable yt, which takes the value of 1 or 0 \n')
fprintf('depending on whether ystar is positive or not. Compare the 80 values produced \n')
fprintf('to the values in Table 19.4 for y1, y2, y3 and y4. \n')

fprintf('define y as a global variable')
global y

y = ystar > 0;
% format 4,2;
display(reshape(y, 20, 4))

fprintf('To estimate the probit model using the Newton-Raphson algorithm, (19.2.20), \n')
fprintf('first write PROC PROBITLI which returns the value of the log-likelihood function. \n')
fprintf('It assumes that X and y are in memory and takes as argument an estimate \n')
fprintf('of beta. It uses the GAUSS function CDFN which returns the value of the CDF \n')
fprintf('for a N(0,1) random variable. \n')

fprintf('At this point there are several ways to proceed. The general optimization algorithms \n')
fprintf('of Chapter 12 could be used to maximize the log-likelihood function or \n')
fprintf('an algorithm specifically for probit could be written, which entails programming \n')
fprintf('the first and second derivatives. We will follow both paths. First, PROC PROBIT \n')
fprintf('is written which returns the probit ML estimates and their asymptotic covariance \n')
fprintf('matrix using (19.2.20) and the derivatives given in (19.2.19) and (19.2.21). \n')
fprintf('Its arguments are X, y and PROC PROBITLI. Place the PROC in a convenient \n')
fprintf('file and run it. \n')

fprintf('Use PROC PROBIT to estimate the parameters of our model \n')
[bp,covbp] = fProbit(x,y,@fProbitLi);


fprintf('Instead of writing a complete new PROC, we could have used PROC MAXM from \n')
fprintf('Chapter 12. Make sure PROC MAXM is in memory and obtain the maximum \n')
fprintf('likelihood estimates of the parameters using this Newton-Raphson algorithm \n')
fprintf('based on numerical derivatives. Use the OLS estimates as starting values. \n')
b = x\y;
bp = fMaxm(b,@fProbitLi);

fprintf('You should observe that using numerical derivatives is slower. In this case \n')
fprintf('the numerical derivatives provide a good approximation to the Hessian when \n')
fprintf('evaluated at the final estimates. That is because the log-likelihood function of \n')
fprintf('the probit model is strictly concave. \n')
fprintf('Given this experience estimation of the logit model is easy. Write PROC \n')
fprintf('LOGITLI that returns the value of the log-likelihood function for the logit model. \n')

fprintf('Use PROC MAXM to obtain the ML estimates of the parameters of the logit \n')
fprintf('model. \n')
b = x\y;
bl = fMaxm(b,@fLogitLi);

fprintf('Once again there may be a question how close the approximate Hessian is to \n')
fprintf('the true one. The Hessian for the logit model is given in (19.2.22). \n')

pdf = exp(-x*bl) ./ (1+exp(-x*bl)).^2;
H = -(x .* repmat(pdf, 1, cols(x)))'*x;
std = sqrt(diag(-inv(H)));
display(std)

fprintf('In this case the approximate Hessian is very close to the true one at the final \n')
fprintf('estimates. \n')

fprintf('The likelihood-ratio test for the �overall� significance of the model is described \n')
fprintf('on the top of page 794. First calculate the value of the log- likelihood function \n')
fprintf('at the ML estimates for the probit model. \n')
l1 = fProbitLi(bp);

fprintf('Under the hypothesis the X matrix is a column of ones. Use the sample mean \n')
fprintf('of y as the initial estimate of the remaining parameter, beta1, and obtain the ML \n')
fprintf('estimate for this restricted model. \n')
x = ones(t,1);
b = meanc(y);
br = fMaxm(b,@fProbitLi);

fprintf('Calculate the value of the log-likelihood for the restricted model and then the \n')
fprintf('value of the test statistic. \n')
l2 = fProbitLi(br);
lr = 2*(l1-l2);
pval = chi2cdf(lr,t-k, 'upper');
display(lr)
display(pval)

fprintf('Calculate the value of the �Pseudo�-R2. \n')
r2 = 1-(l1/l2);
display(r2)

fprintf('Calculate the values of the partial derivatives at xstar. \n')
xstar = [1 .69 .69]';
partials = normpdf(xstar'*bp) .* bp;
display(partials)

fprintf('19.3 Models with Limited Dependent Variables \n')
fprintf('In this Section the Tobit model is presented. Construct the data in Table 19.2 \n')
fprintf('as follows. First construct X and a vector of 20 N(0,16) random errors. \n')
x = [ones(20,1) seqa(1,1,20)];
t = rows(x);
k = cols(x);

% open f1 = nrandom.dat;
% e = readr(f1,20);
% f1 = close(f1);

load nrandom200
e = nrandom200(1:20);
e = 4*e;

fprintf('Using the given parameter values construct ystar and y. \n')
beta = [-9 1]';
ystar = x*beta + e;
z = (ystar > 0);
y = z .* ystar;
display(ystar)
display(y)
display(x)

fprintf('Obtain the OLS estimates using all the data and ignoring the truncated nature \n')
fprintf('of the dependent variable. Compare to column 1 of Table 19.3. \n')
b = x\y;
sig2 = (y - x*b)'*(y - x*b)/(t - k);
std = sqrt(diag(sig2*invpd(x'*x)));
display(b)
display(std)
disp(b./std);

fprintf('Delete the observations that have y = 0 and use OLS again. Compare the results \n')
fprintf('to the second column of Table 19.3. \n')
dat = [y x];
fprintf('Sort the data and place the complete observations first,then delete the rest \n')
dat = rev(sortrows(dat,1));
t1 = sumc(z);
yt = dat(1:t1,1);
xt = dat(1:t1,2:cols(dat));
% /* Apply OLS */
bt = xt\yt;
sigt = (yt - xt*bt)'*(yt - xt*bt)/(t1 - k);
stdt = sqrt(diag(sigt*invpd(xt'*xt)));
display(bt)
display(stdt)
display(bt./stdt)

fprintf('To carry out ML estimation we will use MAXM. First write PROC TOBITLI which \n')
fprintf('returns the value of the Tobit log-likelihood function given in Equation 19.3.6. \n')
fprintf('Its argument is an initial set of estimates for beta and sigma^2, in that order. \n')

fprintf('Using as initial estimates the results of OLS applied to the complete sample, \n')
fprintf('obtain the ML estimates of the parameters. \n')
p0 = [b; sig2];
param = fMaxm(p0,@fTobitLi);

fprintf('The asymptotic covariance matrix for the ML estimates is given by the inverse \n')
fprintf('of the information matrix in Equation 19.3.8. Write PROC TOBITI to compute \n')
fprintf('it. Its argument is the set of ML estimates. \n')

fprintf('Use PROC TOBITI to calculate the estimate of the asymptotic covariance matrix, \n')
fprintf('standard errors and t-values. \n')
covp = inv(fTobiTi(param));
display(covp)
std = sqrt(diag(covp));
display(param)
display(std)
display(param./std)

fprintf('In Equations (19.3.9) and (19.3.10) various regression functions and their partial \n')
fprintf('derivatives are shown. \n')
b = param(1:k,1);
sig = sqrt(param(k+1,1));
xbar = meanc(x);
xbar = xbar';
z = (xbar'*b)./sig;
normcdf(z); % /* 19.3.10b */
m = 1 - z*normpdf(z)/normcdf(z)-(normpdf(z)/normcdf(z))^2; % /* 19.3.10c */
display(m)