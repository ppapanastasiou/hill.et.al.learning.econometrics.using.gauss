function out=fPdfg(x, a, b)

out = 1/(gamma(a)*b.^a).*x.^(a-1).*exp(-x/b);

return