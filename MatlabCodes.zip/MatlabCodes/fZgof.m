function fZgof(z)

nsam = rows(z);
v = seqa(-3,.3,21); 
v = [-5;v;5]; %/* define intervals */

freq = counts(z,v); %/* observed freq. */
freq = freq(2:23,:);

cdfval = normcdf(v); %/* calc. expected freq. */
prob = cdfval(2:23,:) - cdfval(1:22,:);
expected = nsam * prob;

% /* test statistic */

gof = sumc(( (freq - expected).^2) ./ expected);
pval = chi2cdf(gof,21,'upper'); % /* p-value */
% "chi-square statistic : " gof; %/* print */
% "p-value : " pval;
% retp("");
% endp;

disp('chi-square statistic :')
disp(gof)
disp('p-value :')
disp(pval)

return