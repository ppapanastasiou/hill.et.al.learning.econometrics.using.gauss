function out=fPdft2(u, h, v, x)

out = gamma((v+1)/2)*(1/(gamma(0.5)*gamma(v/2)))*sqrt(h/v)*...
    (1+(h*(x-u).^2)/v).^(-(v+1)/2);

return