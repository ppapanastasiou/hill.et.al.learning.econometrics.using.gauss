function mom1 = fMub2(rho,b2)
%local mom1;
mom1 = b2 .* fRb2Post2(rho,b2);
% retp(mom1);
% endp;

return