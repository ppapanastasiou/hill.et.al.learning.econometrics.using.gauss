% /* PROC BOXCOX2 -- general Box-Cox Concentrated Likelihood */
function li = fBoxcox2(lam0)

% Define b in fBoxcox2 as a global variable
% Define sigmasq in fBoxcox2 as a global variable
global y x j b sigmasq

% local dat,ybc,c,e,li;
% clearg b,xbc,sigmasq;
% /* Transform the data with the current lambda�s */
dat = fBct([y x],lam0);
ybc = dat(:,1);
xbc = [j dat(:,2:cols(dat))];
% /* Compute the estimate of b (Equation 12.5.11) */
b = xbc\ybc;
% /* Compute the estimate of sigamsq (Equation 12.5.12) */
e = ybc - xbc*b;
sigmasq = e'*e/rows(y);
% /* Compute the components of the log-likelihood in (Equation 12.5.19) */
c = log(2*pi*sigmasq);
li = -(c/2) - (e.*e/(2*sigmasq)) + (lam0(1,:)-1).*log(y) ;
% retp(li);
% endp;

return