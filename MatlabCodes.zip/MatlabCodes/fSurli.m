function out = fSurli(b0)

global y p v

% local g,b1,b2,z,e1,e2,s1,s2,s12,s;
g = b0(1:3,:); % /* Separate the param values */
b1 = b0(4,:);
b2 = b0(5,:);
z = y - p*g; % /* Calculate Supernumerary income */
e1 = v(:,1) - p(:,1)*g(1,1) - b1*z; % /* Residuals */
e2 = v(:,2) - p(:,2)*g(2,1) - b2*z;
% /* Elements of Contemporaneous Covariance */
s1 = e1'*e1;
s2 = e2'*e2;
s12 = e1'*e2;
s = [s1 s12; s12 s2];
out = (-(rows(y)/2)*log(det(s))); % /* Equation 12.4.9 */
% endp;
return