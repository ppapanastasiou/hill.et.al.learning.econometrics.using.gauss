close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Appendix A \n')
fprintf('Linear Algebra and Matrix \n')
fprintf('Methods \n')
fprintf('In this section the use of GAUSS matrix operations is illustrated. These operations \n')
fprintf('are used throughout the text. \n')
fprintf('A.1 Definition of Matrices and Vectors \n')
fprintf('A matrix is a rectangular array. A vector is a single row or column. When \n')
fprintf('defining a matrix in GAUSS using the LET command the matrix is assumed \n')
fprintf('to be a vector unless dimensions are given. For example \n')
x = [3 9 0 -5 1]';
display(x)

x = [3 9 0 -5 1];
display(x)

fprintf('The transpose of a column vector is a row vector. \n')
display(x')

fprintf('An identity matrix is specified as \n')
I = eye(3);
display(I)

fprintf('The diagonal of a square matrix can be extracted as \n')
ivec = diag(I);
display(ivec')

fprintf('The diagonal of a square matrix can be inserted as \n')
dvec = [1 2 3]';
d = diagrv(I,dvec);
display(d)

fprintf('Matrix equality requires that two matrices be equal element by element, which \n')
fprintf('means they must be of the same dimension. The equality symbol (=) in \n')
fprintf('GAUSS means a bit more however. It is truly an �assigment� operator, where \n')
fprintf('the symbol on the left-hand-side is replaced by whatever is on the right-handside. \n')
fprintf('Thus for example, \n')
d = sumc(d);
display(d)

fprintf('is legal and simply means that the symbol d is assigned the value of sumc(d), \n')
fprintf('where SUMC sums the elements of the the columns of its matrix argument. \n')
fprintf('Matrix equality can be checked using the relational operator == (or EQ) which \n')
fprintf('returns a value of 1 or 0 depending upon whether two matrices are equal element \n')
fprintf('by element. See the GAUSS manual for further explanation of RELATIONAL \n')
fprintf('OPERATORS, ELEMENTWISE OPERATORS and LOGICAL \n')
fprintf('OPERATORS. \n')
fprintf('A.2 Matrix Addition and Subtraction \n')
fprintf('Formally, matrix addition and subtraction requires that the matrices involved \n')
fprintf('be of the same dimension. \n')
A = [6 8; -2 4];
B = [0 -3; 9 7];
C = A + B;
display(C)

fprintf('GAUSS commands are somewhat more flexible in that it offers �elementwise� \n')
fprintf('operations. To add or subtract a constant to every element of a matrix. \n')
C = 5 + A;
display(C)

fprintf('To add a row to each row. \n')
fprintf('Matlab is not that flexible in this respect as GAUSS so we need to use the function repmat or use the kronecker product to expand the vector to equalthe size of the matrix \n')
d = [9 1];
d = repmat(d, rows(A), 1);
fprintf('Or with the kronecker product \n')
d = [9 1];
d = kron(ones(rows(A), 1), d);
C = A + d;
display(C)

fprintf('To add a column to each column. \n')
fprintf('Matlab is not that flexible in this respect as GAUSS so we need to use the function repmat or use the kronecker product to expand the vector to equal the size of the matrix \n')
d = [2 3]';
d = repmat(d, 1, cols(A));
fprintf('Or with the kronecker product \n')
d = [2 3]';
d = kron(ones(1, cols(A)), d);
C = A + d;
display(C)

fprintf('A.3 Matrix Multiplication \n')
fprintf('Matrices must be conformable for multiplication. \n')
D = [3 -8 1; 9 2 5];
F = A*D;
display(F)

fprintf('Inner products of vectors and matrices can be shortened. \n')
F = A'*A;
display(F)

fprintf('or \n')
fprintf('Not in Matlab \n')
F = A'*A;
display(F)

fprintf('Scalar multiplication is defined as \n')
F = 5*A;
display(F)

fprintf('Elementwise multiplication (.*) can be used to multiply corresponding elements, \n')
fprintf('corresponding rows or columns. \n')
% /* Multiply corresponding elements */
F = A .* B;
display(F)

% /* Elementwise multiply each row of A by d */
d= [.5 1];
F = A .* repmat(d, rows(A),1);
display(F)

% /* Elementwise multiply each column of A by e */
e = [3 2]';
F = A .* repmat(e, 1, cols(A));
display(F)

fprintf('Elementwise divison (./) works in the same way. Note that A ./ B would result \n')
fprintf('in a divison by zero, which is to be avoided. \n')
F = A ./ repmat(d, rows(A), 1);
display(F)

F = A ./ repmat(e, 1, cols(A));
display(F)

fprintf('Another useful elementwise operater is exponentiation, (^). \n')
fprintf('Not in Matlab use .^ instead \n')
F = A.^2;
display(F)

fprintf('A.4 Trace of a Square Matrix \n')
fprintf('GAUSS does not have a trace operator, thus to sum diagonal elements combine \n')
fprintf('SUMC and DIAG as \n')
tr = sumc(diag(A));
display(tr)

fprintf('Maltab does \n')
tr = trace(A);
display(tr)

fprintf('A.5 Determinant of a Square matrix \n')
fprintf('The GAUSS determinant function is DET. \n')
c = det(A);
display(c)

fprintf('A.6 The Rank of a Matrix and Linear Dependency \n')
fprintf('The rank of a matrix is the number of linearly independent rows or columns. A \n')
fprintf('square matrix with full rank (i.e., rank equals dimension) is nonsingular and has \n')
fprintf('an inverse and a nonzero determinant. GAUSS has a function, RANK, which \n')
fprintf('computes the rank of a matrix by counting its number of nonzero �singular \n')
fprintf('values�. More is given in Section A.11. \n')

fprintf('A.7 Inverse Matrix and Generalized Inverse \n')
fprintf('The inverse of a square nonsingular matrix can be found in several ways in \n')
fprintf('GAUSS. The relevant functions are INV, INVPD and SOLPD. Use INV to \n')
fprintf('find the matrix inverse of a general, nonsingular matrix. \n')


inva = inv(A);
display(inva)

check = inva*A;
display(check)

fprintf('If the matrix is positive definite (Section A.14) and symmetric then the function \n')
fprintf('INVPD can be used and is faster than INV. \n')
% /* AA is a positive definite and symmetric matrix */
AA = A'*A;
display(AA)

aainv = pinv(AA);
display(aainv)
check = aainv*AA;
display(check)

fprintf('The function SOLPD will be explained in the following section. \n')
fprintf('GAUSS does provide a command to find the generalized (Moore-Penrose) inverse, \n')
fprintf('PINV. \n')

fprintf('A.8 Solutions for Systems of Simultaneous Linear Equations \n')
fprintf('To solve a system of equations like Equation A.8.2 the matrix A must be nonsingular. \n')
fprintf('If that is true then the matrix inverse function can be used to solve \n')
fprintf('for the unknowns x. Using the matrix A already in memory, \n')
b = [2 1]';
x = inva*b;
check = A*x;
display(check)

fprintf('CHECK is identical to the vector B as x is the solution to the system of equations \n')
fprintf('and thus satisfies the equality. \n')
fprintf('If A is positive definite then the faster function SOLPD can be used. Using AA \n')
fprintf('created just above for A, \n')
% x = solpd(b,AA);

fprintf('Solve Equation Ax=b which has the solution x = inv(A)*b \n')
x = mldivide(AA,b);
check = AA*x;
display(check)

fprintf('SOLPD can also be used to invert a positive definite matrix. \n')
% aainv = solpd(eye(2),AA);
aainv = mldivide(AA, eye(2));
check = aainv*AA;
display(check)

fprintf('A.9 Characteristic Roots and Vectors of a Square Matrix \n')
fprintf('The characteristic roots and vectors of a square matrix are found by solving the \n')
fprintf('characteristic polynomial (A.9.2) for lambda and then finding vectors x which \n')
fprintf('solve (A.9.1). If the square matrix is symmetric then the characteristic roots \n')
fprintf('are real. Otherwise they may not be. GAUSS provides functions that finds \n')
fprintf('the characteristic roots and vectors for both of these cases. \n')
fprintf('First, for symmetric matrices use the functions EIGRS (roots only) or EIGRS2 \n')
fprintf('(roots and vectors). For example, using the matrix AA. \n')
% {r,v} = eigrs2(AA);
[v,r] = eig(AA); % In matlab with two outputs we get first the eigenvectors and then the eigenvalues
r = diag(r); % only want the diagonal, since we want only a column vector containing the eigenvalues to be compatible with the Gauss function eigrs2
display(r)
display(v)

fprintf('Note that GAUSS returns the roots in ascending order of magnitude. The \n')
fprintf('Characteristic vectors are found in the columns of V and are in the order of the \n')
fprintf('characteristic roots. Check that the first characteristic root and vector solve \n')
fprintf('(A.9.1). \n')
c = (AA - r(1,1)*eye(2))*v(:,1);
display(c)

fprintf('If the square matrix is not symmetric use the functions EIGRG or EIGRG2. \n')
fprintf('These functions return the real and complex parts of the roots and vectors. \n')
fprintf('Using the example in the text, \n')
A = [5 -3; 4 -2];

[d, c] = fEig(A, 1);

% % {rr,ri,vr,vi} = eigrg2(A);
% [vr,rr,vi] = eig(A);
% vr = rev(vr')';
% rr = rev(diag(rr));
% vi = rev(vi);
% 
% display(vr)
% display(rr)
% display(vi)

fprintf('Note that in this example the roots are real and returned in descending order. \n')
fprintf('The characteristic vectors are real as well. As the text notes, characteristic \n')
fprintf('vectors are not unique with respect to sign, and in this case GAUSS returns \n')
fprintf('the the positive ones. \n')

fprintf('A.10 Orthogonal Matrices \n')
fprintf('An orthogonal matrix is one whose transpose is its inverse. As noted in the \n')
fprintf('text, the characteristic vectors of a symmetric matrix form an orthogonal set. \n')
fprintf('The matrix V containing the characteristic vectors of the symmetric matrix AA \n')
fprintf('is an example. \n')
I1 = v'*v;
display(I1);

I2 = v*v';
display(I2)

fprintf('Furthermore, AA*v = v*diag(lambda) where diag(lambda) is a diagonal matrix \n')
fprintf('with the characteristic roots on the diagonal. To illustrate, \n')
m1 = AA*v;
m2 = v*diagrv(eye(2),r);
disp([m1 m2])

fprintf('A.11 Diagonalization of a Symmetric Matrix \n')
fprintf('Using the results in A.10 and A.11 we can construct a matrix P that �diagonalizes� \n')
fprintf('a positive definite and symmetric matrix. First, note that the matrix of \n')
fprintf('characteristic vectors diagonalizes a symmetric matrix and returns a diagonal \n')
fprintf('matrix with the characteristic roots on the diagonal. \n')
lam = v'*AA*v;
disp([lam r])

fprintf('We can further diagonalize a matrix to an identity by using the matrix V postmultiplied \n')
fprintf('by a diagonal matrix whose nonzero elements are the reciprocals of \n')
fprintf('the square roots of the characteristic roots. \n')
P = v*diagrv(eye(2),1 ./ sqrt(r));
W = P'*AA*P;
display(W)

fprintf('It is useful to know that the rank of a matrix A is given by the number of nonzero \n')
fprintf('characteristic roots of A�A. In GAUSS the rank of a matrix is calculated from \n')
fprintf('the number of nonzero �singular values� of A, which are in fact the square roots \n')
fprintf('of the characteristic roots of A�A. The function that does this is RANK. The \n')
fprintf('command that performs the singular value decomposition is SVD. \n')
fprintf('A related transformation is the Cholesky decomposition, CHOL, which factors \n')
fprintf('a matrix (X) into the product X = Y�Y where Y is upper triangular. \n')

fprintf('A.12 Idempotent Matrices \n')
fprintf('An idempotent matrix is one which when multiplied by itself yields itself again. \n')
fprintf('To illustrate an econometricians favorite idempotent matrix \n')
X = [1 5; 1 7; 1 3; 1 1; 1 0];
M = eye(5) - X*pinv(X'*X)*X';

fprintf('The matrix M is symmetric and idempotent. \n')
Q = M*M;
% format 8,4;
display(Q)
% ?;
display(M)

fprintf('The characteristic roots of a symmetric, idempotent matrix are ones and zeros \n')
fprintf('with the number of unit roots being its rank. \n')
% lam = eigrs(M);
[~, lam] = eig(M);
lam = diag(lam);
display(lam)

fprintf('Furthermore the trace of an idempotent matrix is also equal to its rank. \n')
sumc(diag(M));

fprintf('A.13 Quadratic Forms \n')
fprintf('A quadratic form in x is defined in (A.13.1). The sign of the quadratic form is \n')
fprintf('related to the characteristics of the matrix, A, as is illustrated in the following \n')
fprintf('section. \n')

fprintf('A.14 Definite Matrices \n')
fprintf('Definite matrices have many useful properties as listed here. These will be used \n')

fprintf('A.15 Kronecker Product of Matrices \n')
fprintf('The Kronecker product of two matrices is defined in (A.15.1). The GAUSS \n')
fprintf('operator .*. yields this product. \n')
A = [1 3; 2 0];
B = [2 2 0; 1 0 3];
C = kron(A, B);
display(C)

fprintf('Properties of this operator are listed in the text. Particularly useful is Equation \n')
fprintf('A.15.6. \n')

fprintf('A.16 Vectorization of Matrices \n')
fprintf('Vectorization of a matrix means that its columns are �stacked� one atop the \n')
fprintf('other as in (A.16.1). In GAUSS this can be accomplished using the RESHAPE \n')
fprintf('function. For example, use the matrix B in the previous section. \n')
vecb = reshape(B,6,1); % In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape(Data,N,T))' in GAUSS is equivalent to reshape(Data,T,N) in MATLAB
display(vecb)

fprintf('Note that the transpose of B was reshaped as this function reshapes the rows \n')
fprintf('of a matrix. Alternatively the GAUSS function VEC can be used. \n')
vecb = vec(B);
display(vecb)

fprintf('A.17 Vector and Matrix Differentiation \n')
fprintf('Useful rules for differentiation are given in this section. Take particular care to \n')
fprintf('understand the definitions of gradient, Jacobian and Hessian. \n')

fprintf('A.18 Normal Vectors and Multivariate Normal \n')
fprintf('Distribution \n')

fprintf('Transformations of multivariate normal random vectors play a large role in \n')
fprintf('statistics and are related to hypothesis testing and confidence interval estimation \n')
fprintf('in this book. Especially useful is Equation A.18.6 which gives the distribution \n')
fprintf('of linear transformations of multivariate normal random vectors. \n')

fprintf('A.19 Linear, Quadratic, and Other Nonlinear \n')
fprintf('Functions of Normal Random Vectors \n')
fprintf('This Section extends the results in A.18 to quadratic and linear forms in multivariate \n')
fprintf('normal random vectors. Chisquare, Student�s-t and the F- distribution \n')
fprintf('are defined and related. The gamma function is given by the GAUSS function \n')
fprintf('GAMMA. GAUSS also includes functions for the p.d.f. and c.d.f. of \n')
fprintf('N(0,1) random variables (PDFN & CDFN) as well as the complement of the \n')
fprintf('normal c.d.f. (CDFNC). Also provided, and useful for finding �p-values� are \n')
fprintf('complements to the distribution functions of the t (CDFTC), F (CDFFC) and \n')
fprintf('chi-square (CDFCC). \n')

fprintf('A.20 Summation and Product Operators \n')
fprintf('GAUSS provides functions that sum (SUMC) and multiply (PRODC) columns \n')
fprintf('of matrices. The factorial operator is the exclamation symbol �!�. \n')
fprintf('frequently throughout the text. \n')
