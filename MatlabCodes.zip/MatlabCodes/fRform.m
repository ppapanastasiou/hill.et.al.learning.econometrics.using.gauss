function out = fRform(c)
% local g, b;
g = -eye(3); % /* Gamma */
g([2 3],1) = c([1 2],1); % /* Equation 1 */
g(1,2) = c(4,1); % /* Equation 2 */
g(2,3) = c(9,1); % /* Equation 3 */
b = zeros(5,3); % /* Beta */
b(1,1) = c(3,1); % /* Equation 1 */
b(1:4,2) = c(5:8,1); % /* Equation 2 */
b([1 2 5],3) = c(10:12,1); % /* Equation 3 */
out = -b*pinv(g);
% endp;

return