function out = fAuto(b0)

global yl x xl

out = nan(rows(yl), cols(b0));
for i = 1: cols(b0)
    % local m1,m2,m3,m4,m5;
    m1 = yl .* b0(4,i);
    m2 = (x(:,1) .* b0(1,i)) + (x(:,2) .* b0(2,i))+ (x(:,3) .* b0(3,i));
    m3 = (xl(:,1) .* b0(1,i)) .* b0(4,i);
    m4 = (xl(:,2) .* b0(2,i)) .* b0(4,i);
    m5 = (xl(:,3) .* b0(3,i)) .* b0(4,i);
    % retp(m1+m2-m3-m4-m5);
    out(:,i) = m1+m2-m3-m4-m5;
end

return