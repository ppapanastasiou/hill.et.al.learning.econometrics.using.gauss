function ss = fSSdif(y, b)

if size(y,1) < size(y, 2)
    y = y';
end

if size(b,2) < size(b, 1)
    b = b';
end


T = length(y);
K = length(b);

y = kron(ones(1, K), y);
b = kron(ones(T, 1), b);

ss = sum((y - b).^2);

return