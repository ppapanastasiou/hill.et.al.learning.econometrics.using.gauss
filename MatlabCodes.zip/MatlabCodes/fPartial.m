function out = fPartial(y,maxk)

% local thetakk,t,k,yk,xk,thetak,tk;
y = y - meanc(y); % /* center data */
thetakk = zeros(maxk,1); % /* storage vector for estimates */
t = rows(y);
k = 1; % /* obtain estimate for 1st lag */
yk = y(k+1:t,1);
xk = y(k:t-1,1);
thetak = xk\yk;
thetakk(k,1) = thetak;
k = 2; % /* begin loop */
while k <= maxk;
    yk = y(k+1:t,1); % /* define yk */
    tk = t-k; % /* number of complete obs */
    xk = xk(1:tk,:); % /* delete last obs */
    xk = [y(k:t-1,1) xk]; % /* add lag */
    thetak = xk\yk; % /* OLS */
    thetakk(k,1) = thetak(k,1); % /* store coefficient */
    k = k+1;
end
% retp(thetakk);
out = thetakk;
% endp;

return