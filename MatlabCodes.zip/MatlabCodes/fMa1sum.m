function obj = fMa1sum(a,y)
% local t,obj,i,incr,k;
y = y - meanc(y); % */ /* center the data */
t = rows(y);

obj = 0; % /* initialize obj fn */
i = 1; % /* begin loop to sum over t */
while i <= t;
    incr = 0; % /* initialize increment */
    k = 1; % /* begin loop for summand */
    while k <= i;
        incr = incr + y(k,1).* a.^(i-k); % /* t�th term of Eq. 16.4.21 */
        k = k+1;
    end
    obj = obj + incr.^2; % /* Eq. 16.4.21 */
    i = i+1;
end
% retp(obj);
% endp;

return