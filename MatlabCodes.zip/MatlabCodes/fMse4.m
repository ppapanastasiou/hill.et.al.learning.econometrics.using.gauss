function mse=fMse4(beta, sigma2)

t = length(beta);

mse = 0*beta +sigma2/t +1;

return