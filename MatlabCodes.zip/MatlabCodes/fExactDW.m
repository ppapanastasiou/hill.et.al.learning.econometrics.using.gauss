% 9.6 Exact Durbin-Watson Statistic
% This program contains the code for the program DW.SET which compiles and
% loads the procedures to compute the exact Durbin-Watson critical value. If you
% type it into a file, it is usually best to save the file on the subdirectory
% \GAUSS\sp.
% The computations follow those outlined in J. Koerts and A. P. J. Abrahamse, On
% the Theory and Application of the General Linear Model, Rotterdam University
% Press, 1969, and in J. P. Imhof, �Computing the distribution of quadratic forms
% in normal variables,� Biometrika, 1961, Vol. 48, pages 419-426.
% /* DW.SET -- Loads and creates procedures to compute exact
% Durbin-Watson critical value */
% loadp intquad;
% loadp eigsym;

function val = fExactDW(dw,x,rho)
% local M,A,Psi,psih,t,w,C,D,A1,val,g;
t = rows(x);
% /* Creating psi - covariance matrix of disturbances */
w = seqa(0,1,t);
psi = repmat(rho.^w,1,t);
psi = shiftr(psi,w,0);

psi = psi + (psi - eye(t));
psi = psi/(1-rho.^2);
% /* Computing psi to the 1/2 using the
% Cholesky decomposition */
% psih = chol(psi);
psih = chol(abs(psi));
% /* Creating M */
M = eye(t) - (x*invpd(x'*x)*x');
% /* Creating A -- matrix with 2�s on diagonal,
% -1�s on off-diagonal, and 1�s at two corners */
A1 = [zeros(t-1,1) eye(t-1); zeros(1,t)];
A = eye(t)*2 - (A1 + A1');
A(1,1) = 1;
A(t,t) = 1;
% /* Computing roots */
C = psih*M;
D = C*(A - dw*eye(t))*C';
% L = eigsym(D,0);
[~, L] = eig(D);
L = diag(L);

% /* Integrating */
% val = .5 - (intquad(@fImhof,0,30,L',40))/pi;
val = .5 - (integral(@fImhof,0,30,L',40))/pi;
% retp(val);
% endp;
return

% loadp intquad;
% loadp eigsym;
function z = fImhof(u,Lp)
% local e,g,z;
% /* u is the variable to be integrated
% Lp is the transposed vector of eigenvalues */
e = (.5*sumc(arctan(Lp'.*u))) ;
g = exp(sumc(0.25*log( 1 + (Lp'.*u)^2 ))) ;
z = sin(e)./(u'.*g);
% retp(z�);
% endp;

return