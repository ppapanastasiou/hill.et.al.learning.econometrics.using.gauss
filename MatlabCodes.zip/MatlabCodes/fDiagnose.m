function table = fDiagnose(x,y)

global e

% local t,k,b,h,obs,selh,sighat2,sigt2,estar,se,stid,c,dfbeta,
% selbeta,selfits,sel,table;
t = rows(x);
k = cols(x);
b = x\y; % /* OLS */
% /* Calculate leverage values */

h = diag(x*invpd(x'*x)*x'); % /* Eq. 22.2.8 */
obs = seqa(1,1,t);
selh = (h >= 2*k/t); % /* Find large h values */
% /* Calculate Studentized residuals */
sighat2 = e'*e/(t-k);
sigt2 = (t-k)*sighat2/(t-k-1) - ((e.^2)/(t-k-1)) ./ (1-h); % /* Eq. 22.2.16 */
estar = e ./ sqrt(sigt2 .* (1-h)); % /* Eq. 22.2.15 */
selstud = (abs(estar) >= 2); % /* Find large values */
% /* Calculate DFBETAS */
c = pinv(x'*x)*x';

dfbeta = (c' .* kron(estar, ones(1,k)))./ sqrt( kron((1-h), diag(invpd(x'*x))')); % /* Eq. 22.2.18 */

dfbeta = dfbeta(:,2:k);
selbeta = abs(dfbeta) >= (2/sqrt(t)); % /* Find large values */
% /* Calculate DFFITS */
dffits = sqrt(h ./ (1-h)) .* estar; % /* Eq. 22.2.21 */
selfits = (abs(dffits) >= 2*(sqrt(k/t))); % /* Select lg. values */
% /* Find obs. with at least one significant diagnostic */
sel = [selh selstud selbeta selfits];
sel = sumc(sel');
sel = sel >= 1;
sel = selif(obs,sel);
table = [sel e(sel,:) estar(sel,:) h(sel,:) dfbeta(sel,:) dffits(sel,:)];
display('table')
disp(table)
% retp(table);
% endp;

return