function out = fSecondDerivative(beta)
global x2

out = 2*x2;
return