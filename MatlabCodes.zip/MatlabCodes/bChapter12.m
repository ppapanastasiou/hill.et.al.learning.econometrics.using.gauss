close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Define x and y as global variables')
global x y

fprintf('12.1 Introduction \n')
fprintf('This chapter deals with models that are intrinsically nonlinear. That is, they \n')
fprintf('are nonlinear in the parameters and there is no way to transform them to being \n')
fprintf('linear in the parameters. In such cases nonlinear least squares (NLS) and \n')
fprintf('maximum likelihood (ML) estimation techniques are appropriate, depending on \n')
fprintf('error assumptions. In both cases the first order conditions of the optimization \n')
fprintf('problem are nonlinear and thus numerical techniques are relied upon to minimize \n')
fprintf('the sum of squared errors or maximize the likelihood function. Thus in this \n')
fprintf('Chapter the numerical optimization techniques are presented and asymptotic \n')
fprintf('properties of the estimators stated. \n')

fprintf('12.2 Principles of Nonlinear Least Squares \n')
fprintf('Consider the problem of estimating the parameter in Equation (12.2.1) by nonlinear \n')
fprintf('least squares. LOAD the data from file TABLE12.1 on the disk with this \n')
fprintf('book and check it. \n')

load mDataTable12_1
dat = mDataTable12_1;
y = dat(:,1);
x = dat(:,[2 3]);
% format 8,4;
disp([y x])


fprintf('Write a PROC to calculate the values of the function (12.2.1), given that x is \n')
fprintf('in memory, for any value of the unknown parameter. Write a FUNCTION to \n')
fprintf('calculate the residual sum of squares rsq (12.2.2) again assuming that x is in \n')
fprintf('memory. \n')

fprintf('The reason for treating the functions differently is that the GAUSS functions \n')
fprintf('GRADP and HESSP, which calculate numerical first and second derivatives of a \n')
fprintf('function, take as arguments PROCs but not FUNCTIONs. We will demonstrate \n')
fprintf('the use of these functions in this chapter. \n')
fprintf('Plot the values of the sum of squares function, as in Figure 12.1 of the text, for \n')
fprintf('values of beta starting at -3. \n')
beta = seqa(-3,.1,56);
% library qgraph;
tmp = fRsq(beta);

fig1 = figure(1);
set(fig1, 'Color', 'white')
plot(beta, tmp, 'Color', 'black', 'LineWidth' , 3)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Figure 12.1 Residual sum of squares function for single parameter example';
% legend('RSS')
title(titel,'FontSize',10);
ylabel( 'S($\beta$)', 'FontSize', 10, 'Interpreter', 'latex');
xlabel( '$\beta$', 'FontSize', 10, 'Interpreter', 'latex');

fprintf('In order to use the Gauss-Newton algorithm to estimate the parameters we need \n')
fprintf('the derivative of the function with respect to the parameter as in (12.2.26). \n')
fprintf('Write a PROC to calculate that derivative assuming x is in memory. \n')


fprintf('Use the Gauss-Newton algorithm to estimate the parameter, using the initial \n')
fprintf('value of 4. Note that the stopping rule is based on the number of iterations or \n')
fprintf('convergence of the algorithm to a specified tolerance. The steps of the Gauss- \n')
fprintf('Newton algorithm are defined in Equation (12.2.29). \n')
b1 = -3;
crit = 1;
iter = 1;
% format 10,4;
while (iter <= 25) && (crit > 1e-8);
    fprintf('Iteration: %2.0f \n', iter);
    % iter b1 rsq(b1);
    % /* Equation 12.2.29 */
    tmp = (fDerv(b1)'*(y - fFnb(b1)) )/( fDerv(b1)'*fDerv(b1) );
    bn = b1 + tmp;
    crit = abs(bn - b1);
    b1 = bn;
    iter = iter + 1;   
end


fprintf('Try different starting values and note the different rates of convergence and \n')
fprintf('that the process converges to different points depending on the starting value \n')
fprintf('used. This should give ample warning that in nonlinear problems one must try \n')
fprintf('a variety of starting values to ensure that the global minimum of rsq is found. \n')
fprintf('Below is PROC NLSG which does nonlinear least squares estimation of a nonlinear \n')
fprintf('regression model. It takes as arguments the starting values b0; the righthand- \n')
fprintf('side of the regression model, E(y), which is passed as a PROC, &FI; the \n')
fprintf('analytic gradient vector which is also passed as a PROC, &GRAD, and the data \n')
fprintf('matrices x and y. \n')
fprintf('In addition it has a step-length adjustment which halves the step length until \n')
fprintf('no further reduction in the sum of squared errors is possible. \n')
fprintf('You should place this PROC in a file for future use and run it to place it in \n')
fprintf('memory. \n')

fprintf('Use PROC NLSG to estimate using the 4 starting values in Table 12.2. \n')
% {bn,z} = NLSG(4,&FNB,&DERV,x,y);
% {bn,z} = NLSG(-3,&FNB,&DERV,x,y);
% {bn,z} = NLSG(-1.05,&FNB,&DERV,x,y);
% {bn,z} = NLSG(-.9,&FNB,&DERV,x,y);
fprintf('The procedure returns not only the estimated parameter but also z. Thus we can calculate the estimate of the error variance. \n')

[bn,z] = fFNLSG(4,@fFnb, @fDerv, x, y);
[bn,z] = fFNLSG(-0.9,@fFnb, @fDerv, x, y);
[bn,z] = fFNLSG(-3,@fFnb, @fDerv, x, y);
[bn,z] = fFNLSG(-1.05,@fFnb, @fDerv, x, y);

[bn,z] = fFNLSG(4,@fFnb, @fDerv, x, y);
sighat2 = fRsq(bn)/(rows(y) - rows(bn));
display(sighat2)
fprintf('The asymptotic variance of the estimated parameter. \n')
varb = sighat2*invpd(z'*z);
display(varb)
fprintf('And construct a 95 percent confidence interval for the regression parameter beta \n')
interval = 1.96*sqrt(varb);
display(bn - interval)
display(bn + interval)
fprintf('This problem was relatively simple as the analytic gradient was easy to derive \n')
fprintf('and program. It will not always be so easy. The following PROC again obtains \n')
fprintf('NLS parameter estimates, but it calculates numerical gradients. In this version \n')
fprintf('the computation of the numerical derivative is shown explicitly, but the GAUSS \n')
fprintf('function GRADP could be used instead. Put PROC NLS in a file and run it to put in memory. \n')

fprintf('Now, repeat the nonlinear estimation of our model using PROC NLS for the same set of starting values. \n')
[bn,z] = fNLS(4, @fFnb, x, y);
[bn,z] = fNLS(-0.9, @fFnb, x, y);
[bn,z] = fNLS(-3, @fFnb, x , y);
[bn,z] = fNLS(-1.05, @fFnb, x, y);

fprintf('In sections 12.2.2 and 12.2.3 of ITPE2 the general multiple parameter nonlinear \n')
fprintf('regression model is presented and examples of Cobb-Douglas and CES production \n')
fprintf('functions given. LOAD the data for both examples from file TABLE12.3 \n')
fprintf('on the data disk and check it. \n')
% load dat[30,3] = table12.3;
load mDataTable12_3
dat = mDataTable12_3;
y = dat(:,3);
x = dat(:,[1 2]);
display([y x])
fprintf('Write PROC CD to calculate E(y) for the Cobb-Douglas production function \n')
fprintf('shown in Equation (12.2.45) for the given x data. PROC CD returns a (T x 1) vector. \n')

fprintf(' Write a PROC to calculate the gradient vector, Equation (12.2.47), for each of the data points. Note that this returns a (T x K) matrix.\n')

fprintf('Now estimate the parameters of the model using the starting values (1,0,0) and \n')
fprintf('using analytic derivatives. The results will be identical to those in the text \n')
fprintf('except for the estimate of the error variance. In Equation (12.2.43b) the text \n')
fprintf('uses (T - K) as the divisor, as we have, but the numerical results in the book use T as the divisor. \n')
b0 =[ 1 0 0]';
[b,z] = fFNLSG(b0, @fCD, @fGradCD, x, y);
fprintf('Repeat the exercise using numerical derivatives. \n')

[b,z] = fNLS(b0,@fCD,x,y);

fprintf('The second example in the text is the CES production function. Write a PROC \n')
fprintf('for E(y), Equation (12.2.53), and the gradient (12.2.54). Note that both PROCs assume that x is in memory. \n')


fprintf('As you can see, the process of deriving and programming the gradient vector \n')
fprintf('can become a sizable problem. Estimate the parameters of the CES production \n')
fprintf('function. The dependent variable is the natural log of y and take as starting values (1, .5, -1, -1). \n')
y = log(y);
b0 = [1 .5 -1 -1]';
[b,z] = fFNLSG(b0, @fCES, @fGradCES, x, y);

fprintf('Repeat the estimation using numerical derivatives. \n')
[b,z] = fNLS(b0, @fCES, x, y);
fprintf('In Section 12.2.4 the Newton-Raphson algorithm is introduced. It is a general \n')
fprintf('purpose optimization algorithm that uses first and second derivatives. The \n')
fprintf('algorithm is illustrated with the one parameter model in Equation (12.2.1). \n')
fprintf('LOAD the data from file TABLE12.1. \n')
load mDataTable12_1
dat = mDataTable12_1;

fprintf('Define x1 and x2 as global variables')
global x1 x2 

y = dat(:,1);
x = dat(:,[2 3]);
x1 = dat(:,2);
x2 = dat(:,3);

fprintf('Write functions to evaluate the function value, Equation 12.2.1, its first and second derivatives, and the sum of squared errors. \n')
% fn FNB(beta) = x1 .* beta + x2 .* (beta^2);
% fn DERV1(beta) = x1 + 2*beta*x2;
% fn DERV2(beta) = 2*x2;
% fn RSQ(beta) = sumc( (y - FNB(beta)).*(y - FNB(beta)) );

fprintf('Write a PROC that computes the parameter estimates using the Gauss-Newton first and then using the Newton-Raphson procedure. Put this PROC in a file and run it. \n')
fprintf('Now use PROC GNNR to replicate Table 12.4. Page 520 in ITPE2 \n')

[bn, iter, dRsq] = fGNNR(1);
[bn, iter, dRsq] = fGNNR(-2);
[bn, iter, dRsq] = fGNNR(0.1);
[bn, iter, dRsq] = fGNNR(-.9);

fprintf('12.3 Estimation of Linear Models with General \n')
fprintf('Covariance Matrix \n')
fprintf('In this section the general linear model is considered. Maximum likelihood and \n')
fprintf('nonlinear least squares estimators, as well as Bayesian techniques, are discussed \n')
fprintf('and applied to models of autocorrelation and heteroskedasticity. \n')
fprintf('The first example is given in Section 12.3.2 where a variety of estimators are \n')
fprintf('developed for the first-order autoregressive error model. LOAD the data in file \n')
fprintf('TABLE9.2 and examine it. This data was used first in Section 9.5.6. \n')
%load dat[20,3] = table9.2;

load mDataTable9_2
dat = mDataTable9_2;

fprintf('Define t k as global variables')
global t k

t = rows(dat);
y = dat(:,1);
x = [ones(t,1) dat(:,[2 3])];
k = cols(x);
% format 8,4;
disp([y x])
fprintf('Obtain the least squares estimates. \n')
b = x\y;
display(b)
fprintf('Write a PROC to obtain the estimate of rho in Equation (9.5.40). Note that \n')
fprintf('PROC NEWRHO, like many others in this section, assume that y and x are in \n')
fprintf('memory. If you try to run the proc before y and x are defined you will get an \n')
fprintf('error message, as GAUSS will assume they are uninitialized procs. \n')

fprintf('Run the PROC to load it into memory and use it to estimate rho. \n')
rhohat = fNewRho(b);
display(rhohat)
fprintf('Write a PROC to obtain the EGLS estimates of, the sum of squared errors and the transformed X matrix. \n')

fprintf('Use the PROC to obtain the EGLS parameter estimates and then the estimated covariance matrix. \n')
[bstar,sse,xstar] = fNewb(rhohat);
sighat2 = sse/(t - k);
covb = sighat2*invpd(xstar'*xstar);

fprintf('In Equations (12.3.35) - (12.3.37) are the approximate asymptotic covariance \n')
fprintf('matrices for the estimates of beta, sigma2 and rho. Use these to calculate �asymptotic \n')
fprintf('standard errors� and print out the results. Compare these results to the last row of Table 12.5. \n')

fprintf('bhat \n')
disp(bstar);
fprintf(' rhohat: %2.2f \n sighat2: %2.2f \n', rhohat, sighat2);
fprintf('bhat std.err: \n')
disp(sqrt(diag(covb)));
fprintf(' rhohat std.err: %2.2f\n sighat2 std.err: %2.2f \n', sqrt((1-rhohat^2)/t), sqrt(2*(sighat2^2)/t));

% "bhat rhohat sighat2 " bstar�;;rhohat;;sighat2;
% "std.err. " sqrt(diag(covb))�;;sqrt((1-rhohat^2)/t);;
% sqrt(2*(sighat2^2)/t);

fprintf('An alternative to EGLS is to apply NLS to Equation (12.3.28). This approach \n')
fprintf('discards the first observation which dramatically alters the estimates, despite \n')
fprintf('the fact that asymptotically it does not matter. Methods that retain the first \n')
fprintf('observation are more efficient in small samples and are preferred. But for comparison \n')
fprintf('purposes this is a useful exercise. First transform the data. \n')

fprintf('Define yl xl as global variables')
global yl xl

y = dat(2:t,1);
yl = dat(1:t-1,1);
x = [ones(t-1,1) dat(2:t,2:k)];
xl = [ones(t-1,1) dat(1:t-1,2:k)];
disp([y x])

fprintf('Write a PROC to calculate E(y) given initial values of beta and rho stacked into the vector b0. \n')
fprintf('Make sure that NLS is in memory, and use it to obtain estimates. \n')
b0 = [b;rhohat];
[b,z] = fNLS(b0,@fAuto,x,y);
fprintf('Compare these NLS estimates to those in Table 12.5 and you will see that they are substantially different. \n')
fprintf('In Equations (12.3.29) and (12.3.30) outline the Cochrane-Orcutt procedure. Write a PROC that uses this algorithm but retaining the first observation. \n')

fprintf('Reconstruct the original y and X. \n')
y = dat(:,1);
x = [ones(t,1) dat(:,2:k)];
t = rows(x);
k = cols(x);
fprintf('Use PROC CORC to obtain NLS estimates starting from several initial values of rho. \n')
[b,sse,covb] = fCorc(0);
[b,sse,covb] = fCorc(0.5);
[b,sse,covb] = fCorc(0.9);

fprintf('Compare these estimates to those in the first row of Table 12.5. \n')
fprintf('Maximum likelihood estimation of the parameters of this model can proceed in \n')
fprintf('several ways. In Equation (12.3.33) gives, except for constants, the expression \n')
fprintf('for the concentrated likelihood function, which is only a function of rho. One \n')
fprintf('possiblity is to search over values of rho and choose the value that maximizes \n')
fprintf('(12.3.33). To that end write a PROC that calculates this likelihood given a \n')
fprintf('value of rho and with y and X in memory. Note that this proc returns twice the \n')
fprintf('�elements� of the log-likelihood given in (12.3.10) and not the sum. \n')

fprintf('Note that this PROC returns a (T x 1) vector of components of the loglikelihood. \n')
fprintf('Search over the [0,1) interval first in units of .01. \n')
rhov = seqa(0,.01,100);
l = zeros(100,1);
iter = 1;
while iter <= 100;
    rho = rhov(iter,1);
    l(iter,1)=sumc(fAutolic(rho));
    iter = iter + 1;
end
fprintf('Find the value of rho corresponding to the maximum and then search in a finer \n')
fprintf('grid over the neighborhood about this value. \n')
rhoml = rhov(maxindc(l),1);
rhoml = rhoml - 0.1;
rhov = seqa(rhoml,.001,200);
l = zeros(200,1);
iter = 1;
while iter <= 200;
    rho = rhov(iter,1);
    l(iter,1) = sumc(fAutolic(rho));
    iter = iter + 1;
end
rhoml = rhov(maxindc(l),1);
% format 8,4;
display(rhoml)

fprintf('Once the maximum likelihood estimate of rho is obtained the ML estimates of beta can be found using PROC NEWB. \n')

[b,sse,xstar] = fNewb(rhoml);
sighat2 = sse/t;
fprintf('Since we will find the ML estimates in several ways, write a PROC to construct \n')
fprintf('and print out the final results with their asymptotic standard errors, given that \n')
fprintf('the estimates of beta, rho and sigma^2 have been stacked into a vector, param. \n')

fprintf('Use this PROC to print out final results for the ML estimates just obtained. \n')
param = [b; rhoml; sighat2];
covb = fAutocov(param);
display(covb)

fprintf('The search procedure is effective but potentially costly and does not ensure that \n')
fprintf('the global maximum of the likelihood function is obtained. Another alternative \n')
fprintf('is to maximize the Log-likelihood function using a general optimization procedure. \n')
fprintf('Several of these are described in Section 12.2.5 of the text. While it is \n')
fprintf('possible to obtain analytical expressions for the first and second derivatives it is \n')
fprintf('tedious to do so and then program them. Below is a ML procedure that uses the \n')
fprintf('method of Berndt-Hall-Hall-Hausman (BHHH) with numerical first derivatives. \n')
fprintf('It assumes y and X are in memory and initial estimates and the PROC defining \n')
fprintf('the �components � of the likelihood function are passed to it (NOTE: not the summed log-likelihood). \n')


fprintf('To use this general purpose algorithm we must write a PROC that defines \n')
fprintf('the components of the log-likelihood function of the first-order autoregressive \n')
fprintf('model. Its argument is the stacked vector of parameter values for beta, rho and then \n')
fprintf('sigma^2. PROC AUTOLI is fairly long, so place it in a convenient file and run it. \n')

fprintf('Set the initial parameter values and apply the proc. In general several sets \n')
fprintf('of starting values should be tried since the procedure may converge to a local \n')
fprintf('maximum or even a minimum of the log-likelihood function. \n')

b0 = [4 2 0.7 0.5 7]';
b = fMaxl(b0,@fAutoli,x,y);
covb = fAutocov(b);

fprintf('In Section 12.3.2c the principles of Bayesian methodology are applied to the \n')
fprintf('autocorrelation problem. The example used is based on the model and data \n')
fprintf('from Section 9.5.6. LOAD the data from that section and inspect the data. \n')
% load dat[20,3] = table9.2;

load mDataTable9_2;
dat = mDataTable9_2;
t = rows(dat);
k = cols(dat);

fprintf('Define nu as a global variable')
global nu

nu = t - k;
y = dat(:,1);
x = [ones(t,1) dat(:,[2 3])];
% format 8,4;
display([y x]);

fprintf('The �kernel� of the posterior p.d.f. for the autocorrelation parameter, rho, is given \n')
fprintf('in Equation 12.3.41. The normalizing constant is given in the form of an integral \n')
fprintf('in Equation 12.3.42. PROC RHOKERN calculates the value of kernel for a vector, \n')
fprintf('or matrix, of rho values. It uses PROC NEWB to calculate the EGLS estimator \n')
fprintf('of (bstar), the sum of squared errors (sse) and the transformed X matrix \n')
fprintf('(xstar). The PROC is written in a way such that it can be used by GAUSS�s \n')
fprintf('numerical integration function INTQUAD1. That is, the proc must return a \n')
fprintf('vector or matrix the same size as the single argument of the proc. See your \n')
fprintf('GAUSS manual for an example. Before you place RHOKERN in memory make \n')
fprintf('sure PROC NEWB is in memory or can be automatically loaded by GAUSS. \n')


fprintf('With RHOKERN in memory, carry out the integral in (12.3.42) and solve for the normalizing constant. \n')
% intord = 20;
xl = [1;-1];

fprintf('Define rhoconst as a global variable')
global rhoconst

% rhoconst = intquad1(&RHOKERN,xl);
rhoconst = integral(@fRhoKern,-1,1);
% rhoconst = quadgk(@fRhoKern,-1,1)
rhoconst = 1/rhoconst;
rhoconst;

fprintf('Given the normalizing constant, write PROC RHOPOST which returns the p.d.f. values given. \n')

fprintf('Graph the posterior p.d.f. for  as in Figure 12.5. \n')
rhovec = seqa(0,.01,100);
% library qgraph;
% xy(rhovec,fRhoPost(rhovec));

fig2=figure(2);
set(fig2, 'Color', 'white')
plot(rhovec, fRhoPost(rhovec), 'Color', 'black', 'LineWidth' , 3)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Figure 12.5 Posterior p.d.f. for $\rho$';
% legend('RSS')
title(titel,'FontSize',10, 'Interpreter', 'latex');
ylabel( '$ g(\rho | y) $', 'FontSize', 10, 'Interpreter', 'latex');
xlabel( '$\rho$', 'FontSize', 10, 'Interpreter', 'latex');

fprintf('The mean of the posterior distribution can be obtained using Equation 12.3.43. \n')
fprintf('Again we will use numerical integration. Write PROC RHOMU which takes rho as an argument and returns rho times the p.d.f. value. \n')

fprintf('Calculate the mean of the posterior distribution. \n')
% rhomean = intquad1(&RHOMU,xl);
rhomean = integral(@fRhoMu,-1,1);
% rhomean = quadgk(@fRhoMu,-1,1);
display(rhomean)
fprintf('To obtain the standard deviation of the posterior p.d.f. we will first calculate \n')
fprintf('the second moment (about the origin) of the p.d.f. in the same fashion as the first moment. \n')

fprintf('Calculate the standard deviation of the posterior distribution. \n')
% rhose = sqrt(intquad1(&RHOMU2,xl) - rhomean^2);
rhose = sqrt(integral(@fRhoMu2,-1,1) - rhomean^2);
% rhose = sqrt(quadgk(@fRhoMu2,-1,1) - rhomean^2);
display(rhose)
fprintf('Calculate the probability that rho falls in the interval [0.4, 1.0]. See page 537 ITPE2 \n')

xl = [1.0; 0.4];
% p = intquad1(&RHOPOST,xl);
% p = integral(@fRhoPost,0.4,1);
p = quadgk(@fRhoPost,0.4,1);
display(p)

fprintf('The next task is to obtain the posterior distribution for an individual parameter \n')
fprintf('value beta2. The kernel of the joint posterior is given in Equation 12.3.44. It is \n')
fprintf('a function of rho and beta2. PROC RB2KERN takes these arguments and returns the \n')
fprintf('value of the kernel. It must be written in such a way that it can be used by \n')
fprintf('the bivariate numerical integration function INTQUAD2. In particular it must \n')
fprintf('take arguments that are vectors or matrices and return the same. \n')

fprintf('Now use INTQUAD2 to obtain the normalizing constant. Let the limits of beta2 \n')
fprintf('be -1 to 4, which for practical purposes defines the real line. This will take a \n')
fprintf('few minutes to calculate. \n')
intord = 20;
rhol = [1;-1];
b2l = [4;-1];

fprintf('Define biconst as a global variable')
global biconst

biconst = integral2(@fRB2Kern,-1, 1, -1, 4);
display(biconst)


fprintf('Now write a procedure that calculates the value of the joint posterior as a \n')
fprintf('function of rho with beta2 in memory. The reason for this is that we will integrate \n')
fprintf('out rho, using INTQUAD1, to obtain the marginal posterior p.d.f. for beta2. \n')

fprintf('Define b2 as a global variable')
global b2 
b2 = 0;

fprintf('Create a vector of values of beta2 and calculate the corresponding values of the posterior p.d.f. \n')
b2vec = seqa(0,.035,100);
intord = 10;
pdfvec = 0 * b2vec;

i = 1;
while i <= rows(b2vec);
    b2 = b2vec(i);
    pdfvec(i) = integral(@fRB2Post, -1, 1);
    i = i + 1;
end

fprintf('Now graph the p.d.f. as in Figure 12.6. \n')
% xy(b2vec,pdfvec);

fig3 = figure(3);
set(fig3, 'Color', 'white')
plot(b2vec, pdfvec, 'Color', 'black', 'LineWidth' , 3)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Figure 12.6 Marginal posterior p.d.f for $\beta_2$';
% legend('RSS')
title(titel,'FontSize',10, 'Interpreter', 'latex');
ylabel( '$g(\beta_2|y)$', 'FontSize', 10, 'Interpreter', 'latex');
xlabel( '$\beta_2$', 'FontSize', 10, 'Interpreter', 'latex');

fprintf('To calculate the mean and variance of the posterior p.d.f. we will use Equation \n')
fprintf('12.3.45. Write PROC MOMB2 which takes rho as an argument and returns the \n')
fprintf('values of the EGLS estimates of beta2 weighted by the posterior p.d.f. of rho \n')

intord = 20;
rhol = 1|-1;
% meanb2 = intquad1(&MOMB2,rhol);
meanb2 = integral(@fMomb2,-1, 1);
fprintf('See page 538 of ITPE2 \n')
display(meanb2)

intord = 20;
rhol = 1|-1;

b2l = 4|-1;
meanb2 = integral2(@fMub2,-1, 1, -1, 4);
display(meanb2)
mom2 = integral2(@fMu2bu2,-1, 1, -1, 4);
display(mom2)
varb2 = mom2 - meanb2^2;
display(varb2)
seb2 = sqrt(varb2);
display(seb2)

fprintf('The second example given in Section 12.3 is that of the model of multiplicative \n')
fprintf('heteroskedasticity first presented in Section 9.3.4. \n')
fprintf('LOAD the data in file TABLE9.1 and check. \n')

load mDataTable9_1
dat = mDataTable9_1;
y = dat(:,1);
x = [ones(20,1) dat(:,[2 3])];

fprintf('Define z as a global variable')
global z
z = x(:,[1 2]);

disp([y x z]);

fprintf('To obtain the ML estimates we can once again use PROC MAXL. First write a \n')
fprintf('proc that returns the components of the log-likelihood function (12.3.48) given \n')
fprintf('a vector of parameter values for beta and alpha stacked into a vector. \n')

fprintf('Once the ML estimates are obtain the asymptotic standard errors can be obtained \n')
fprintf('from the inverse of the information matrix, which is given in Equation \n')
fprintf('(12.3.49) Write a proc to obtain those standard errors and put the covariance \n')
fprintf('matrices into global memory for later use. \n')

fprintf('As suggested on p. 540 of ITPE2 let the starting values be the EGLS estimates. \n')

param0 = [1.01 1.657 .896 -4.376 .366]';
param = fMaxl(param0,@fHeteroli,x,y);
display(param)
[covb, covalpha] = fHetercov(param);
display(covb)
display(covalpha)

fprintf('As an alternative to using a general optimization algorithm for ML estimation \n')
fprintf('it is sometimes possible to use the structure of the problem at hand to simplify \n')
fprintf('matters. This is true for the model under consideration as was noted by Harvey. \n')
fprintf('Equations (12.3.51) and (12.3.52) define iterations for the Method of Scoring \n')
fprintf('algorithm. Note the convergence criteria. \n')

fprintf('Use this proc with the same starting values to obtain ML estimates. \n')
param0 = [1.01 1.657 .896 -4.376 .366]'; % possible mistake here he meant to write -4.376 and not -4.346
param = fHarvey(param0);
fprintf('See page 540 of ITPE2. \n')
display(param)
[covb,covalpha] = fHetercov(param);
fprintf('In Section 12.3.4 asymptotic tests related to ML estimation are presented. They \n')
fprintf('are applied to the model of multiplicative heteroskedasticity in Section 12.3.4b. \n')

fprintf('The Wald statistic in Equation (12.3.93) is simply the square of the asmptotic-t \n')
fprintf('statistic in this case. \n')

fprintf('See page 549 of ITPE2. \n')
wald = (param(5,1) / sqrt( covalpha(2,2) ) )^2;
display(wald) 
disp(chi2cdf(wald,1, 'upper'));

fprintf('The likelihood ratio test is given in Equation (12.3.102). \n')
fprintf('See page 551 of ITPE2. \n')

t = rows(x);
b = x\y;
sig02 = (y - x*b)'*(y - x*b)/t;
lr = t*log(sig02) - sumc(z*param([4 5],:));
display(lr) 

fprintf('12.4 Nonlinear Seemingly Unrelated Regression Equations \n')
fprintf('In this Section the nonlinear SUR model is considered and maximum likelihood \n')
fprintf('estimation of the concentrated likelihood function, Equation 12.4.9, described. \n')
fprintf('As an example of such a model a linear expenditure system. The data used is \n')
fprintf('that in file TABLE11.3 which contains T = 30 observations on the prices of 3 \n')
fprintf('commodities, income and quantities of the commodities. LOAD the data and \n')
fprintf('check it. \n')
% load dat[30,7] = table11.3;

load mDataTable11_3
dat = mDataTable11_3;

fprintf('Define p as a global variable')
global p
p = dat(:,1:3);
y = dat(:,4);
q = dat(:,5:7);
fprintf('Define v as a global variable')
global v
v = p.*q;

% format 10,5;
disp([p y q]);
fprintf('In order to maximize the concentrated likelihood function we will use the Newton- \n')
fprintf('Raphson algorithm, as described in Equation 12.2.89. The matrix of second \n')
fprintf('partial derivatives will be approximated with numerical second derivatives using \n')
fprintf('the GAUSS function HESSP, and numerical first derivatives using GRADP. \n')
fprintf('The arguments of PROC MAXM are a set of initial estimates, b0, and PROC \n')
fprintf('SURLI that defines the value (a scalar) of the objective function. This proc is \n')
fprintf('long so place it in a separate file and run it. Note that this proc assumes that \n')
fprintf('X and y are in memory. In other respects PROC MAXM is much like PROC \n')
fprintf('MAXL. \n')

fprintf('Write a PROC that produces the value of the concentrated likelihood function \n')
fprintf('for the first two of the equations in (12.4.13) (since the 3 equations are linearly \n')
fprintf('dependent.)\n')

fprintf('Using the initial values suggested on p. 555 of ITPE2, obtain the ML parameter \n')
fprintf('estimates. Note that the standard errors returned by MAXM are based on the \n')
fprintf('numerical second derivaties. \n')
b0 = [2.903 1.360 13.251 0.20267 .13429]';
b = fMaxm(b0,@fSurli);

fprintf('12.5 Functional Form � The Box-Cox Transformation \n')
fprintf('In this Section maxmimum likelihood estimation of the regression and transformation \n')
fprintf('parameters of the Box-Cox model is discussed. What follows is a series \n')
fprintf('of PROCs that implement these ideas. The first is PROC BCT which carries out \n')
fprintf('the transformation in Equation (12.5.3) of the text, given the matrix Z containing \n')
fprintf('the data to transform and the parameter lambda which is either a scalar or \n')
fprintf('a vector which is conformable to z. \n')

fprintf('Next, is PROC BOXCOX. Its arguments are a set of initial parameter values for \n')
fprintf(' beta, lambda and sigma^2, in that order. PROC BOXCOX returns the T components of the \n')
fprintf('log-likelihood function in Equation (12.5.10) in a (T x 1) vector. It assumes \n')
fprintf('that y and X are in memory as well as a (T x 1) vector of ones, j. Thus, before \n')
fprintf('proceeding, LOAD the data in TABLE12.7 and check it. \n')
% load dat[40,3] = table12.7;
load mDataTable12_7
dat = mDataTable12_7;
x = dat(:,[1 2]);
y = dat(:,3);
fprintf('Define j as a global variable \n')
fprintf('j is a (T x 1) vector of ones \n')
global j
j = ones(40,1);
disp([x y]);

fprintf('Now enter PROC BOXCOX and run it. \n')

fprintf('Assume that the transformation parameter lambda is the same for all the variables. \n')
fprintf('Use the starting values given at the top of p. 560 and the BHHH algorithm \n')
fprintf('MAXL to obtain ML estimates. Make sure that MAXL is in memory. \n')
b0 = [3 1 1 1 1.5]';
b = fMaxl(b0,@fBoxcox,x,y);

fprintf('Compare these estimates to those in Table 12.8 which assume the same lambda. \n')
fprintf('The standard errors reported by MAXL are based on the BHHH approximation \n')
fprintf('to the Hessian and using only first derivatives. Thus they are an approximation \n')
fprintf('to the �Unconditional Standard Errors� reported in the text and, as you can \n')
fprintf('see, not terribly close. ITPE2 cites the text by Fomby, Hill and Johnson, which \n')
fprintf('contains a discussion of the difference between conditional and unconditional \n')
fprintf('standard errors. The conditional standard errors assume that the transformation \n')
fprintf('parameter lambda is known, and not estimated, and are thus based on the covariance \n')
fprintf('matrix in Equation (12.5.15) for beta. Compute these conditional standard \n')
fprintf('errors for the estimates of betabased on the ML estimates. \n')

fprintf('See page 562 of ITPE2. \n')

xlam = [j fBct(x, .779)];
covb = 1.24 * invpd(xlam'*xlam);
std = sqrt(diag(covb));
display(std)

fprintf('The conditional standard error reported for sigma^2 is based on its usual ML estimate \n')
fprintf('of the variance. \n')

fprintf('See page 562 of ITPE2. \n')

varsig2 = 2*(1.24^2)/40;
std = sqrt(varsig2);
display(std)

fprintf('In order to generalize the procedure to allow different lambdas on each of the variables \n')
fprintf('enter the following procedure into a file and run it. It calculates the T elements \n')
fprintf('of the Concentrated likelihood function in Equation (12.5.19). The PROC takes \n')
fprintf('as argment a vector, lam0, that contains initial values for the transformation \n')
fprintf('parameters for y and the (K - 1) regressors in X, in that order. Once again, it is \n')
fprintf('assumed that y, x, and j are in memory. Note that it places into global memory \n')
fprintf('OLS estimates b and sigmasq as well as the transformed X matrix which will \n')
fprintf('be used in the next step using the GAUSS command CLEARG. \n')


fprintf('Given the initial values of lambda and estimates for beta and sigma^2, the maximum likelihood \n')
fprintf('estimates of lambda can be obtain and then the ML estimates of beta and sigma^2. However, \n')
fprintf('so that approximate unconditional standard errors for all parameters can be \n')
fprintf('obtained the proc below, BOXCOX3, obtains the full likelihood for this model as \n')
fprintf('given exactly in Equation 12.5.19 given a set of parameters p0 that contains \n')
fprintf('estimates of beta, lambda, and sigma^2, in that order. \n')

fprintf('Finally we are ready to put it all together. Our strategy will be to use MAXL \n')
fprintf('to obtain ML estimates of lambda given some initial estimates. Then these ML \n')
fprintf('estimates and the corresponding ML estimates for beta and sigma^2 will used to calculate \n')
fprintf('the value of the full likelihood function which is fed into GRADP. Given the \n')
fprintf('numerical values of the first derivatives the BHHH approximation to the Hessian \n')
fprintf('is computed and approximate unconditional standard errors computed. All \n')
fprintf('these steps are summarized in PROC BOXFULL. It takes as argument only the \n')
fprintf('initial values for lambda that BOXCOX2 uses. \n')

fprintf('Make sure all the procs are loaded into memory. Set the initial values of the \n')
fprintf('parameters lambda to one and estimate the full model. \n')

fprintf('See page 562 of ITPE2. \n')

lam0 = [1 1 1]';
p = fBoxfull(lam0);

fprintf('As you can see the numerical approximations to the unconditional standard \n')
fprintf('errors are different from those in the text. To obtain the conditional standard \n')
fprintf('errors we proceed as before. \n')

fprintf('See page 562 of ITPE2. \n')

xlam = [j fBct(x,[-1.536 .391]')];
covb = 2.876 * invpd(xlam'*xlam);
std = sqrt(diag(covb));
display(std)
varsig2 = 2*(2.876^2)/40;
std = sqrt(varsig2);
display(std)




