function out = fTobiTi(p0)

global x

% local k1,b,sig,z,pdf,cdf,a,b,c;
k1 = rows(p0); % /* sort out estimates */
b = p0(1:k1-1,1);
sig = sqrt(p0(k1,1));
z = (x*b)./sig; % /* argument of std. normal */
pdf = normpdf(z); % /* f */
cdf = normcdf(z); % /* F */
% /* write a, b, c as column vectors */
a = -(z.*pdf - pdf.^2 ./(1-cdf) -cdf) ./(sig.^2);
b = ((z.^2 .* pdf)+pdf-(z .* pdf.^2)./(1-cdf))./(2*sig.^3);
c = -((z.^3 .* pdf)+z.*pdf-((z.^2) .* pdf.^2)./(1-cdf)-2*cdf)./(4*sig.^4);
% /* construct the components of (19.3.8) */
a = (x.*repmat(a, 1, cols(x)))'*x;
b = sumc(x.*repmat(b, 1, cols(x)));
c = sumc(c);
out = [a b; b' c];

% retp( (a~b)|(b�~c) );
% endp;

return