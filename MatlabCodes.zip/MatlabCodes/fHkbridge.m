function [bridge,covridge]= fHkbridge(x,y)

% local *;
t = rows(x); % /* Standardize X and y */
k = cols(x);
xs = x(:,2:k);
xc = xs - repmat(meanc(xs), rows(xs), 1);
ssq = diag(xc'*xc);
vStd = sqrt(ssq);
xc = xc ./ repmat(vStd', rows(xc), 1);
corr = xc'*xc;

yc = y - repmat(meanc(y), rows(y), 1);
bc = xc\yc; %/* OLS */
sighat2 = (yc - xc*bc)'*(yc - xc*bc)/(t-k);
khat = (k - 1)*sighat2 ./ (bc'*bc); % /* Eq. 21.4.12 */
bridge = pinv(corr + khat .* eye(k-1)) * xc'*yc;
% /* Eq. 21.4.13 */
q = pinv(corr + khat .* eye(k-1));
covridge = sighat2 .* q * corr * q; % /* Eq. 21.4.4 */
w = diagrv(eye(k-1),1 ./ vStd); % /* W-inv */
bridge = w*bridge; % /* Unstandardize */
covridge = w*covridge*w;
stderr = sqrt(diag(covridge));

display('HKB-noniterative Ridge Estimator') % /* Print */
% ?;
display('khat : ') 
disp(khat)
display('Est : ') 
disp(bridge')
display('Std. Err. : ') 
disp(stderr')

crit = 1; % /* define constants */
kold = khat;
iter = 1;
while (crit > 1e-6) && (iter < 20); % /* begin loop */
    khat = (k-1) * sighat2 ./ (bridge'*bridge);
    crit = abs(khat - kold);
    bridge = pinv(corr + khat .* eye(k-1)) * xc'*yc;
    kold = khat;
    iter = iter + 1;
end

q = pinv(corr + khat .* eye(k-1));
covridge = sighat2 .* q * corr * q; % /* Eq. 21.4.4 */
w = diagrv(eye(k-1),1 ./ vStd); % /* Unstandardize */
bridge = w*bridge;
covridge = w*covridge*w;
stderr = sqrt(diag(covridge));

display('HKB-iterative Ridge Estimator') % /* Print */
% ?;
display('khat : ') 
disp(khat)
display('Est : ') 
disp(bridge')
display('Std. Err. : ') 
disp(stderr')
% retp(bridge,covridge);
% endp;

return