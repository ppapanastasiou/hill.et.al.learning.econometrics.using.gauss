function mse=fMse2(beta, sigma2)

t = length(beta);

mse = 0.*beta +sigma2./t;

return