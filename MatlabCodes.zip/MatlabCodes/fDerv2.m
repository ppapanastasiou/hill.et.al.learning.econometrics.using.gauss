function dOut = fDerv2(p)

dOut = 2-6.*p;

return