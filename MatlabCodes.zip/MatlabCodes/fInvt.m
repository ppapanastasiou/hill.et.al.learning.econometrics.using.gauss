function tstat=fInvt(df,alpha)
tstat = 0.995 + 0.005*minindc(abs( tcdf(seqa(1,.005,500),df, 'upper') - alpha));

return