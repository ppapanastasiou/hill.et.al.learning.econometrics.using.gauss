function mse=fMse1(beta, bbar)

mse = (beta - bbar).^2;

return