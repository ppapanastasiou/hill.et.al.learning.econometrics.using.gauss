function out = fFnb(beta)

global x

out = x(:,1) .* beta + x(:,2) .* (beta.^2);

return