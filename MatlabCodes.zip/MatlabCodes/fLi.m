function wLg = fLi(y, beta, t, iAlternative)

if (nargin<4 || isempty(iAlternative))
    iAlternative=0;
end

% Note that this could also be written as: function wLg(i) = sum(log(normpdf(y - dBeta)));

[iRowsY, iColsY] =size(y);
if iRowsY ~=1 && iColsY ~=1;
    error('y is not a vector')
end

[iRowsBeta, iColsBeta] =size(beta);
if iRowsBeta ~=1 && iColsBeta ~=1;
    error('beta is not a vector')
end

if size(y,1)==1
    y =y';
    fprintf(' transpose y so it is a column vector \n')
end

if size(beta,2)==1
    beta =beta';
    fprintf(' transpose beta so it is a row vector \n')
end

T = length(y);
K = length(beta);

beta = kron(ones(T,1), beta);
y = kron(ones(1,K), y);

if iAlternative == 0
    wLg = -(t/2)*log(2*pi) - 0.5*sum((y - beta).^2);
elseif iAlternative == 1
    wLg = sum(log(normpdf(y - beta)));
else
    error('Wrong Alternative Input')
end

% Non vectorized form
% K = length(beta);
% 
% wLg =zeros(1, K);
% for i = 1: length(beta)
%     if iAlternative == 0
%         dBeta =beta(i);
%         wLg(i) = -(t/2)*log(2*pi) - 0.5*sum((y - dBeta).^2);
%     elseif iAlternative == 1
%         dBeta =beta(i);
%         wLg(i) = sum(log(normpdf(y - dBeta)));
%     else
%         error('Wrong Alternative Input')
%     end
% end

return