function chi=fInvchi(df,alpha) 

chi=0.95 + 0.05*minindc(abs(chi2cdf(seqa(1,.05,2000),df,'upper')- alpha));

return