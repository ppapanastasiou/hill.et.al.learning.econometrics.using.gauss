close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 17 \n')
fprintf('Distributed Lags \n')

fprintf('17.1 Introduction \n')
fprintf('When using time series data there is often a time lag between an event and \n')
fprintf('its effect. Furthermore the impacts of an event may be spread over more than \n')
fprintf('one future time period. Models that take these factors into account are called \n')
fprintf('distributed lag models. In this chapter finite lag models and infinite lag models \n')
fprintf('are considered. Finite lags reflect the assumption that the future effects of an \n')
fprintf('event are exhausted in a specific, or finite, time period. Infinite lags assume \n')
fprintf('that the effect of the event is spread over an infinite horizon. \n')

fprintf('17.2 Unrestricted Finite Distributed Lags \n')
fprintf('For finite distributed lags it is common practice to use the data to help select \n')
fprintf('the length of the lag. In file TABLE17.1 is a data set on quarterly capital \n')
fprintf('appropriations (x) and expenditures (y). LOAD the data and examine it. \n')

% load dat[88,2]= table17.1;
load mDataTable17_1
dat = mDataTable17_1;
yvec = dat(:,1);
display(yvec)
xvec = dat(:,2);
display(xvec)

fprintf('Note that observation 42 on y is different than in the text. We will use this \n')
fprintf('data as it is the basis of the calulations in the text. \n')
fprintf('Following the example in the text, page 725, assume that the maximum lag \n')
fprintf('length to be considered is M = 10. Construct the y vector, beginning with \n')
fprintf('observation M + 1. \n')
t = rows(xvec);
m = 10;

y = yvec(m+1:t,1);
fprintf('In order to construct Table 17.2 in the text we will begin construction of the \n')
fprintf('X matrix in Equation 17.2.4 assuming that the lag length is zero and then add \n')
fprintf('columns as the lag length increases to its maximum of 10. The design matrix is \n')
fprintf('initially a column vector of ones representing the equation intercept. As the lag \n')
fprintf('length is increased calculate the statistics in Table 17.2 using PROC LAGSTAT, \n')
fprintf('below, and store them in a storage matrix, store. Execute the procedure to \n')
fprintf('place it in memory. \n')


fprintf('Now construct an X matrix consisting of a (T - M) x 1 column of ones and \n')
fprintf('create the storage matrix. \n')
x = ones(t-m,1);
store = zeros(m+1,5);

fprintf('Write a DO-LOOP within which the values in Table 17.2 are calculated for lag \n')
fprintf('lengths n = 0,...,M = 10. \n')
n = 0;
while n <= m;
    x = [x xvec(m-n+1:t-n,1)];
    [sse, sig2, aic, sic] = fLagStat(y,x);
    store(n+1,:) = [n sse sig2 aic sic];
    n = n + 1;
end

fprintf('Print the matrix store and compare to Table 17.2. \n')
% format 14,9;
% "--------n-------------sse----------sighat2---------aic----------sic";
display('           n      sse             sighat2           aic           sic')
disp(store)

fprintf('Calculate the sequential test statistics given in Equation 17.2.7 and used as a \n')
fprintf('basis for determining the lag length. Carry out each test at the .05 level of \n')
fprintf('significance and stop the testing process once a hypothesis is rejected. The lag \n')
fprintf('length is the last value tested but not rejected as zero. \n')

sse = store(2:11,2);
sighat2 = store(2:11,3);
test = 1;
pval = 1;
while pval > .05;
    n = m - test;
    lam = (sse(n,1) - sse(n+1,1))/sighat2(n+1,1);
    pval = fcdf(lam,1,t-(n+2), 'upper');
    display([n lam pval])
    test = test + 1;
end

fprintf('Compare these results to those on page 725. On the basis of these tests the lag \n')
fprintf('length is chosen to be N = 8. Given this lag length, obtain the OLS parameter \n')
fprintf('estimates of the distributed lag weights, correcting the sample size to T - N. \n')
nhat = 8; % /* lag length */
t = rows(yvec);
y = yvec(nhat+1:t,1); % /* specify y */
x = ones(t-nhat,1); % /* construct X */
n = 0;

while n <= nhat;
    x = [x xvec(nhat-n+1:t-n,1)];
    n = n + 1;
end
k = cols(x);
t = rows(x);
b = x\y; % /* OLS */
sighat2 = (y-x*b)'*(y-x*b)/(t - k);
covb = sighat2*pinv(x'*x);
stderr = sqrt(diag(covb));
display(b)
display(stderr)

fprintf('In comparing these results to those in Equation 17.2.9 note that there are some \n')
fprintf('differences in the estimates. This is due to roundoff error resulting from the \n')
fprintf('highly multicollinear nature of the explanatoray variables in this regression. \n')
fprintf('The topic of multicollinearity is explored in Chapter 21. \n')

fprintf('17.3 Finite Polynomial Lags \n')
fprintf('One way to deal with the inherent multicollinearity in the finite distributed lag \n')
fprintf('model is to impose some structure on the lag weight distribution. A popular \n')
fprintf('and easily implemented alternative is to assume that the lag weights fall on \n')
fprintf('a polynomial of some low degree, implying that the lag weight distribution is \n')
fprintf('�smooth�. \n')

fprintf('To extend the example in the previous section, let the lag length be specified \n')
fprintf('as eight. Furthermore, for simplicity, follow the text and assume that the yintercept \n')
fprintf('is zero. Call the X matrix excluding the intercept column xdot. \n')
xdot = x(:,2:cols(x));

fprintf('The maximum degree polynomial to be considered is Q = 8 since a polynomial \n')
fprintf('of degree 8 will fit exactly the N + 1 = 9 lag parameters. The polynomial \n')
fprintf('coeffiecients are related to the lag weights by Equation 17.3.1 in the text. \n')
fprintf('If Q = N the matrix is square and nonsingular, implying that no real restrictions \n')
fprintf('are placed on the lag weights in this case. The lag weights will be restricted \n')
fprintf('to fall on lower and lower polynomial degrees as the higher order polynomial \n')
fprintf('coefficients are set to zero, which also reduces the column dimension of the \n')
fprintf('matrix hq. To begin construct the matrix hq with Q = N = 8 \n')
nvec = seqa(0,1,nhat+1);
qvec = seqa(0,1,nhat+1);
hq = repmat(nvec, 1, length(qvec)).^(repmat(qvec', length(nvec), 1));

fprintf('We will sequentially test the hypotheses in Equation 17.3.7 using the test statistic \n')
fprintf('(17.3.8). To implement the test calculate the sum of squared errors SSEN,Q \n')
fprintf('in (17.3.9) and the estimated error variance hat(sigma)^2_N,Q for Q = N,N ? 1, . . . , 0, and \n')
fprintf('retain the values in a matrix store. \n')

store = zeros(nhat+1,3);
test = 0;
while test <= nhat;
    q = nhat - test; % /* polynomial degree */
    z = xdot*hq(:,1:q+1); % /* Z as in Eq. 17.3.3 */
    ahat = z\y; % /* OLSE of alpha */
    sse = (y - z*ahat)'*(y - z*ahat); % /* sse */
    sighat2 = sse/(t-q-1); % /* sighat2 % */
    store(test+1,:)=[q sse sighat2]; % /* Store values */
    test = test + 1;
end

fprintf('Calculate the value of the test statistic in Equation 17.3.8 for each of the tests \n')
fprintf('in (17.3.7). The numerator is the difference between the SSE for the more \n')
fprintf('restricted model less that of the less restricted model. The denominator is the \n')
fprintf('estimated error variance from the less restricted model. For each F-test one \n')
fprintf('restriction is imposed and is based on T ? (Q + 1) degrees of freedom. \n')
% /* Eq. 17.3.8 */
lam = (store(2:nhat+1,2) - store(1:nhat,2))./ store(1:nhat,3);
df1 = ones(8,1); % /* numerator df */
i = seqa(1,1,8);
q = nhat - i;
df2 = t - (q + 1); % /* denominator df */
% format 8,4; /* print results */
display('          i             q            F-stat         p-value') 
disp([i q lam fcdf(lam,df1,df2, 'upper')])

fprintf('Based on these tests we would choose a polynomial of degree Q = 3 for the lag \n')
fprintf('weights. To give an idea of the shapes imposed on the lag weight distributions \n')
fprintf('calculate the unrestricted lag weights, and those for the second and third degree \n')
fprintf('polynomials, and plot them as in Figure 17.3. First, the unrestricted estimates \n')
fprintf('are simply the least squares parameter estimates of Equation 17.2.9 excluding \n')
fprintf('the intercept. \n')
b0 = xdot\y;

fprintf('The estimates falling on the third degree polynomial are found by estimating \n')
fprintf('Equation 17.3.3 with 4 columns (Q + 1) retained in Z and then making the \n')
fprintf('transformation in Equation 17.3.4 to obtain the estimates of the lag weights. \n')
a3 = (xdot*hq(:,1:4))\y;
b3 = hq(:,1:4)*a3;

fprintf('The estimates for the second degree polynomial are based on (17.3.3) with 3 \n')
fprintf('columns of Z retained and then the transformation to the lag weights. \n')
a2 = (xdot*hq(:,1:3))\y;
b2 = hq(:,1:3)*a2;

fprintf('Plot the lag weights against the values i = 0, . . . , 10. \n')
% library qgraph;
% xy(nvec,b0~b2~b3);

fig1 = figure(1);
set(fig1, 'Color', 'white')
plot(nvec, [b0 b2 b3], 'Color', 'black', 'LineWidth' , 3)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
% titel='Plot of the data in Table 16.1';
% legend('RSS')
% title(titel,'FontSize',10);
% ylabel( '$y_t$', 'FontSize', 14, 'Interpreter', 'latex');
% xlabel( 't', 'FontSize', 12);

fprintf('To obtain estimated standard errors of the estimated lag weights estimate the \n')
fprintf('error variance from the residuals from (17.3.3) corresponding to the third degree \n')
fprintf('polynomial. \n')

q = 3;
hq3 = hq(:,1:q+1);
z = xdot*hq3;
sighat2 = (y - z*a3)'*(y - z*a3)/(t - q - 1);

fprintf('Obtain the estimated covariance matrix of the polynomial coefficients. \n')
cova3 = sighat2*invpd(z'*z);

fprintf('Then use Equation 17.3.6 to obtain the covariance matrix of the estimated lag \n')
fprintf('weights. Then construct standard errors, t-statistics and p-values. \n')
covb3 = hq3*cova3*hq3';
stderr = sqrt(diag(covb3));
tstat = b3 ./ stderr;
pval = 2*tcdf(tstat,t-q-1, 'upper');
display(b3)
display(stderr)
display(tstat)
display(pval)

fprintf('Compare these results to the unrestricted OLS results. \n')
sighat2 = (y - xdot*b0)'*(y - xdot*b0)/(t - cols(xdot));
covb0 = sighat2 * invpd(xdot'*xdot);
stderr = sqrt(diag(covb0));
tstat = b0 ./ stderr;
pval = 2*tcdf(tstat,t-cols(xdot), 'upper');
display(b0)
display(stderr)
display(tstat)
display(pval)

fprintf('17.4 Infinite Distributed Lags \n')
fprintf('In this Section an infinite distributed lag model is described. The statistical \n')
fprintf('model for the geometric lag is given in Equation 17.4.12. To illustrate estimation \n')
fprintf('of this model we will follow the text and generate 5 samples of data using \n')
fprintf('parameter values in Equation 17.4.19. First read 100 random n(0,1) values from \n')
fprintf('the official random numbers contained in the file NRANDOM.DAT to be used \n')
fprintf('as the observations on X and then read an additional 500 values to constitute \n')
fprintf('5 samples of size 100 on the random disturbance U. \n')
% open f1 = nrandom.dat;
% xvec = readr(f1,100);
% u = readr(f1,500);
% f1 = close(f1);
% u = reshape(u,5,100)';
load nrandom200
xvec = nrandom200(1:100);
u = randn(500,1);
u = reshape(u,5,100)';

fprintf('Create a (100 x 5) matrix of zeros that will contain the y-values. \n')
y = zeros(100,5);

fprintf('The first observation on y, using (17.4.19), depends on the values of y and u \n')
fprintf('in the time period zero. Assume that these �pre-sample� values are zero and \n')
fprintf('construct the first observation on y, for all 5 samples. \n')
y(1,:) = xvec(1,1) + u(1,:);

fprintf('For observations 2,...,100 use Equation 17.4.19 to generate the values of y. \n')
obs = 2;
while obs <= 100;
    y(obs,:) = xvec(obs,:) + 0.5*y(obs-1,:) + u(obs,:) - 0.5*u(obs-1,:);
    obs = obs + 1;
end

fprintf('The estimators of the model�s parameters will be the least squares estimator, \n')
fprintf('Equation 17.4.13, the instrumental variable estimator (17.4.17) and the maximum \n')
fprintf('likelihood estimator described in Section 17.4.2c. First we will consider \n')
fprintf('the use of OLS and the instrumental variables estimator. In each case only \n')
fprintf('the complete observations will be used. This means that each sample �begins� \n')
fprintf('with observation 2. We will obtain estimates for samples of size 20, 50, and 100 \n')
fprintf('within a DO-LOOP for each sample 1 through 5. Also, for the present assume \n')
fprintf('that the model�s intercept is known to be zero. \n')

nsam = 1; % /* begin do-loop % */
while nsam <= 5;
    x = [xvec [0; y(1:99,nsam)]]; % /* full X matrix */
    b20 = x(2:20,:)\y(2:20,nsam); % /* OLS on 20 obs */
    b50 = x(2:50,:)\y(2:50,nsam); % /* OLS on 50 obs */
    b100 = x(2:100,:)\y(2:100,nsam);% /* OLS on 100 obs */
    z = [xvec [0;xvec(1:99,:)]]; % /* full instrument */
    % /* matrix in 17.4.18 */
    z20 = z(2:20,:); %/* IV on 20 obs */
    biv20 = pinv(z20'*x(2:20,:))*z20'*y(2:20,nsam);
    z50 = z(2:50,:); % /* IV on 50 obs */
    biv50 = pinv(z50'*x(2:50,:))*z50'*y(2:50,nsam);
    z100 = z(2:100,:); % /* IV on 100 obs */
    biv100 = pinv(z100'*x(2:100,:))*z100'*y(2:100,nsam);
    % "sample" nsam; % /* Print results */
    disp([b20;biv20]');
    disp([b50;biv50]');
    disp([b100;biv100]');
    nsam = nsam + 1;
end

fprintf('Compare these results to the OLS and IV estimates in Table 17.4. Before obtaining \n')
fprintf('ML estimates, carry out a Monte Carlo experiment comparing the OLS \n')
fprintf('and IV estimation procedures. We will use the GAUSS random number generator \n')
fprintf('for this exercise, so the histogram results we obtain will not be identical \n')
fprintf('to those in Figures 17.4 and 17.5, but they will be similar. Essentially we will \n')
fprintf('simply repeat the steps carried out above for 100 samples instead of 5 and collect \n')
fprintf('all the results. The data generation will be carried out in sets of 50 samples \n')
fprintf('each because of the storage limits of personal computers. \n')

% open f1 = nrandom.dat; % /* create X
% xvec = readr(f1,100);
% f1 = close(f1);

load nrandom200
xvec = nrandom200(1:100,1);

y1 = zeros(100,50); % /* storage matrices */
y2 = zeros(100,50);
u1 = randn(100,50); % /* random numbers */
u2 = randn(100,50);
y1(1,:) = xvec(1,1) + u1(1,:); % /* the first obs on y */
y2(1,:) = xvec(1,1) + u2(1,:);
obs = 2; % /* obs 2, ..., 100 */
while obs <= 100;
    y1(obs,:) = xvec(obs,:) + 0.5*y1(obs-1,:) + u1(obs,:) - 0.5*u1(obs-1,:);
    y2(obs,:) = xvec(obs,:) + 0.5*y2(obs-1,:) + u2(obs,:) - 0.5*u2(obs-1,:);
    obs = obs + 1;
end
u1 = 0; % /* clear storage area */
u2 = 0;
b20 = zeros(2,100); % /* define storage matrices */
b50 = zeros(2,100);
b100 = zeros(2,100);

biv20 = zeros(2,100);
biv50 = zeros(2,100);
biv100 = zeros(2,100);
iter = 1; % /* begin estimation do-loop */
while iter <= 100;
    if iter <= 50; % /* define y and sample index */
        y = y1; 
        nsam = iter;
    else
    y = y2; 
    nsam = iter - 50;
    end
    x=[xvec [0;y(1:99,nsam)]]; % /* X matrix */
    b20(:,iter) = x(2:20,:)\y(2:20,nsam); % /* OLS, 20 obs */
    b50(:,iter) = x(2:50,:)\y(2:50,nsam); % /* OLS, 50 obs */
    b100(:,iter) = x(2:100,:)\y(2:100,nsam); % /* OLS, 100 obs*/
    z= [xvec [0; xvec(1:99,:)]]; % /* Z matrix */
    z20 = z(2:20,:); % /* IV on 20 obs */
    biv20(:,iter) = pinv(z20'*x(2:20,:))*z20'*y(2:20,nsam);
    z50 = z(2:50,:); % /* IV on 50 obs */
    biv50(:,iter) = pinv(z50'*x(2:50,:))*z50'*y(2:50,nsam);
    z100 = z(2:100,:); % /* IV on 100 obs */
    biv100(:,iter) = pinv(z100'*x(2:100,:))*z100'*y(2:100,nsam);
    iter;
    iter = iter + 1;
end

fprintf('Now calculate the means and standard deviations of the OLS estimates. \n')
display(meanc([b20; b50; b100]'))
display(stdc([b20; b50; b100]'))

fprintf('Note that the OLS estimator is biased for the parameter lambda. \n')
fprintf('Define the break points for the histograms in Figure 17.5 for gamma(v1) and lambda(v2)\n') 

v1 = [.7 .9 1.1 1.3]';
v2 = [0 .2 .4 .6]';

fprintf('Use the �window� option to construct 6 panels and plot the percentage of estimated \n')
fprintf('values falling in each interval. \n')
% library qgraph;
% beggraph;
% window(3,2);
% {c,m,freq} = histp(b20[1,.]�,v1);
% {c,m,freq} = histp(b20[2,.]�,v2);
% {c,m,freq} = histp(b50[1,.]�,v1);
% {c,m,freq} = histp(b50[2,.]�,v2);
% {c,m,freq} = histp(b100[1,.]�,v1);
% {c,m,freq} = histp(b100[2,.]�,v2);
% endgraph;

fig=figure(2);
set(fig, 'Color', 'white')
title('Figure 17.5 Frequency distributions for least square estimators')
subplot(3,2,1);
hist(b20(1,:)',v1);
legend('\beta_{20}');
subplot(3,2,2);
hist(b20(2,:)',v2);
legend('\beta_{20}');
subplot(3,2,3);
hist(b50(1,:)',v1);
legend('\beta_{50}');
subplot(3,2,4);
hist(b50(2,:)',v2);
legend('\beta_{50}');
subplot(3,2,5);
hist(b100(1,:)',v1);
legend('\beta_{100}');
subplot(3,2,6);
hist(b100(2,:)',v2);
legend('\beta_{100}');
%see http://www.mathworks.com/matlabcentral/answers/103035-how-do-i-add-a-hat-on-a-character-which-is-displayed-in-the-legend-of-a-figure-in-matlab-7-0-r14
% Create a blank legend
% h = legend('');
% hchild is the handle to the children of the axes object.
% In this case it is a 3 by 1 vector and hchild(3) is the
% handle to the string in the legend
% hchild = get(h,'children');
% Set LaTeX as the interpreter
% set(hchild(2),'Interpreter','LaTeX');
% Add x with a hat to the legend in the current figure
% set(hchild(2),'String','$$\beta_{100}$$');

fprintf('Repeat the process for the instrumental variable estimator. First calculate the \n')
fprintf('means and standard deviations of the estimates, and note that the IV estimator \n')
fprintf('estimates both parameters well, on average. \n')
display(meanc([biv20; biv50; biv100]'))
display(stdc([biv20; biv50; biv100]'));

fprintf('Again obtain the histograms similar to Figure 17.4. The break points for  are \n')
fprintf('redefined. \n')
v2 = [.2 .4 .6 .8]';
% graphset;
% beggraph;
% window(3,2);
% {c,m,freq} = histp(biv20[1,.]�,v1);
% {c,m,freq} = histp(biv20[2,.]�,v2);
% {c,m,freq} = histp(biv50[1,.]�,v1);
% {c,m,freq} = histp(biv50[2,.]�,v2);
% {c,m,freq} = histp(biv100[1,.]�,v1);
% {c,m,freq} = histp(biv100[2,.]�,v2);
% endgraph;

fig=figure(3);
set(fig, 'Color', 'white')
title('Figure 17.4 Frequency distributions for instrumental variable estimators')
subplot(3,2,1);
hist(biv20(1,:)',v1);
legend('\beta_{20}');
subplot(3,2,2);
hist(biv20(2,:)',v2);
legend('\beta_{20}');
subplot(3,2,3);
hist(biv50(1,:)',v1);
legend('\beta_{50}');
subplot(3,2,4);
hist(biv50(2,:)',v2);
legend('\beta_{50}');
subplot(3,2,5);
hist(biv100(1,:)',v1);
legend('\beta_{100}');
subplot(3,2,6);
hist(biv100(2,:)',v2);
legend('\beta_{100}');
%see http://www.mathworks.com/matlabcentral/answers/103035-how-do-i-add-a-hat-on-a-character-which-is-displayed-in-the-legend-of-a-figure-in-matlab-7-0-r14
% Create a blank legend
% h = legend('');
% hchild is the handle to the children of the axes object.
% In this case it is a 3 by 1 vector and hchild(3) is the
% handle to the string in the legend
% hchild = get(h,'children');
% Set LaTeX as the interpreter
% set(hchild(2),'Interpreter','LaTeX');
% Add x with a hat to the legend in the current figure
% set(hchild(2),'String','$$\beta_{100}$$');

fprintf('Maximum likelihood estimation of the geometric lag model is simplified by the \n')
fprintf('fact that for a given value of  the model is linear in the parameters as indicated \n')
fprintf('in Equation 17.2.24 with variables as defined just below Equation 17.2.24. Write \n')
fprintf('a proc that constructs the artificial variables z1 and z2, estimates the model \n')
fprintf('(including an intercept this time) and returns the sum of squared errors and \n')
fprintf('OLS estimates of Model 17.4.25. The arguments of PROC SSELAM are y, the \n')
fprintf('vector X and the value of . Note that z1 (the second variable in the matrix \n')
fprintf('zlam) is calculated recursively following the expression below (17.4.24). Place \n')
fprintf('PROC SSELAM in a convenient file and run it. \n')

fprintf('Place the original data back in memory. \n')
% open f1 = nrandom.dat;
% xvec = readr(f1,100);
% u = readr(f1,500);
% f1 = close(f1);
% u = reshape(u,5,100)�;

load nrandom200
xvec = nrandom200(1:100,1);
u = randn(500,1);
u = reshape(u,5,100)';

y = zeros(100,5);
y(1,:) = xvec(1,1) + u(1,:);
obs = 2;
while obs <= 100;
    y(obs,:) = xvec(obs,:) + 0.5*y(obs-1,:) + u(obs,:) - 0.5*u(obs-1,:);
    obs = obs + 1;
end

fprintf('Now, use PROC SSELAM to compute the sum of squared errors for a range of \n')
fprintf('values between zero and one for each of the 5 samples constructed earlier and \n')
fprintf('each of the 3 sample sizes. This is fairly long so you will want to place the code \n')
fprintf('in a file and then run it. \n')

nsam = 1; %/* loop controlling sample */
display('         t              gamma         lamba        sse')
while nsam <= 5;
    samsize = 1; % /* loop controlling
    % sample size */

while samsize <= 3;
    if samsize == 1; % /* select sample size */
        t = 20;
    elseif samsize == 2;
        t = 50;
    else
        t = 100;
    end
ssevec=zeros(9,3); % /* initialize storage matrix for sse
% and estimates of gamma and lambda */

iter = 1; % /* begin loop varying lambda */
while iter <= 9;
    lam = iter/10;
    [sse,blam] = fSselam(y(1:t,nsam), xvec(1:t,:), lam);
    gam = blam(2,1); % /* store values */
    ssevec(iter,:)=[gam lam sse];
    iter = iter + 1;
end
% /* Find estimates that minimize SSE */
parm = ssevec(minindc(ssevec(:,3)),:);
disp([ t parm]); % /* print ML estimates and sample size */
samsize = samsize + 1;
end
nsam = nsam + 1;

end

fprintf('Compare these ML results to those in Table 17.4. \n')