function li = fStochli(p0)

global x y z 
% local li,k,t,k1,piz,piy,ey,ez,c;
% clearg sigv,sigu;

k = rows(p0);
t = rows(x);
piz = p0(1:k-2,:);
alpha = p0(k-1,:);
beta = p0(k,:);
piy = beta*piz;
piy(1,:) = piy(1,:) + alpha;
ey = y - x*piy;
ez = z - x*piz;
sigv = ey'*ey/t;
sigu = ez'*ez/t;
c = -t*log(2*pi) - t*.5*log(sigu) - t*.5*log(sigv);
li = c - (ey'*ey)/(2*sigv) - (ez'*ez)/(2*sigu) ;
% retp(li);
% endp;

return