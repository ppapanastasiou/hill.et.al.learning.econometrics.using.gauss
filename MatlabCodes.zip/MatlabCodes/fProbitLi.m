function out = fProbitLi(b) % /* See Eq. 19.2.18

global x y

% */ local cdf,li;
cdf = normcdf(x*b);
li = y .* log(cdf) + (1-y) .* log(1-cdf);

out = sumc(li);

% retp(sumc(li));
% endp;

return