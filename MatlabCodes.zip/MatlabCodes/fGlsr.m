function [br covbgr]=fGlsr(bg,xx,r,rr)

chat = invpd(xx);
qq = chat*r'*invpd(r*chat*r');
br = bg + qq*(rr - r*bg);
covbgr = chat - qq*r*chat;

return