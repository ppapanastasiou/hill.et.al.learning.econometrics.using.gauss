close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 20 \n')
fprintf('Biased Estimation \n')
fprintf('20.1 Statistical Decision Theory \n')
fprintf('In this Section basic concepts of decision theory are presented. \n')
fprintf('20.2 Combining Sample and Nonsample Information \n')
fprintf('Various ways of incorporating sample and nonsample information are discussed \n')
fprintf('in this Section. The first example is given in Section 20.2.1b. It uses the \n')
fprintf('sampling model described in Section 6.1.5. LOAD the (20 x 3) design matrix \n')
fprintf('in JUDGE.X, specify the true parameter vector, beta, and construct a sample of \n')
fprintf('y values using N(0,.0625) random disturbances. Examine the data. \n')

% load x[20,3] = judge.x;
load mDataJudge
x = mDataJudge;

t = rows(x);
k = cols(x);
beta = [10 0.4 0.6]';

% open f1 = nrandom.dat;
% e = readr(f1,20);
% f1 = close(f1);

load nrandom200
e = nrandom200(1:20);
e = sqrt(0.0625)*e;
y = x*beta + e;
% format 10,6;
% y~x;
display([y x])

fprintf('Construct the linear restrictions in (20.2.1a) and obtain the RLS estimates using (20.2.5). \n')
r = [0 1 1]; % /* 20.2.1a */
rr = 1;

b = x\y;
sinv = pinv(x'*x);
q = invpd(r*sinv*r');
br = b + sinv*r'*q*(rr - r*b); % /* 20.2.5 */

fprintf('The covariance matrix for the RLS estimator is given in Equation 20.2.7. To \n')
fprintf('estimate the error variance either the usual, unbiased estimator can be used or \n')
fprintf('the sum of squared errors can be based on the RLS estimates and the degrees \n')
fprintf('of freedom corrected for the fact that J = rank(R) fewer parameters need be \n')
fprintf('estimated. \n')
sighat2 = (y - x*b)'*(y - x*b)/(t - k);
j = rows(r); % /* based on RLS */
sig2 = (y - x*br)'*(y - x*br)/(t - k + j);

fprintf('This provides two estimates of the RLS covariance matrix. \n')
% /* Eq. 20.2.7 */
covbr = sighat2 * (sinv - sinv*r'*q*r*sinv);
covbr2 = sig2 * (sinv - sinv*r'*q*r*sinv);
fprintf('Compare the OLS and RLS estimates. \n')
% format 8,5;
display(b)
display(sighat2*sinv)
display(br)
display(covbr) 
display(covbr2)

fprintf('For later use, write PROC RLS to produce the RLS estimates and covariance \n')
fprintf('matrix given y, x, r and rr. Use the restricted residuals to estimate the error \n')
fprintf('variance. \n')

fprintf('The use of stochastic contraints is illustrated on page 819. It uses the same \n')
fprintf('sampling model. Write the restrictions (20.2.13a) and the precision matrix Omega \n')

r = [0 1 0; 0 0 1];
rr = [.5 .5]';
om = eye(2) ./ 64;

fprintf('Obtain parameter estimates using (20.2.15) and the covariance matrix in (20.2.17). \n')
fprintf('This example assumes sigma^2 = .0625 is known. \n')
q = pinv(x'*x + r'*pinv(om)*r);
btilde = q*(x'*y + r'*pinv(om)*rr);
covbtil = (.0625) * q;
display(btilde)
display(covbtil)

fprintf('An example using inequality constraints is given on p.822. It is simply noted \n')
fprintf('that the OLS estimates violate the single restriction in (20.2.24a) and that the \n')
fprintf('inequality RLS estimates are equal to the RLS estimates. \n')
display(b)
display(br)

fprintf('In Section 20.2.3d Bayesian analysis with inequality restrictions is considered. \n')
fprintf('Given the sampling model in Equation 20.2.37 and a noninformative prior is \n')
fprintf('assumed then the posterior is given by (20.2.39). Write a PROC that returns \n')
fprintf('the value of the posterior given the least squares estimate b, the sum of the \n')
fprintf('squared x values xsum and the multiplicative constant c. \n')

fprintf('In order to calculate the normalizing constant c for the truncated normal posterior \n')
fprintf('in (20.2.41), let c = 1 with the values for b and the sum of squares at \n')
fprintf('the bottom of page 827. Use the GAUSS function INTQUAD1 to numerically \n')
fprintf('integrate the posterior density from 0 to 1. The normalizing constant is the \n')
fprintf('reciprocal of this value as given on page 828. \n')
intord = 20;
% xl = [1; 0];
% y = intquad1(&POST,xl);
y = integral(@fPost,0,1);
% y = quadgk(@fPost,0,1);
display(y)
c = 1/y;
display(c)

fprintf('Plot the normal and truncated normal posterior functions. \n')
beta = seqa(.7,.005,101);
n1 = fPost(beta); % /* normal posterior */
n2 = n1*c .* (beta < 1); % /* truncated normal post�r */
% library qgraph;
% xy(beta,n1~n2);

fig = figure(1);
set(fig, 'Color', 'white')
plot(beta, [n1 n2], 'Color', 'black', 'LineWidth' , 3)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
% titel='Plot of the data in Table 16.1';
% legend('RSS')
% title(titel,'FontSize',10);
% ylabel( '$y_t$', 'FontSize', 14, 'Interpreter', 'latex');
% xlabel( 't', 'FontSize', 12);

fprintf('To compute the Bayesian point estimate of beta the mean of the posterior distribution \n')
fprintf('must be obtained. The weighted posterior can be numerically integrated \n')
fprintf('over the range [0,1] to compute the expected value of beta. PROC EXPT returns \n')
fprintf('the value of the weighted density function which is then integrated. \n')

% betabar = intquad1(&expt,xl);
% format 10,6;
betabar = integral(@fExpt,0,1);
display(betabar)

fprintf('To compute the Bayesian 95 percentage highest posterior density interval for the truncated \n')
fprintf('posterior calculate the probability mass over a rough grid of values and \n')
fprintf('then refine the search. \n')
lb = seqa(.7,.01,20);
ub = ones(20,1);
xl = [ub'|lb'];
% prob = intquad1(&POST,xl);
prob = nan(length(ub),1);
for i = 1:length(ub)
    dLb = lb(i);
    dUb = ub(i);
    prob(i,1) = integral(@fPost,dLb,dUb);
end
display('          lb            prob')
disp([lb prob])

fprintf('The lower bound of the 95 percentage interval is near .82. Examine this area more \n')
fprintf('carefully. \n')
lb = seqa(.81,.001,20);
xl = [ub';lb'];
% prob = intquad1(&POST,xl);
for i = 1:length(ub)
    dLb = lb(i);
    dUb = ub(i);
    prob(i,1) = integral(@fPost,dLb,dUb);
end
display('          lb            prob')
disp([lb prob])

fprintf('The example is then repeated for a different value of b, which violates the prior \n')
fprintf('information. \n')
fprintf('Find the normalizing constant. \n')
b = 1.05;
c = 1;
xsum = 196;
xl = [1; 0];
% y = intquad1(&POST,xl);
y = integral(@fPost,0,1);
display(y)
c = 1/y;
display(c)

fprintf('Graph the posteriors. \n')
beta = seqa(.8,.005,101);
n1 = fPost(beta);
n2 = n1*c .* (beta < 1);

% xy(beta,n1~n2);

fig = figure(2);
set(fig, 'Color', 'white')
plot(beta, [n1 n2], 'Color', 'black', 'LineWidth' , 3)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
% titel='Plot of the data in Table 16.1';
% legend('RSS')
% title(titel,'FontSize',10);
% ylabel( '$y_t$', 'FontSize', 14, 'Interpreter', 'latex');
% xlabel( 't', 'FontSize', 12);

fprintf('Find the mean of the truncated posterior. \n')
% betabar = intquad1(&expt,xl);
betabar = integral(@fExpt,0,1);
display(betabar)

fprintf('Find the 95 percentage HPD interval. \n')
lb = seqa(.8,.01,20);
ub = ones(20,1);
xl = [ub'; lb'];
% y = intquad1(&POST,xl);
y = nan(length(ub),1);
for i = 1:length(ub)
    dLb = lb(i);
    dUb = ub(i);
    y(i,1) = integral(@fPost,dLb,dUb);
end
display('          lb            prob')
disp([lb y])


fprintf('Search near .89 for the lower bound of the interval. \n')
lb = seqa(.88,.001,20);
xl = [ub'; lb'];
% y = intquad1(&POST,xl);
y = nan(length(ub),1);
for i = 1:length(ub)
    dLb = lb(i);
    dUb = ub(i);
    y(i,1) = integral(@fPost,dLb,dUb);
end
display('          lb            prob')
disp([lb y])

fprintf('Finally, let us extend the results to allow for an unknown error variance, as on \n')
fprintf('page 830 of ITPE2. The example used is that in Section 6.1.5. LOAD in the \n')
fprintf('(20 x 3) design matrix found in the file JUDGE.X and examine it. \n')
t = 20;
k = 3;
% load x[t,k] = judge.x;
load mDataJudge
x = mDataJudge;
display(x)

fprintf('Now create the values of the dependent variable using the parameter values \n')
fprintf('given in the text and the first 20 �official� normal random numbers, which are \n')
fprintf('transformed to have variance .0625. \n')
beta = [10 0.4 0.6]';
% open f1 = nrandom.dat;
% e = readr(f1,20);
% f1 = close(f1);

load nrandom200
e = nrandom200(1:20);
e = sqrt(.0625) * e;
y = x*beta + e;
fprintf('Calculate the ML estimates of beta and the unbiased estimator of the error variance. \n')
b = x\y;
sighat2 = (y - x*b)'*(y - x*b)/(t - k);
covb = sighat2 * pinv(x'*x);

fprintf('The idea now is to do the following. If a uniform inequality prior is placed \n')
fprintf('on the parameters, namely that the sum of the second and third parameters is \n')
fprintf('less than or equal to one, the posterior distribution is a multivariate-t which \n')
fprintf('is truncated itself. The parameter estimates are the mean of this truncated \n')
fprintf('joint distribution. Since it is difficult to integrate this function in a straightforward \n')
fprintf('manner, we use a technique called �Monte Carlo Integration�. What it \n')
fprintf('amounts to is generating many (we will use 20,000) (K x 1) vectors of betas from \n')
fprintf('the untruncated multivariate-t distribution and then simply keep track of the \n')
fprintf('mean and variance of those beta vectors which satisfy the inequality constraint. \n')
fprintf('Those means and variances are our Bayesian parameter estimates. \n')
fprintf('The first problem we must address is how to generate random values from a \n')
fprintf('multivariate-t distribution. The method is described in �Further experience in \n')

fprintf('Bayesian Analysis Using Monte Carlo Integration,� by H.K. van Dijk and T. \n')
fprintf('Kloek, Journal of Econometrics, vol. 14, pages 307-328, 1980. The procedure is \n')
fprintf('to generate multivariate normal random values from a distribution with mean \n')
fprintf('B and covariance matrix COVB, which we have calculated above, and divide \n')
fprintf('by the square root of a random value from a chi-square distribution which has \n')
fprintf('been divided by its degrees of freedom, (T - K). \n')
fprintf('To generate the desired multivariate normal distribtion we use a transformation \n')
fprintf('matrix such that P*P� = COVB. That is provided by the transpose of the \n')
fprintf('Cholesky decomposition. Find and check this matrix. \n')
pt = chol(covb);
p = pt';
check = p*p';
display(check)
display(covb)

fprintf('As noted above we wish to generate 20,000 (K x 1) vectors. This we will do in \n')
fprintf('25 loops that generates 800 such vectors at a time. We will also use the concept \n')
fprintf('of antithetic random numbers which says to use both the positive and negative \n')
fprintf('values of a random number to reduce numerical inaccuracy. Thus the number \n')
fprintf('of random samples in each iteration will be NSAM = 400. \n')
niter = 25;
nsam = 400;
totsam = 2*niter*nsam;

fprintf('We will use separate seed values for the multivariate normal and chi-square \n')
fprintf('random deviates to ensure independence of the numerator and denominator. \n')
seed1 = 93578421;
seed2 = 17411329;

fprintf('Finally, define storage matrices in which we will accumulate the sum, sum of \n')
fprintf('squares and posterior probability of the inequality constrained parameters. \n')
bbar2 = zeros(k,1);
bbaravg = zeros(k,1);
totn = 0;

fprintf('Now we are ready to start. The following code should be placed in a file and \n')
fprintf('executed. It will take a couple of minutes to complete the execution. Also, the \n')
fprintf('results you obtain will not be exactly the same as in the text as a different set \n')
fprintf('of random numbers is used, but they will be close. \n')

iter = 1; % /* begin loop */
while iter <= niter;
    rng(seed2)
    w = randn(t-k,nsam); % /* create chi.sq.(t-k) */
    w = sumc(w .* w)';
    rng(seed1)
    inc = p*randn(k,nsam); % /* normal(b,covb) */
    inc = inc ./ repmat(sqrt( w ./ (t-k)), rows(inc), 1); % /* divide by chi.sq. */
    bbar = [(repmat(b, 1, cols(inc)) + inc) (repmat(b, 1, cols(inc)) - inc)]; %  /* multi-t */
    bsum = bbar(2,:) + bbar(3,:); % /* sum b2 and b3 */
    success = (bsum <= 1); % /* check constraint */
    totn = sumc(success') + totn; % /* count successes */
    bsat = bbar .* repmat(success, rows(bbar), 1); % /* select successes */
    bbaravg = bbaravg + sumc(bsat'); % /* collect sum */
    % /* collect sum of sq. */
    bbar2 = bbar2 + sumc( (bsat.*bsat)');
    % ?;
    display('iter =') 
    disp(iter) % /* print iteration */
    display('totn =') 
    disp(totn) % /* cumulative total */
    iter = iter + 1;
end
postprob = totn/totsam; % /* post. prob */
bbarbar = (bbaravg ./ totn); % /* means */
bbarvar = ((bbar2 - (totn .* bbarbar.^2))/totn); % /* variances */

display('totn =') 
disp(totn) % /* print */
display('postprob =') 
disp(postprob)
display('bbarbar =') 
disp(bbarbar')
display('bbarvar =') 
disp(bbarvar')

fprintf('20.3 Pretest and Stein Rule Estimators \n')
fprintf('In this section the sampling properties of the pretest estimator and the Steinrule \n')
fprintf('estimator are presented. \n')
fprintf('20.4 Model Specification \n')
fprintf('In this Section various rules are discussed which have been proposed to aid in the \n')
fprintf('selection of regressors to include in a statistical model. In order to examine the \n')
fprintf('ability of these rules to detect the correct set of regressors a small monte carlo \n')
fprintf('experiment is carried out in Section 20.4.3f. The true model is the one presented \n')
fprintf('in Section 6.1.5 and which has been used earlier in this chapter. Construct 100 \n')
fprintf('samples of y with T = 20 observations using this model. Recall that 250 samples \n')
fprintf('of random errors from a N(0,1) are stored in e1nor.fmt. \n')

t = 20;

% load x[20,3] = judge.x;
% load xa[20,3] = table20.52;
load mDataJudge
x = mDataJudge;
load mDataTable20_52
xa = mDataTable20_52;

beta = [10 0.4 0.6]';
% load e = e1nor.fmt;
e = randn(20,100);
e = sqrt(.0625)*e(:,1:100);
y = repmat(x*beta, 1, cols(e)) + e;

fprintf('The matrix y is (20 x 100) with each column representing a sample of size 20. \n')
fprintf('For the purposes of exploration we will add 3 regressors to the X matrix. These \n')
fprintf('are shown in Equation (20.5.2) as x4, x5 and x6 and are contained in the file \n')
fprintf('TABLE20.52 on your data disk. \n')
% format 10,6;
x = [x xa];
display(x) % /* Eq. 20.5.2 */

fprintf('We wish to examine the ability of the four criteria based on R2, AIC, PC and \n')
fprintf('SC to detect the correct model from the seven sets of regressors listed in Table \n')
fprintf('20.3. Write a program that will calculate each of the selection criteria for each \n')
fprintf('of the 7 models for all 100 samples. \n')
rbar2 = zeros(100,7); % /* storage matrices */
aic = zeros(100,7);
sc = zeros(100,7);
pc = zeros(100,7);
x1 = x(:,1:3); % /* 7 model specifications */
x2 = x(:,1:4);
x3 = x(:,[1 2 3 5]);
x4 = x(:,[1 2 3 6]);
x5 = x(:,1:5);
x6 = x(:,[1 2 3 4 6]);
x7 = x(:,[1 2 3 5 6]);
% /* SST */
sst = sumc( (y-repmat(meanc(y), rows(y), 1)) .* (y-repmat(meanc(y), rows(y), 1)) );

model = 1; % /* start do-loop */
while model <= 7;
    model;
    if model == 1; 
        x = x1; % /* select model */
    elseif model == 2; 
        x = x2;
    elseif model == 3; 
        x = x3;
    elseif model == 4; 
        x = x4;
    elseif model == 5; 
        x = x5;
    elseif model == 6; 
        x = x6;
    else x = x7;
    end
    b = x\y; % /* ols estimates */
    k1 = cols(x); % /* K1 */
    ssei = sumc( (y-x*b) .* (y-x*b) ); % /* SSE */
    % /* Selection criteria as defined in Table 20.2 */
    rbar2(:,model) = 1 - ((t-1)/(t-k1)) .* (ssei ./ sst);
    aic(:,model) = log(ssei/t) + 2*k1/t;
    sc(:,model) = log(ssei/t) + k1*log(t)/t;
    pc(:,model) = (ssei/(t-k1)) .* (1+k1/t);
    model = model + 1;
end % /* end do-loop */

fprintf('To count the number of times each model is selected under each criterion use \n')
fprintf('the MAXINDC and MININDC to return the indices of respective model choices \n')
fprintf('and count the number taking values 1,...,7. \n')
v = [1 2 3 4 5 6 7]';
rbar2F = counts(maxindc(rbar2'),v);
aicF = counts(minindc(aic'),v);
scF = counts(minindc(sc'),v);
pcF = counts(minindc(pc'),v);
table = [rbar2F aicF pcF scF];
% format 4,2;
display(table)