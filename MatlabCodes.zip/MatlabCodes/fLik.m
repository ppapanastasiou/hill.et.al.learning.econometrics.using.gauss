function dLik = fLik(y, p)
T = length(y);
K = length(p);

p = kron(ones(T,1), p);
y = kron(ones(1,K), y);

dLik = prod(p.^y .*(1-p).^(1-y));

return

