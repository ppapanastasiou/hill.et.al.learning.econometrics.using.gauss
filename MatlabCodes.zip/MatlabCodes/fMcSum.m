function results=fMcSum(param, x, beta, sigma2)

disp('True parameters :')
disp([beta' sigma2])
disp('Mean of estimates :')
disp(mean(param'))
disp('Max of estimates :')
disp(max(param'))
disp('Min of estimates :')
disp(min(param'))
disp('True variances :')
disp(diag(sigma2*inv(x'*x))')
disp('Estimated variances :')
disp(std(param(1:length(beta),:)').^2)
disp('Sample size :')
disp(rows(x))
disp('Number of samples :')
disp(cols(param))

results.beta=beta;
results.sigma2=sigma2;
results.meanparam=mean(param);
results.maxparam=max(param);
results.minparam=min(param);
results.truevar=diag(sigma2*inv(x'*x));
results.estvar=std(param(1:length(beta),:)').^2;
results.samplesize=rows(x);
results.numbersamples=cols(param);

return