function  lam=fLambda(r,rr,b,ixx,sighat2)

lam = (r*b - rr)'*inv(r*ixx*r')*(r*b - rr)/(rows(rr)*sighat2);

return