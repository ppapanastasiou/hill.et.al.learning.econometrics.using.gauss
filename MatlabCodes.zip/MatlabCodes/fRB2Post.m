function store = fRB2Post(rho)
% local m,n,store,i,j,bstar,sse,xstar,xtx,ixx,c22,rhomat;

global nu biconst b2

store = 0 .* rho;
m = rows(store); 
n = cols(store);
rhomat = rho .* (store + 1);
i = 1;
while i <= m;
    j = 1;
    while j <= n;
        [bstar,sse, xstar] = fNewb(rhomat(i,j));
        xtx = xstar'*xstar;
        ixx = invpd(xtx);
        c22 = ixx(2,2);
        store(i,j) = (1/biconst).* (sqrt(1- rhomat(i,j).^2)*(sse^(-(nu+1)/2))/(sqrt(det(xtx))*c22))/(1+((b2-1.672)^2)/(c22*sse))^((nu+1)/2);
        j = j+1;
    end
    i = i + 1;
end

% retp(store);

return