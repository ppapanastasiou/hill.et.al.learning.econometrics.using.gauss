function dOut=fM2ig(v, s)

dOut=v*s*s/(v-2);

return