close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 15 \n')
fprintf('Simultaneous Linear \n')
fprintf('Statistical Models: II \n')

fprintf('In this chapter a variety of estimators for single equations within a system of simultaneous \n')
fprintf('equations are considered as well as the problem of estimating all the \n')
fprintf('equations jointly. The asymptotic properties of the estimators are determined \n')
fprintf('and compared. \n')

fprintf('15.1 Estimating the Parameters of an Overidentified Equation \n')

fprintf('When equations within a simultaneous system are overidentified the indirect \n')
fprintf('least squares estimator is inefficient. Generalized and Two Stage Least Squares \n')
fprintf('estimators are proposed that are more efficient than the indirect least squares \n')
fprintf('estimator. \n')

fprintf('15.2 The Search for an Asymptotically Efficient Estimator \n')

fprintf('The estimators proposed in Section 15.2 are single equation methods. That is \n')
fprintf('they estimate the parameters of a single structural equation at a time. Much \n')
fprintf('as in the case in Seemingly Unrelated Regression problems the efficiency of \n')
fprintf('estimation can be increased if contemporaneous correlations exist among the \n')
fprintf('structural equation errors and if the equations are overidentified. The technique \n')
fprintf('of Three Stage Least Squares is introduced as a method of using this additional \n')
fprintf('information. \n')

fprintf('15.3 Asymptotic and Finite Sampling Properties \n')
fprintf('of the Alternative Estimators \n')

fprintf('This Section summarizes the properties of the various estimators. \n')

fprintf('15.4 An Example \n')

fprintf('To illustrate the various estimators discussed in the previous Sections an example \n')
fprintf('is carried out. First we will verify the sample generation process by \n')
fprintf('replicating the data generated in Table 15.1. \n')
fprintf('LOAD the data in file TABLE15.1, which consists of T = 20 observations on \n')
fprintf('the five exogenous variables listed in Table 15.1. Check the data. \n')

% load x[20,5] = table15.1;
% format 10,7;
% x;

load mDataTable15_1
x = mDataTable15_1;

fprintf('Specfify the Gamma and Beta matrices of structural parameters, given in Equations \n')
fprintf('15.4.3 and 15.4.4, and then construct the matrix of reduced form parameters \n')
fprintf('in (15.4.6). \n')

gam = [-1 0.2 0; -10 -1 2; 2.5 0 -1];

beta = [-60 40 -10; 0 -4 80; 0 -6 0; 0 1.5 0; 0 0 5];

pimat = -beta*inv(gam);
display(pimat)

fprintf('Specify the Sigma matrix in Equation 15.4.5. \n')

sigma = [227.55 8.91 -56.89; 8.91 0.66 -1.88; -56.89 -1.88 15.76];

fprintf('In order to generate random disturbances with a N(0, Sigma) distribution we \n')
fprintf('will follow the same process used in Chapter 11, as described in the Appendix \n')
fprintf('to that chapter. First, find the characteristic roots and vectors of Sigma and change \n')
fprintf('their order to one of descending magnitude \n')

% {d,c} = eigrs2(sigma);
% d c;
% d = rev(d);
% c = (rev(c�))�;
% d c;
[c, d] = eig(sigma);% In matlab with two outputs we get first the eigenvectors and then the eigenvalues
d=diag(d);% only want the diagonal, since we want only a column vector containing the eigenvalues to be compatible with the Gauss function eigrs2
disp([d c])
% Note that GAUSS orders the characteristic roots and the corresponding characteristic
% vectors from smallest to largest. To conform to the text order the roots
% from largest to smallest and reverse the order of the columns of the matrix of
% characteristic vectors to match.
d = rev(d);
c = rev(c');
fprintf('Eigenvalues \n')
display(d)
fprintf('Eigenvectors \n')
display(c)

%%
fprintf('Added by me to illustrate characteristic roots and vectors')
C = c;
fprintf('Due to the normalization issue of characteristic vectors, discussed in Chapter \n')
fprintf('11, the sign of the last characteristic vector must be changed for us to exactly \n')
fprintf('replicate the data in ITPE2. \n')
C(end,:) = -C(end,:);

D = zeros( length(d), length(d));
D = diagrv(D, d);
CD = C'*sqrt(D);
DC = sqrt(D)*C;
mSigma = CD*DC;
display(sigma)
display(mSigma)

D1 = C*mSigma*C';
display(D)
display(D1)

mIdentity = D^(-1/2)*C*mSigma*C'*D^(-1/2);
mIdentity1 = D^(-1/2)*D*D^(-1/2);
display(mIdentity)
display(mIdentity1)

mSigma1 = CD*DC;
display(mSigma1)

%%
fprintf('Note that GAUSS returns C transpose and not C. Hence we tranpose here c \n')
fprintf('to keep the same notation as the manual. \n')
c = c';

fprintf('Due to the normalization issue of characteristic vectors, discussed in Chapter \n')
fprintf('11, the sign of the third characteristic vector must be changed for us to exactly \n')
fprintf('replicate the data in ITPE2. \n')
c(:,3) = -c(:,3);
display(c)

fprintf('Create the transformation matrix and check that it does transform the matrix \n')
fprintf('sigma to the identity and that when multiplied by its transpose it creates the \n')
fprintf('sigma matrix. \n')

sighalf = c * diagrv( eye(3), sqrt(d) ); %this is the C'D^(1/2)

check1 = c'*sigma*c;
display(check1)
display(D)

check2 = sighalf*eye(3)*sighalf';
display(check2)
display(sigma)

fprintf('Read in the first 60 �official� N(0,1) random numbers. \n')

% open f1 = nrandom.dat;
% e1 = readr(f1,20);
% e2 = readr(f1,20);
% e3 = readr(f1,20);
% f1 = close(f1);

load nrandom200
e1 = nrandom200(1:20,1);
e2 = nrandom200(21:40,1);
e3 = nrandom200(41:60,1);

fprintf('Stack the columns into a matrix E and transform them using sighalf. The \n')
fprintf('resulting random numbers have the desired sampling distribution. \n')
e = [e1 e2 e3]*sighalf';
display(e)

fprintf('Create the reduced form disturbances v and use the reduced form equation to create the values of y. \n')
v = e*pinv(gam);
y = x*pimat + v;
display(y)
fprintf('Using the data on y and X, estimate the reduced form parameters (15.4.10). \n')

pix = x\y;
display(pix)

fprintf('Compute the OLS parameter estimates for each structural equation (15.4.11- 15.4.12). \n')
y1 = y(:,1);
z1 = [y(:,[2 3]) x(:,1)];
b1 = z1\y1;
y2 = y(:,2);
z2 = [y(:,1) x(:,[1 2 3 4])];
b2 = z2\y2;
y3 = y(:,3);
z3 = [y(:,2) x(:,[1 2 5])];
b3 = z3\y3;
display(b1)
display(b2)
display(b3)

fprintf('Since the second equation is just identified, its structural parameters can be \n')
fprintf('efficiently estimated using indirect least squares (15.4.13). \n')
bils = x'*z2\x'*y2;
display(bils)

fprintf('For the overidentified equations indirect least squares is inefficient and GLS- \n')
fprintf('2SLS should be used. See Equation 15.1.10. \n')
q = x*pinv(x'*x)*x';
bgls1 = (z1'*q*z1)\(z1'*q*y1); % /* Equation 1 */
bgls2 = (z2'*q*z2)\(z2'*q*y2); % /* Equation 2 */
bgls3 = (z3'*q*z3)\(z3'*q*y3); % /* Equation 3 */
display(bgls1)
display(bgls2)
display(bgls3)

fprintf('To obtain standard errors for these estimators we will estimate the covariance \n')
fprintf('matrix as in Equations 15.1.15 and 15.1.16, correcting for the degrees of freedom. \n')
e1 = y1 - z1*bgls1;
e2 = y2 - z2*bgls2;
e3 = y3 - z3*bgls3;
t = rows(e1);
ehat = [e1 e2 e3];
sse = diag(ehat'*ehat);

k = [cols(z1); cols(z2); cols(z3)];
df = t - k;
var = sse ./ df;
sd1 = sqrt(diag( var(1) * invpd(z1'*q*z1) ));
sd2 = sqrt(diag( var(2) * invpd(z2'*q*z2) ));
sd3 = sqrt(diag( var(3) * invpd(z3'*q*z3) ));

fprintf('Print out the estimates and their standard errors and compare to (15.4.17). \n')
display([bgls1 sd1]);
display([bgls2 sd2]);
display([bgls3 sd3]);

fprintf('To compute the 3SLS estimator the contemporaneous covariance matrix will be \n')
fprintf('estimated using the 2SLS residuals and the inverse taken. \n')
sig = ehat'*ehat/t;
isig = invpd(sig);

fprintf('The most direct computational approach is to use Equation 15.2.4, which requires \n')
fprintf('the construction of the stacked vector y and block diagonal matrix z as \n')
fprintf('indicated below (15.2.2). \n')
y = [y1; y2; y3];
k1 = cols(z1);
z1a = [z1; zeros(2*t,k1)];
k2 = cols(z2);
z2a = [zeros(t,k2); z2; zeros(t,k2)];
k3 = cols(z3);
z3a = [zeros(2*t,k3); z3];
z = [z1a z2a z3a];
display(z)

fprintf('The 3SLS estimator is then computed. Compare these results to those in \n')
fprintf('(15.4.21). \n')
num = z'*kron(isig, q)*y;
den = z'*kron(isig, q)*z;
b3sls = den\num;
std = sqrt(diag(invpd(den)));
display([b3sls std])

fprintf('The only problem with this approach is that the matrices involved can be large \n')
fprintf('and storage can become a problem. The following is equivalent code which does \n')
fprintf('not involve creating the large matrices. Analyze how these statements work. \n')
z = [z1 z2 z3];
y = [y1 y2 y3];
indx = [ones(3,1);( ones(5,1)*2 );( ones(4,1)*3 )];
vv = isig(indx,indx);
vy = isig(indx,:);
xx = z'*x*invpd(x'*x)*x'*z;
zy = z'*x*invpd(x'*x)*x'*y;
isxx = invpd(xx .* vv);
szy = sumc( (zy .* vy)' );
b = isxx*szy;
std = sqrt(diag(isxx));
display(b)
display(std);

fprintf('Finally, write a PROC computing the reduced form coefficients from a given set \n')
fprintf('of structural estimates that are stacked into a single column, c. \n')


fprintf('Run PROC RFORM to put it into memory and then apply it to the OLS, GLS- \n')
fprintf('2SLS and 3SLS parameter estimates. \n')
bols = [b1; b2; b3];
pols = fRform(bols);
display(pols); % /* Equation 15.4.22 */
b2sls = [bgls1; bgls2; bgls3];
p2sls = fRform(b2sls);
display(p2sls); %  /* Equation 15.4.23 */

p3sls = fRform(b3sls);
display(p3sls); % /* Equation 15.4.24 */

fprintf('15.5 On Using the Results of Econometric Models \n')
fprintf('for Forecasting and Decision Purposes \n')
fprintf('In this Section some of the uses of econometric models are discussed. In Equations \n')
fprintf('15.5.1a-g the use of these models as forecasting tools is illustrated. First, \n')
fprintf('if xt is given by (15.5.1e) and if the true reduced form parameters are known \n')
fprintf('the forecasted value of yt is (15.5.1f) \n')
xt = [1 8 6 23 40]';
yt = xt'*pimat;

fprintf('If the reduced form parameters are derived from the 3SLS estimates the forecasted \n')
fprintf('value of yt is (15.5.1g). \n')
yhat = xt'*p3sls;
display(yhat)

fprintf('In the context of a dynamic model the characteristic roots of the matrix F \n')
fprintf('containing the parameters on the lagged endogenous variables determine the \n')
fprintf('dynamic properties of the model. For the system in Equations 15.5.6a-b the \n')
fprintf('matrix F is given in (15.5.8). This matrix is not symmetric and the resulting \n')
fprintf('characteristic roots need not be real. GAUSS can handle this problem, \n')
fprintf('however, as it contains special functions designed for complex numbers. The \n')
fprintf('GAUSS function EIGRG returns the real and imaginary parts of the characteristic \n')
fprintf('roots of a real, general matrix. \n')
fprintf('Note that the values in the text are incorrect. This may be verified by noting \n')
fprintf('that the determinant of F is the product of its characteristic roots. \n')
f= [.32 -.18; -.16 -.06];
[crr,cri] = eig(f);
display(crr)
display(cri)
fprintf('The lag 1-step dynamic multipliers are calculated from F * G in (15.5.9). \n')
g = [6.8 .04 .3; 1.6 -.02 .1];
display(f*g)

