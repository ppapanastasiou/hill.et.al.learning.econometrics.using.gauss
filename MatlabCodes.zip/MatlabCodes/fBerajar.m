function [lam, pval] = fBerajar(x,y)
% local *;
t = rows(x);
k = cols(x);
b = x\y; % /* OLS */
e = y - x*b; % /* residuals */
sigtil2 = sumc(e.^2)/t; % /* moments */
mu3 = sumc(e.^3)/t;
mu4 = sumc(e.^4)/t;
% /* Eq. 22.2.7 */
term1 = (mu3.^2)/(6*sigtil2.^3);
term2 = (mu4 - (3 .* sigtil2.^2))^2/ (24 * sigtil2^4);
lam = t*(term1 + term2);
pval = chi2cdf(lam,2, 'upper');
display('Bera-Jarque test for Normality')
% ?;
display('lam')
disp(lam)
display('pval') 
disp(pval)

% retp("");
% endp;

return