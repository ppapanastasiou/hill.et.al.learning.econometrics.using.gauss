function out=fPdfNorm(x, mu, sig2)

% Attention sig2 is the variance not the standard deviation

out= exp((-(x-mu).^2)./(2*sig2))./sqrt(2*pi*sig2);

return