function mom2 = fRhoMu2(rho)
% local mom2;
mom2 = rho .* rho .* fRhoPost(rho);

return