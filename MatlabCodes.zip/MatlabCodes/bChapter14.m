close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 14 \n')
fprintf('Simultaneous Linear \n')
fprintf('Statistical Models: I \n')
fprintf('14.1 Introduction \n')
fprintf('In this chapter the nature of simultaneous equations models is explored. In \n')
fprintf('particular the notation and assumptions are developed, the inconsistency of \n')
fprintf('OLS estimation demonstrated and the concept of identification explained. \n')
fprintf('14.2 Specification of the Sampling Model \n')
fprintf('In this Section the notation is developed and the assumptions of the sampling \n')
fprintf('model stated. Following Equation 14.2.21 a numerical example is given. Define \n')
fprintf('the matrices sigma and plimx as given at the top of page 608. \n')

sigma = [5 1; 1 1]';

plimx = [1 1 0; 1 2 0; 0 0 1]';

fprintf('Define the parameter matrices Gamma and Beta. \n')
g =[-1 2; 1 -1];

b = [0 3; 2 0; 0 1];

fprintf('Compute reduced form parameters as in Equation 14.2.13a. \n')
pix = -b*pinv(g);
display(pix)

fprintf('Compute the plim of V 0V/T , which is the contemporaneous covariance matrix \n')
fprintf('for the reduced form disturbances. See Equation 14.2.18a. \n')
plimv = inv(g)'*sigma*inv(g);
display(plimv)

fprintf('Compute the plim of y0y/T . See Equation 14.2.23. The (2,2) element should \n')
fprintf('agree with (14.2.23). \n')
plimy = pix'*plimx*pix + plimv;
display(plimy)

fprintf('Compute the plim of X0y/T . See Equation 14.2.24. The (2,2) element should \n')
fprintf('agree with (14.2.24). \n')
plimxy = pix'*plimx;
display(plimxy)

fprintf('Compute the plim of y0e/T . See Equation 14.2.25. The (2,1) element will agree \n')
fprintf('with (14.2.25). \n')
plimye = -inv(g)'*sigma;
display(plimye)

fprintf('14.3 Least Squares Bias \n')
fprintf('In this Section the least squares bias and inconsistency is demonstrated. On \n')
fprintf('page 611 the example from the preceeding section is continued. \n')
fprintf('Compute the plim of the least squares estimator as in Equation 14.3.7. Construct \n')
fprintf('plimz from the previous results. \n')
plimz = [91 -11; -11 2];

fprintf('Define delta1. \n')
d1 = [1 2]';

fprintf('Construct plimze using previous results. \n')
plimze = [-11 0]';

fprintf('Find the plim of the least squares estimator of delta and its asymptotic bias. \n')
fprintf('See page 611 ITPE2. \n')
plimd1 = d1 + pinv(plimz)*plimze;
display(plimd1)

bias = plimd1 - d1;

fprintf('14.4 The Problem of Going from the Reduced-Form Parameters to the Structural Paramaters \n')
fprintf('In this Section the Identification problem is defined and identification rules \n')
fprintf('given. In Section 14.5.3 an Empirical example is given using the simple Keynesian model. \n')
fprintf('LOAD the data from file TABLE14.1. It consists of T = 20 observations on \n')
fprintf('investment from Table 14.1 in ITPE2. \n')
%load i[20,1] = table14.1;
load mDataTable14_1
i = mDataTable14_1;

fprintf('Using i, and the official random numbers, we can create the remaining elements \n')
fprintf('of the model using Equations 14.9.1-14.9.2. Let e be a vector of N(0,.04) random \n')
fprintf('disturbances. \n')
% open f1 = nrandom.dat;
% e = readr(f1,20);
load nrandom200
e = nrandom200(1:20,1);
% f1 = close(f1);
e = sqrt(.04)*e;

fprintf('Define the parameter values for alpha and beta \n')
alpha = 2;
beta = 0.8;

fprintf('Construct v. \n')
v = (1/(1 - beta))*e;

fprintf('Construct c and y using Equation 14.9.2. \n')
c = alpha/(1 - beta) + beta/(1 - beta)* i + v;
y = alpha/(1 - beta) + 1/(1 - beta)* i + v;

fprintf('Print out Table 14.1 using the constructed values. \n')
display([i c y v])

fprintf('Compute reduced form parameters regressing c and y on i. \n')
dep = [c y];
x = [ones(20,1) i];
pix = x\dep;
display(pix)

fprintf('Solve for the the structural parameters using (14.5.23) and (14.5.25). \n')

pi11 = pix(1,1);
pi21 = pix(2,1);
beta = pi21/(1+pi21);
alpha = pi11*(1 - beta);
display(alpha) 
display(beta)

fprintf('Then, using income equations, (14.5.24) and (14.5.26), \n')
pi12 = pix(1,2);
pi22 = pix(2,2);
beta = (pi22 - 1)/pi22;
alpha = pi12*(1 - beta);
display(alpha)
display(beta)

fprintf('Compare these results to the OLS estimates. \n')
b = [ones(20,1) c]\y;
display(b)

fprintf('Since it is impossible to judge the amount of estimator bias from one sample of \n')
fprintf('data, carry out a short monte carlo experiment, repeating the above using n = \n')
fprintf('250 samples of size T = 20. \n')
fprintf('Create the data on c and y. \n')
n = 250;
t = 20;
% load e = e1nor.fmt;
e = randn(t,n);
e = sqrt(.04) * e;
c = (2 + .8*repmat(i,1,n) + e)./(1 - .8);
y = repmat(i,1,n) + c;

fprintf('Obtain reduced form estimates and calculate their mean values from the 250 \n')
fprintf('samples and compare to the true values for the consumption equation (14.5.25). \n')
x = [ones(t,1) i];
pic = x\c;
display(meanc(pic')')

fprintf('Obtain estimates of the structural parameters for the 250 samples and compare \n')
fprintf('their mean to the true structural parameter values. \n')
p1 = pic(1,:);
p2 = pic(2,:);
beta = p2 ./ (1+p2);
alpha = p1 .* (1 - beta);
b = [alpha; beta];
display(meanc(b')')
display(stdc(b')')

fprintf('Obtain the OLS estimates for the consumption equation for 250 samples and \n')
fprintf('calulate their mean and standard deviation. \n')
j = 1;
bols = zeros(2,n);
while j < n;
    bols(:,j) = [ones(t,1) y(:,j)]\c(:,j);
    j = j + 1;
end
display(meanc(bols')')
display(stdc(bols')')

fprintf('Calculate the percent of samples in which the OLS estimates were greater than \n')
fprintf('the indirect least squares estimates. \n')
z = (bols - b) > 0;
display(meanc(z'))

fprintf('Calculate the percent of samples in which the indirect least squares estimates \n')
fprintf('were greater than the true parameter values. \n')
beta = [2 .8]';
z = b > repmat(beta,1, cols(b));
display(meanc(z'))

fprintf('Calculate the percent of samples in which the OLS estimates were greater than \n')
fprintf('the true parameter values. \n')
z = bols > repmat(beta,1, cols(bols));
display(meanc(z'))

fprintf('These results should demonstrate to you the extent of the OLS bias. You may \n')
fprintf('wish to experiment with larger sample sizes. \n')

