function store = fRB2Kern(rho,b2)
% local m,n,p,q,store,i,j,bstar,sse,xstar,xtx,
% ixx,c22,rhomat,b2m;

global nu

store = 0 * rho .* b2; % /* define storage matrix */
m = rows(store); % /* obtain dimensions */
n = cols(store);
rhomat = rho .* (store + 1); % /* matrix of rho values */
b2m = (store + 1) .* b2; % /* matrix of b2 values */
i = 1;
while i <= m;
    j = 1;
    while j <= n;
        % /* carry out gls */
        [bstar,sse, xstar] = fNewb(rhomat(i,j));
        % /* define pieces of kernel */
        xtx = xstar'*xstar;
        ixx = invpd(xtx);
        c22 = ixx(2,2);
        % /* calculate kernel */
        store(i,j) = (sqrt(1 - rhomat(i,j)^2)*(sse^(-(nu + 1)/2))...
            /(sqrt(det(xtx))*c22))...
            /(1+((b2m(i,j)-1.672)^2)/(c22*sse))^((nu+1)/2);
        j = j + 1;
    end
    i = i + 1;
end
% retp(store);

return