% /***************************************************************/
% /* */
% /* PROC HARVEY -- ML estimation, by Method of Scoring, */
% /* of Multiplicative heteroskedasticity model */
% /***************************************************************/
function out = fHarvey(param0)

global x y z
% local b0,a0,bn,an,iter,crit,e,za,estar,xstar,q;
% /* Take apart initial parameter values */

k = cols(x);
b0 = param0(1:k,:);
a0 = param0(k+1:rows(param0),:);
% /* Set initial constants */
bn = b0;
an = a0;
iter = 1;
crit = 1;
% /* Start do-loop and print */
while (crit > 1e-8) && (iter <= 50);
    % " iter " iter " bn " bn� " an " an� " crit " crit;
    e = y - x*bn; % /* transform residuals and X */
    za = z*an;
    estar = e .* sqrt(exp(-za));
    xstar = x .* kron(ones(1,k), sqrt(exp(-za)));
    bn = b0 + (xstar\estar); % /* Equation 12.3.51 */
    q = (exp(-za) .* e.^2) - 1; % /* Equation 12.3.52 */
    an = a0 + (z\q);
    % /* check convergence */
    crit = maxc(abs([bn; an] - [b0; a0]));
    b0 = bn;
    a0 = an;
    iter = iter + 1;
end

out = [bn; an];
% retp(bn|an);
% endp;

return