function g = fGradCD(b)
% local g;

global x

g = [( fCD(b) ./ b(1,:) ) ( log(x(:,1)) .* fCD(b) ) ( log(x(:,2)) .* fCD(b) )];

% retp(g);

return

