function out=fPdft1(x,n)

out=(gamma((n+1)/2)/(sqrt(n)*gamma(0.5)*gamma(n/2))).*(1+x.*x/n).^(-(n+1)/2);

return