function [wNam, wMean, wVar, wStd, wMin, wMax, wValid, wMis]= fDstat(mInput)

wNam = repmat(size(mInput,1),1,size(mInput,2));
wMean =nanmean(mInput,1);
wStd = nanstd(mInput,1);
wVar = wStd.^2;
wMin = nanmin(mInput,[],1);
wMax = nanmax(mInput,[],1);
wValid = ~isnan(wStd);
wMis = isnan(wStd);


disp('        nam             mean           var           std          min            max          valid          mis')
disp([wNam' wMean' wVar' wStd' wMin' wMax' wValid' wMis'])
return