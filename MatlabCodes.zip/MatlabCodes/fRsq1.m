function out = fRsq1(beta)
global y

out = sum( (y - fFnb1(beta)).*(y - fFnb1(beta)),1);

return