close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 18 \n')
fprintf('Multiple-Time Series \n')
fprintf('18.1 Background \n')
fprintf('In this chapter time series techniques are applied to several economic variables \n')
fprintf('simultaneously. This allows the possibility that each random variable is affected \n')
fprintf('by and related to the rest. The specific model used to describe these multiple \n')
fprintf('time series is a Vector Autoregressive process, or VAR for short. \n')

fprintf('18.2 Vector Autoregressive Processes \n')
fprintf('In this Section the basic properties of a VAR(p) process for a vector of M \n')
fprintf('variables are explored. One important property is stationarity. A VAR(p) \n')
fprintf('process is stationary if the roots of polynomial (in z) defined by Equation 18.2.2 \n')
fprintf('are �outside the complex unit circle�. That is, if a root of the polynomial is real \n')
fprintf('it must be greater than one in absolute value. If a root is complex, and of the \n')
fprintf('form r = a + bi, where i =sqrt(-1) then sqrt(a)+sqrt(b)>1 \n')

fprintf('In Equation 18.2.4 an example of the problem is given for a VAR(1) process. \n')
fprintf('The matrix theta is given in Equation 18.2.5 and the polynomial is given just \n')
fprintf('below. Define the matrix theta and the polynomial coefficients. Then use the \n')
fprintf('GAUSS function POLYROOT to obtain the real and complex roots. \n')

theta1=[0.008 0.461; 0.232 0.297];
a0=1;
a1=sumc(diag(theta1));
a2=det(theta1);
a=[a2 -a1 a0];
lam=roots(a);
display(lam)

fprintf('In this case the roots are real and greater than 1 in absolute value. \n')
%%
close all;clear;clc

fprintf('18.3 Estimation and Specification of VAR Processes \n')
fprintf('In this Section estimators for the parameters of a VAR process are suggested \n')
fprintf('and their properties explored. In addition model selection procedures, for the \n')
fprintf('order of the process, are explained. First LOAD the data in file TABLE18.1 \n')
fprintf('and graph it against time. \n')

%LOAD the data from file TABLE18.1. The first column represents personal
%consumption and the second column disposable income.
load mDataTable18_1
dat=mDataTable18_1;
y1=dat(:,1);
y2=dat(:,2);
v=seqa(1,1,length(y1));

fprintf('Use the Quick-graphics command WINDOW to define two panels as in Figure \n')
fprintf('18.1. \n')

figure(1)
title('Figure 18.1 Changes in quarterly, seasonally adjusted U.S. per capita personal consumptio expenidtures and disposable income in 1972 dollars at annual rates 1951.II-1969.IV.')
subplot(2,1,1);
plot(v,y1)
legend('Consumption')
xlabel('Time')
ylabel('Consumption')

subplot(2,1,2);
plot(v,y2)
legend('Income')
xlabel('Time')
ylabel('Income')

fprintf('The order of the VAR process for the M = 2 time series will be selected using \n')
fprintf('the AIC and SC criteria developed in Section 17.2. In the context of time series \n')
fprintf('they are defined in Equations 18.3.15 and 18.3.16. Following the text we will \n')
fprintf('assume that the maximum order is n = 4. Create vectors containing the current \n')
fprintf('and lagged values of the two variables. \n')

fprintf('Place the current values of y1 and y2 in a matrix y and define the "X" matrix \n')
fprintf('as in (18.3.2). \n')

nlag=4;
y1t=y1(nlag+1:end-nlag,:);
y2t=y2(nlag+1:end-nlag,:);
vY=[y1t y2t];

ylag=[];
for i=1:nlag
    y1lagtmp=y1(nlag-(i-1):end-(nlag+i),:);
    y2lagtmp=y2(nlag-(i-1):end-(nlag+i),:);
    ylagtemp=[y1lagtmp y2lagtmp];
    ylag=[ylag ylagtemp];
end

t=rows(ylag);
%add constant
mX=[ones(t,1) ylag];

fprintf('Now write a proc that will estimate a VAR process given the matrices y and X. \n')
fprintf('Note that the parameter estimates can be obtain for all equations simultaneously \n')
fprintf('by using GAUSS DIVISION ( / ) since the X matrix is the same for each of the \n')
fprintf('equations (18.3.4). PROC VAR is long so place the code in a file and run it to \n')
fprintf('place in memory. \n')

fprintf('Now use PROC VAR to estimate the parameters of the VAR(4) process. Compare \n')
fprintf('your results to those in Equation 18.3.14. \n')

results1 =  fVar(vY, mX, nlag);

vnames =  ['y1',    
           'y2'];
fPrt(results1,vnames);   

sighat4=results1.sighat;

fprintf('To determine the order of the VAR process write a proc that will calculate the \n')
fprintf('model selection criteria in Equations 18.3.15 and 18.3.16. In addition calculate \n')
fprintf('the determinant of the contemporaneous covariance matrix. The arguments of \n')
fprintf('PROC VARSTAT are the matrix y and the X matrix which contains a column of \n')
fprintf('ones and lagged values of y for orders n = 0, 1, 2, 3 and 4. \n')

results2 =fVarStat(vY,mX);
%%
fprintf('Run PROC VARSTAT to place it in memory and then calculate the selection \n')
fprintf('criteria for successively larger orders of lags. Compare your results to those in \n')
fprintf('Table 18.2. Note that these tests are all based on the data created above which \n')
fprintf('has T = 67 complete observations. \n')

y1t=y1(5:71,1);
y1lag1=y1(4:70,1);
y1lag2=y1(3:69,1);
y1lag3=y1(2:68,1);
y1lag4=y1(1:67,1);

y2t=y2(5:71,1);
y2lag1=y2(4:70,1);
y2lag2=y2(3:69,1);
y2lag3=y2(2:68,1);
y2lag4=y2(1:67,1);

y=[y1t y2t];
t=rows(y1t);
%x=[ones(t,1) y1lag1 y2lag1 y1lag2 y2lag2 y1lag3 y2lag3 y1lag4 y2lag4];

x = ones(t,1); %/* n = 0 */
fVarStat(y,x);
x = [x y1lag1 y2lag1]; %/* n = 1 */
fVarStat(y,x);
x = [x y1lag2 y2lag2]; %/* n = 2 */
fVarStat(y,x);
x = [x y1lag3 y2lag3]; %/* n = 3 */
fVarStat(y,x);
x = [x y1lag4 y2lag4]; %/* n = 4 */
fVarStat(y,x);

%%
fprintf('Since the AIC and SC criteria obtain their minima at lag n = 1 we will use \n')
fprintf('a VAR(1) process to describe the data. Re-estimate the model assuming this \n')
fprintf('lag. Correct the definitions of y and X using T = 70 complete observations. \n')
fprintf('Compare your results to Equation 18.3.18. \n')
y1t = y1(2:71,1);
y1lag1 = y1(1:70,1);
y2t = y2(2:71,1);
y2lag1 = y2(1:70,1);
y = [y1t y2t];
t = rows(y1t);

fprintf('create x matrix and add constant \n')
x = [ones(t,1) y1lag1 y2lag1];
nlag = 1;
results3 = fVar(y, x, nlag);
vnames =  ['y1',    
           'y2'];
fPrt(results3,vnames);   
%%
fprintf('Optimal forecasting in the context of a VAR process means that the forecast \n')
fprintf('mean square error is minimized. The optimal h-step-forecasts are given in Equation \n')
fprintf('18.4.1 and recursions defined just below that equation. To implement these \n')
fprintf('forecasting techniques separate the estimated parameters PARM1 from the previous \n')
fprintf('section into the intercept (nu) and lag weights (theta1). \n')

parmFirstEq=results3(1).beta;
parmSecondEq=results3(2).beta;
parm1=[parmFirstEq parmSecondEq];

nu = parm1(1,:)';
theta1 = parm1(2:3,:)';

fprintf('Using starting period T = 71 forecast one and two periods into the future, \n')
fprintf('following Equation 18.4.2. \n')
y71 = dat(71,:)';
yhat1 = nu + theta1*y71;
display(yhat1)
yhat2 = nu + theta1*yhat1;
display(yhat2)

fprintf('The mean square error matrix of the forecasts is defined in Equations 18.4.3- \n')
fprintf('18.4.5. For the VAR(1) process we are using the MSE matrices are given in \n')
fprintf('Equations 14.4.6. \n')

sighat1 = results3.sighat;
sig1 = sighat1;
display(sig1)
sig2 = sighat1 + theta1*sighat1*theta1';
display(sig2)

fprintf('These MSE matrices and the asymptotic normality of the parameter estimators \n')
fprintf('can be used to construct forecast intervals as in (18.4.9) and (18.4.10). \n')

lb1 = yhat1 - 1.96*sqrt(diag(sig1));
ub1 = yhat1 + 1.96*sqrt(diag(sig1));
disp([lb1 ub1])
lb2 = yhat2 - 1.96*sqrt(diag(sig2));
ub2 = yhat2 + 1.96*sqrt(diag(sig2));
disp([lb2 ub2])

fprintf('One way to verify the model is to examine its forecasting accuracy. Note that \n')
fprintf('the actual observations for T = 72 and T = 73 fall inside the confidence intervals. \n')
display(dat(72,:))
display(dat(73,:))

%%
fprintf('18.5 Granger Causality \n')
fprintf('To test for the existence of causality in VAR models, as defined by Granger, \n')
fprintf('standard test procedures can be used. First test the hypothesis that y2 does \n')
fprintf('not cause y1 using the test statistic in Equation 18.5.5. In this context the \n')
fprintf('�unrestricted� estimates are given by the VAR(1) model above. The �restricted� \n')
fprintf('estimates are obtained by estimating the model assuming that the lagged value \n')
fprintf('of y2 does not significantly affect y1. That is, only the lagged value of y1 is \n')
fprintf('present in the model. \n')
y1t = y1(2:71,1); %/* define y1 and y1 lagged */
y1lag1 = y1(1:70,1);
t = rows(y1t); %/* define X */
x = [ones(t,1) y1lag1];
results4 = fVar(y1t,x); %/* restricted estimates */

fprintf('Compare your restricted estimates to those in Equation 18.5.6. Then calculate \n')
fprintf('the value of the test statistic which is defined just below (18.5.6). Under the \n')
fprintf('null hypothesis that y2 does not cause y1 it has an F-distribution with 1 and \n')
fprintf('T-3 degrees of freedom (asymptotically). \n')
sigr=results4.sighat;

lam = (sigr*(t-2) - sighat1(1,1)*(t-3))/sighat1(1,1);
% pval = cdffc(lam,1,t-3);
pval = fcdf(lam,1,t-3,'upper');
display(lam)
display(pval)

fprintf('On the basis of this test we reject the null hypothesis at the 1significance. As \n')
fprintf('is noted in the text, for the VAR(1) model an equivalent test can be carried \n')
fprintf('out using the t-statistics obtained when the VAR(1) model was estimated. You \n')
fprintf('may wish to check this if you have not printed out your results. \n')

fprintf('To illustrate a test of the hypothesis that income does not cause consumption \n')
fprintf('the VAR(4) process initially estimated will be used. The unrestricted estimates \n')
fprintf('are given by (18.3.14) which we estimated earlier. The restricted model is \n')
fprintf('obtained by estimating the model where y1 is determined only by its lagged \n')
fprintf('values. Estimate the model in (18.5.7) and carry out the joint test of significance. \n')
y1t = y1(5:71,1); %/* define y and lags */
y1lag1 = y1(4:70,1);
y1lag2 = y1(3:69,1);
y1lag3 = y1(2:68,1);
y1lag4 = y1(1:67,1);
t = rows(y1t); %/* define X */
x = [ones(t,1) y1lag1 y1lag2 y1lag3 y1lag4];
%{parmr,sigr} = var(y1t,x); /* estimate Eq. 18.5.7 */
results5 = fVar(y1t,x); %/* estimate Eq. 18.5.7 */
%Now carry out the test and note that the hypothesis is rejected at the 1% level.
sigr=results5.sighat;
lam = (sigr*(t-5) - sighat4(1,1)*(t-9))/(4*sighat4(1,1));
%pval = cdffc(lam,4,t-9);
pval = fcdf(lam,4,t-9,'upper');
display(lam)
display(pval)

%%
fprintf('18.6 Innovation Accounting and Forecast Error \n')
fprintf('Variance Decomposition \n')
fprintf('To trace the effect of a shock (or innovation) to the Multiple Time series system a \n')
fprintf('multiplier anaysis is useful. To trace the effect of a shock to income (y2) assume \n')
fprintf('that the values of y1 and y2 in period 0 are (0,1). Recursively predict the time \n')
fprintf('path of the variables as is done following (18.6.1). Note that for simplicity the \n')
fprintf('mean vector (nu) has been dropped. \n')
y0 = [0 1]';
y1hat = theta1*y0;
display(y1hat)
y2hat = theta1*y1hat;
display(y2hat)

fprintf('If a shock of one standard deviation in income were traced \n')
y0 = [0 ; sqrt(sighat1(2,2))];
y1hat = theta1*y0;
display(y1hat)
y2hat = theta1*y1hat;
display(y2hat)

fprintf('To carry out the innovation analysis in the system transformed to have contemporaneously \n')
fprintf('uncorrelated errors we must diagonalize the covariance matrix \n')
fprintf('sighat1. As noted in the text there are many ways to do this. First let P \n')
fprintf('be given by the Cholesky decomposition of the inverse of the contemporaneous \n')
fprintf('covariance matrix using the GAUSS command CHOL. \n')
p1 = chol(invpd(sighat1));
display(p1)

fprintf('Check to see if p1 diagonalizes sighat1 to an identity matrix, except for rounding \n')
fprintf('error. \n')
check = p1*sighat1*p1';
display(check)

fprintf('Calculate the inverse of P?1 and use it to construct the multiplier matrices in \n')
fprintf('(18.6.6). For the VAR(1) process the M matrices are powers of the parameter \n')
fprintf('matrix Theta1. \n')
invp1 = inv(p1);
display(invp1)

psi0 = eye(2)*invp1;
display(psi0)
m1 = theta1;
m2 = theta1*theta1;
psi1 = m1*invp1;
display(psi1)
psi2 = m2*invp1;
display(psi2)

fprintf('The income innovation (0,1) in this model is different from the effects in (18.6.3). \n')
w0 = [0 1]';
y0 = psi0*w0;
y1 = psi1*w0;
y2 = psi2*w0;
disp([y0 y1 y2])

fprintf('One problem with this analysis is that there are many P matrices that will diagonalize \n')
fprintf('the covariance matrix. For example, taking the inverse of the transposed \n')
fprintf('Cholesky decomposition also �works�. Check this. \n')
p = chol(sighat1);
p = inv(p');
p;
check = p*sighat1*p';
display(check)

fprintf('Naturally the innovation analysis is quite different and the form of P must be \n')
fprintf('selected on the basis of a priori information. \n')
fprintf('Another innovation analysis determines the percent of the MSE contributed \n')
fprintf('by the innovations. Using Equation 18.6.8 the two-step forecast variance of \n')
fprintf('consumption is \n')
f = psi0(1,1)^2 + psi1(1,1)^2 + psi0(1,2)^2 + psi1(1,2)^2;
display(f)

fprintf('Decomposing the contributions of y1 and y2 \n')
f1 = psi0(1,1)^2 + psi1(1,1)^2;
f2 = psi0(1,2)^2 + psi1(1,2)^2;

fprintf('The percent contributions are \n')
pctown = f1/f;
display(pctown)
pctinc = f2/f;
display(pctinc)


