function [d, c] = fEig(mInput, iPrint)

% Output: d is the vector of eigenvalues (also known as characteristic roots, latent roots or proper values) and c is
% the matrix of eigenvectors (also known as characteristic vectors, latent vectors or proper vector)

if nargin < 2 || isempty(iPrint)
    iPrint = 0;
end

[c, d] = eig(mInput);% In matlab with two outputs we get first the eigenvectors and then the eigenvalues
d=diag(d);% only want the diagonal, since we want only a column vector containing the eigenvalues to be compatible with the Gauss function eigrs2

% Note that GAUSS orders the characteristic roots and the corresponding characteristic
% vectors from smallest to largest. To conform to the text order the roots
% from largest to smallest and reverse the order of the columns of the matrix of
% characteristic vectors to match.
d = rev(d);
c = rev(c');

% Note that GAUSS returns C transpose and not C. Hence we tranpose here c \n')
% to keep the same notation as the manual. \n')
c = c';

% Due to the normalization issue of characteristic vectors, discussed in Chapter \n')
% 11 and 15, the sign of the last characteristic vector must be changed for us to exactly \n')
% replicate the data in ITPE2. \n')
% c(:,end) = -c(:,end);

if iPrint == 1
    fprintf('Eigenvalues \n')
    display(d)
    fprintf('Eigenvectors \n')
    display(c)
end

return