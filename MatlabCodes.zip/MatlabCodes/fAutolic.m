% /***************************************************************/
% /* PROC AUTOLIC -- Concentrated Log-Likelihood */
% /* for AR(1) errors */
% /***************************************************************/
function out = fAutolic(rho)

global x y

% local l1,k,T,dstar,ystar,dat,estar,phi,sigmasq,b,xstar;
k = cols(x);
t = rows(x);
%/* Transform the data */
dat = [y x];
dstar = dat - rho*[zeros(1,k+1); dat(1:t-1,:)];
dstar(1,:) = sqrt( 1 - rho^2)*dat(1,:);
ystar = dstar(:,1);
xstar = dstar(:,2:k+1);

% /* Compute b and sigmasq */
% /* See Equations 12.3.11 and 12.3.12 */
b = xstar\ystar;
estar = ystar - xstar*b;

sigmasq = (estar'*estar)/t;
% /* Compute components of the likelihood function */
phi = 1/(1 - rho^2);
l1 = log(2*pi*sigmasq) + log(phi)/t;
out = ( -l1 - ((estar.*estar)/sigmasq) );

return