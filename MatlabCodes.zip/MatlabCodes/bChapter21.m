close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 21 \n')
fprintf('Multicollinearity \n')
fprintf('21.1 Introduction \n')
fprintf('Economists and other social scientists use nonexperimental data. That is, the \n')
fprintf('data does not come from a controlled experiment. One frequent problem with \n')
fprintf('such data is that it is multicollinear. In this chapter the nature of the multicollinearity \n')
fprintf('problem is discussed. Methods of detection are presented and \n')
fprintf('various �cures� proposed. \n')
fprintf('An example of the consequences of multicollinearity for the least squares estimator \n')
fprintf('is provided by the Klein-Goldberger consumption function. LOAD the \n')
fprintf('data in file TABLE21.1 on your data disk and check it. \n')
% load dat[20,5] = table21.1;
% format 10,6;

load mDataTable21_1
dat = mDataTable21_1;
display(dat)

fprintf('The dependent variable in the model is consumption (C) and the explanatory \n')
fprintf('variables are three types of income (W, P, A). Construct the y vector and X \n')
fprintf('matrix. \n')
t = rows(dat);
y = dat(:,2);
x = [ones(t,1) dat(:,[3 4 5])];
k = cols(x);

fprintf('Use PROC OLS, written in Chapter 6, to obtain estimates of the parameters. \n')
fprintf('Make sure that the proc is in memory or where GAUSS can find it. Compare \n')
fprintf('your results to those in Table 21.2. \n')
[b, covb] = fMyOls(x,y, 0);
display(b)
display(covb)

fprintf('Construct the 95 \n')

stderr = sqrt(diag(covb));
lb = b - 2.12 .* stderr;
ub = b + 2.12 .* stderr;
display(lb)
display(ub)

fprintf('21.2 The Statistical Consequences of Multicollinearity \n')
fprintf('In this Section the statistical consequences of multicollinearity on the least \n')
fprintf('squares estimator are presented. In particular, multicollinearity adversely affects \n')
fprintf('the sampling variance of the OLS estimator. \n')
fprintf('21.3 Detecting the Presence, Severity, and Form \n')
fprintf('of Multicollinearity \n')
fprintf('Various strategies for detecting the nature of multicollinear data are discussed in \n')
fprintf('this Section. In Section 21.3.2 the Klein-Goldberger model is used to illustrate \n')
fprintf('these techniques. \n')
fprintf('First, construct the correlation matrix for the explanatory variables using the \n')
fprintf('standardization in Equation 21.3.2. \n')

xs = x(:,[2 3 4]);
xc = xs - repmat(meanc(xs), rows(xs), 1);
ssq = diag(xc'*xc);
xc = xc ./ repmat(sqrt(ssq)', rows(xc), 1);
corr = xc'*xc;
display(corr)

fprintf('Calculate the determinant of the correlation matrix and its inverse. The diagonal \n')
fprintf('of the inverse correlation matrix contains the variance inflation factors. \n')
detcorr = det(corr);
invcorr = inv(corr);
display('det corr : ') 
disp(detcorr)
display(' vif : ')
disp(diag(invcorr)')

fprintf('Use PROC OLS to calculate the auxiliary regressions in Table 21.4. If these \n')
fprintf('three lines are executed as a block, a touch to the space bar will let the next \n')
fprintf('line to execute. \n')
[b1, cov1] = fMyOls([ones(t,1) xs(:,[2 3])],xs(:,1));
display(b1)
display(cov1)
[b2, cov2] = fMyOls([ones(t,1) xs(:,[1 3])],xs(:,2));
display(b2)
display(cov2)
[b3, cov3] = fMyOls([ones(t,1) xs(:,[1 2])],xs(:,3));
display(b3)
display(cov3)

fprintf('The R2 values for the auxiliary regressions can also be obtained from the inverse \n')
fprintf('of the correlation matrix. \n')

auxr2 = 1 - (1 ./ diag(invcorr));
display('aux R2 :') 
disp(auxr2)

fprintf('To calculate Theil�s multicollinearity effect regress y on the explanatory variables, \n')
fprintf('deleting one at a time. \n')
[b1, cov1] = fMyOls([ones(t,1) xs(:,[1 2])],y); 
display(b1)
display(cov1)
[b2, cov2] = fMyOls([ones(t,1) xs(:,[1 3])],y);
display(b2)
display(cov2)
[b3, cov3]= fMyOls([ones(t,1) xs(:,[2 3])],y);
display(b3)
display(cov3)

fprintf('Calculate Theil�s measure. \n')
r2 = .9527;
Theil = r2 - (r2 - .9526) - (r2 - .9513) - (r2 - .8426);
display('Theil�s Measure') 
disp(Theil)

fprintf('Write PROC COLLIN which calculates the characteristic roots and condition \n')
fprintf('numbers of X�X in Table 21.5 as well as the table of variance proportions in Table \n')
fprintf('21.6. The argument X will be either the original X matrix or the normalized X \n')
fprintf('matrix given by Equation 21.3.3. Place PROC COLLIN in a file and run it. \n')

fprintf('Apply collinearity diagnostics to the original X matrix. \n')
collin(x);

fprintf('Apply the collinearity diagnostics to the normalized X matrix. \n')
ssq = diag(x'*x);
xn = x ./ repmat(sqrt(ssq)', rows(x), 1);
collin(xn);

fprintf('21.4 Solutions to the Multicollinearity Problem \n')
fprintf('In this Section various ways of introducing nonsample information are offered \n')
fprintf('as solutions to the problems caused by collinear data. The first is the use of \n')
fprintf('exact restrictions. Use PROC RLS written in Chapter 20 to impose the Klein- \n')
fprintf('Goldberger restrictions, discussed on page 876 of ITPE2, singly and jointly. \n')
fprintf('Make sure PROC RLS is in memory or where GAUSS can find it. Compare \n')
fprintf('your results to those in Table 21.7. \n')
fprintf('Use the first restriction alone. \n')
R1 = [0 -.75 1 0];
rr = 0;
[br,covbr] = fRls1(x,y,R1,rr);

fprintf('Use the second restriction alone. \n')
R2 = [ 0 -.625 0 1];
[br,covbr] = fRls1(x,y,R2,rr);

fprintf('Use the two restrictions together. \n')
R = [R1; R2];
rr = zeros(2,1);
[br,covbr] = fRls1(x,y,R,rr);

fprintf('The use of stochastic restrictions in this chapter is somewhat different than in \n')
fprintf('Chapter 20. The reason is that here it is not assumed that the error variance \n')
fprintf('is known. The appropriate modification of Equation 20.2.15 is made in PROC \n')
fprintf('MIXED given here. It takes as arguments x, y, r, rr, and psi and returns the \n')
fprintf('mixed estimator and its estimated covariance matrix. \n')

fprintf('Use PROC MIXED first with prior variance 1/64. \n')
psi = eye(2) ./ 64;
[bm,covbm] = fMixed(x,y,R,rr,psi);

fprintf('Then using prior variance 1/256. \n')
psi = eye(2) ./ 256;
[bm,covbm] = fMixed(x,y,R,rr,psi);

fprintf('Compare your results to those in Table 21.8. \n')

fprintf('In Section 21.4.3 the ridge regression estimator is presented. Write PROC \n')
fprintf('HKBRIDGE to compute the noniterative and iterative versions of the ridge estimator \n')
fprintf('using the Hoerl-Kennard-Baldwin estimator of �k� given in Equation \n')
fprintf('21.4.12. The proc takes x and y in unstandardized form as arguments and \n')
fprintf('returns the iterative estimates and estimated covariance matrix. \n')


fprintf('Now use PROC HKBRIDGE to obtain the ridge regression estimates of the parameters, \n')
fprintf('other than the intercept, as shown in Table 21.9. \n')
[bridge,covridge] = fHkbridge(x,y);
