function out = fCD(b)

global x

out = nan(rows(x), cols(b));

for i = 1:cols(b)
    out(:,i) = ((b(1,i) .* (x(:,1).^b(2,i)) .* (x(:,2).^b(3,i))));
end

return