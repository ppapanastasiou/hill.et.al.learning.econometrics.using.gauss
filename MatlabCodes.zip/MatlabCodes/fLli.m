function dLik = fLli(y, b, sigma2, iAlternative)
% likelihood function of the normal distribution

if (nargin<4 || isempty(iAlternative))
    iAlternative=0;
end

T = length(y);

if iAlternative==0
    dLik = -(T/2)*log(2*pi) -(T/2)*log(sigma2) - (1/2)*sum((y -b).^2)./sigma2;
else 
    sigma = sqrt(sigma2);
    dLik = sum(log(normpdf((y-b)./sigma)./sigma));
end

return

