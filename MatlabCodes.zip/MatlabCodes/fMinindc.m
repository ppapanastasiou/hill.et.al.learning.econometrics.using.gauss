function [wMinRowIndex, wMinValue] = fMinindc(mInput)
%The function fMinindxc gives the row index of the minimum element in a column.

[wMinValue, wMinRowIndex] = min(mInput);

return

