close all;clear;clc
format bank; % two decimal points
format loose
% format compact; 

fprintf('11.1 Introduction \n')
fprintf('In this chapter you will study two types of models involving sets of linear equations: \n')
fprintf('seemingly unrelated regression equations and pooled time series crosssectional \n')
fprintf('models. \n')

fprintf('11.2 Seemingly Unrelated Regression Equations \n')
fprintf('Begin with the example outlined in Section 11.2.4 in ITPE2. It concerns investment \n')
fprintf('for two companies, say General Electric and Westinghouse. LOAD \n')
fprintf('the data from TABLE11.1, check it, and create the the vectors y1 (column 1 \n')
fprintf('of Table 11.1) and y2 (column 4 of Table 11.1) containing the investment data. \n')
fprintf('The matrices of independent variables contain a constant term, market values \n')
fprintf('(columns 2 and 5 of Table 11.1), and capital stocks (columns 3 and 6 of Table \n')
fprintf('11.1.) \n')


load mDataTable11_1

dat=mDataTable11_1;
y1 = dat(:,1);
y2 = dat(:,4);
x1 = [ones(20,1) dat(:,[2 3])];
x2 = [ones(20,1) dat(:,[5 6])];

fprintf('Estimate each equation separately using least squares. (See Equation 11.2.31 \n')
fprintf('in the text.) \n')

b1 = x1\y1;
disp(b1)
b2 = x2\y2;
disp(b2)

fprintf('Compute the OLS residuals from the regressions, and use them to estimate the \n')
fprintf('contemporaneous covariance matrix. Note that the divisor used is the �average� \n')
fprintf('number of coefficients per equation. \n')
e1hat = y1 - x1*b1;
e2hat = y2 - x2*b2;
k1 = rows(b1);
k2 = rows(b2);
t = rows(y1);
df = t - (k1 + k2)/2;
shat = [e1hat e2hat]'*[e1hat e2hat]/df;
disp(shat)

fprintf('To compute the generalized least squares estimator, bg, first combine the data \n')
fprintf('to form one �stacked� model as shown in Equation 11.2.19 in the text. \n')

y = [y1;y2];
x = [[x1 zeros(t,k2)];[ zeros(t,k1) x2 ]];

fprintf('Next create the inverse of the estimated error covariance matrix for the stacked \n')
fprintf('error vector. See Equations 11.2.21 and 11.2.28 in the text. The .*. operator \n')
fprintf('produces the Kroneckor product. \n')

ishat = invpd(shat);
iphi = kron(ishat,eye(t));

fprintf('Now compute the generalized least squares estimate using Equation 11.2.28 in \n')
fprintf('the text. \n')

bg = (x'*iphi*x)\(x'*iphi*y);
disp(bg);

fprintf('This method works fine if the number of observations is small enough. However, \n')
fprintf('the matrix iphi has dimensions (MT x MT), where M is the number of equations, \n')
fprintf('and personal computers can quickly run into storage problems. Write a \n')
fprintf('procedure to do the same computations but without creating the entire iphi \n')
fprintf('matrix. See Equation ll.2.24 in the text. Note that all computations so far \n')
fprintf('assume that each equation contains the same number of observations. \n')
fprintf('The procedure SUR takes three arguments. The matrices x and y contain the \n')
fprintf('data. To use the procedure, the vectors of dependent variables and matrices \n')
fprintf('of independent variables are concatenated horizontally. For example, the y \n')
fprintf('matrix has as many columns as there are separate equations and as many rows \n')
fprintf('are there are observations per equation. The third argument, shat, contains \n')
fprintf('the estimated contemporaneous covariance matrix. The procedure returns the \n')
fprintf('variables xx, xty and std so that they can be used for later computations. The \n')
fprintf('name xty is given to x0y, rather than xy, to avoid confusion with the QUICK \n')
fprintf('GRAPHICS XY. \n')
fprintf('You may want to put the code for the procedure into a file (sur.prc) to rerun \n')
fprintf('at later dates; SUR is used repeatedly in this chapter. Also, be sure that you \n')
fprintf('understand how the GAUSS code used represents Equation 11.2.24. \n')

x = [x1 x2];
y = [y1 y2];
bga=fSur(x,y,shat);
disp(bga)
disp(bg)
% results.std
% results.xx
% results.xty


fprintf('As is noted in ITPE2 another way to estimate the parameters in a seemingly \n')
fprintf('unrelated regressions context is to iterate Equations (11.2.27) and (11.2.28). To \n')
fprintf('compute the iterative generalized least squares estimate, repeatedly estimate the \n')
fprintf('covariance matrix and the coefficients within a DO-LOOP. When the coefficients \n')
fprintf('cease to change (according to the specified tolerance), the estimation is complete. \n')
fprintf('In addition to stopping when convergence has been achieved, it is usually wise to \n')
fprintf('stop after a given number of iterations, since iterative procedures may converge \n')
fprintf('very slowly, if at all. \n')

tol = 1; %/* initialize tol */
iter = 1; %/* initialize iter */
%format 10,7; %/* begin loop */
while iter <= 20
    e1hat = y1 - x1*bg(1:k1,1); %/* new residuals */
    e2hat = y2 - x2*bg(k1+1:2*k1,1);
    shat = [e1hat e2hat]'*[e1hat e2hat]/t; %/* new contemp. cov. */
    [bga, xx, xty, std1]=fSur(x,y,shat); %/* new estimates */
    % use std1 instead of std since it colludes with the std function of matlab
    tol = sumc( abs(bga-bg)); %/* check tol. */
    iter = iter + 1; %/* update iter */
    bg = bga; %/* store current est.*/
    disp(iter) %/* print */
    disp(tol) %/* print */
end; %/* end loop */
disp(bga) %/* print estimates */
disp(std1) % use std1 instead of std since it colludes with the std function of matlab

fprintf('Note that at each iteration the variable tol decreases. In the first iteration the \n')
fprintf('starting values were the already obtained SUR estimates. The OLS estimates \n')
fprintf('could have been used and convergence to the same set of estimates obtained. \n')
fprintf('In Chapter 12 more will be said about maximum likelihood estimation. The \n')
fprintf('Iterative estimator of the SUR model is the maximum likelihood estimator of \n')
fprintf('this model if the random disturbances are multivariate normal. \n')
fprintf('Now carry out a Monte Carlo experiment that illustrates the small sample properties \n')
fprintf('of the SUR estimator. When SUR is based on an estimated contemporaneous \n')
fprintf('matrix the properties of EGLS estimators are asymptotic ones and do \n')
fprintf('not necessarily apply in small samples. Thus in this Monte Carlo experiment \n')
fprintf('we will be interested to see if the SUR estimates are more efficient than the OLS \n')
fprintf('estimates. \n')
fprintf('In order to simulate the data it must be possible to draw random numbers from \n')
fprintf('a multivariate normal distribution with a given error covariance matrix. Two \n')
fprintf('procedures are given in the Appendix to Chapter 11. We will illustrate the first \n')
fprintf('using characteristic roots and vectors, since that is how the data in Table 11.1 \n')
fprintf('is generated. As an exercise we will replicate the example in the appendix using \n')
fprintf('this method. Note that the GAUSS function CHOL performs the Cholesky \n')
fprintf('decompostion. \n')
fprintf('First obtain the characteristic roots and vectors of the matrix Sigma given on page \n')
fprintf('494. \n')
sigma= [1 1; 1 2];
[c, d] = eig(sigma);% In matlab with two outputs we get first the eigenvectors and then the eigenvalues
d=diag(d);% only want the diagonal, since we want only a column vector containing the eigenvalues to be compatible with the Gauss function eigrs2
disp([d c])

fprintf('Note that GAUSS orders the characteristic roots and the corresponding characteristic \n')
fprintf('vectors from smallest to largest. To conform to the text order the roots \n')
fprintf('from largest to smallest and reverse the order of the columns of the matrix of \n')
fprintf('characteristic vectors to match. \n')
d = rev(d);
c = (rev(c'));
disp([d c])

fprintf('Form the transformation matrix sighalf and compare to the text. \n')
sighalf = c * diagrv( eye(2), sqrt(d) );
disp(sighalf)


nsam = 250; %/* number of samples */
nr = t*nsam; %/* obs. to read */
f1=randn(10000,1);
% open f1 = nrandom.dat; %/* open file */
e1 = f1(1:nr); %/* read 250 samples */
e2 = f1(nr+1:nr+nr); %/* read 250 samples */
% f1 = close(f1); %/* close file */

fprintf('In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape \n')
fprintf('reshape(Data,N,T))Transpose in GAUSS is equivalent to reshape(Data,T,N) in MATLAB \n')
e1 = (reshape(e1,t,nsam)); %/* e1 is (T x 250) */
e2 = (reshape(e2,t,nsam)); %/* e2 is (T x 250) */
% save e1nor = e1; /* saved to e1nor.fmt */
% save e2nor = e2; /* saved to e2nor.fmt */

fprintf('To duplicate the Monte Carlo results in the text we will use the matrices of \n')
fprintf('N(0,1) already stored. LOADM them. \n')
% loadm e1 = e1nor;
% loadm e2 = e2nor;

fprintf('Recall that these matrices are (20 x 250) with each column representing a vector \n')
fprintf('from a multivariate N(0,I) distribution. To create a sample of size T = 20 from \n')
fprintf('a multivariate normal distribution with covariance matrix  given in Equation \n')
fprintf('11.2.33 create a (20 x 2) matrix of N(0,1) values from the first 2 columns of e1 \n')
fprintf('and apply a transformation like sighalf to each row. \n')
sigma =[660 175; 175 90];
[c, d] = eig(sigma);% In matlab with two outputs we get first the eigenvectors and then the eigenvalues
d=diag(d);% only want the diagonal, since we want only a column vector containing the eigenvalues to be compatible with the Gauss function eigrs2
% {d,c} = eigrs2(sigma);
d = rev(d);
c = (rev(c'));
sighalf = c * diagrv( eye(2), sqrt(d) );

fprintf('This transformation matrix will serve to transform the N(0,1) random errors to \n')
fprintf('the desired multivariate normal distribution. However, to obtain the numbers \n')
fprintf('in ITPE2 recall that characteristic vectors are not unique. In fact, if v is a \n')
fprintf('characteristic vector of a matrix then -v is as well. The normalization used in \n')
fprintf('GAUSS is the negative of the normalization used to create the data in Table \n')
fprintf('11.1 of ITPE2. While in general the choice does not matter, to replicate the \n')
fprintf('example in the text we change the sign of sighalf, and proceed to transform the \n')
fprintf('random errors. \n')
sighalf = -sighalf;
e = e1(:,[1 2]);
estar = e * sighalf';

fprintf('Define the parameter vectors to be those given in Equation 11.3.2 and construct \n')
fprintf('the vectors y1 and y2. Compare the values to those in Table 11.1. \n')
beta1 = [-28.0 0.04 0.14]';
beta2 = [-1.3 0.06 0.06]';
y1 = x1*beta1 + estar(:,1);
y2 = x2*beta2 + estar(:,2);
disp([y1 y2]);

fprintf('Write a program to simulate data and estimate the least squares and generalized \n')
fprintf('least squares estimates for two equations with equal numbers of coefficients. \n')
fprintf('The two matrices of independent variables, x1 and x2; the two vectors of true \n')
fprintf('parameters, beta1 and beta2; the true contemporaneous covariance matrix, \n')
fprintf('sigma; and the number of samples, nsam, must be specified. The procedure \n')
fprintf('SUR written above is used within this procedure (MCSUR), so make sure that \n')
fprintf('you have entered it and run it so that it is in memory. \n')
fprintf('Since this procedure is quite long, you may want to put it into a file: MCSUR.PRG. \n')


fprintf('/* Program to carry out a Monte Carlo experiment for \n')
fprintf('the Seemingly Unrelated Regressions model */ \n')
load mDataTable11_1 %/* load data */
dat=mDataTable11_1;

x1 = [ones(20,1) dat(:,[2 3])];
x2 = [ones(20,1) dat(:,[5 6])];
T = rows(x1);
k = cols(x1);
x = [x1 x2];

fprintf('/* define parameters */ \n')
beta1 = [-28.0 0.04 0.14]';
beta2 = [-1.3 0.06 0.06]';
xb = [(x1*beta1) (x2*beta2)];
nsam=250;
sigma = [660 175; 175 90];

fprintf('/* create transformation */ \n')
[c, d] = eig(sigma);% In matlab with two outputs we get first the eigenvectors and then the eigenvalues
d=diag(d);% only want the diagonal, since we want only a column vector containing the eigenvalues to be compatible with the Gauss function eigrs2
% {d,c} = eigrs2(sigma);
d = rev(d);
c = (rev(c'));

sighalf= -c * diagrv( eye(2), sqrt(d) );
% /* load random values */
% loadm e1 = e1nor;
% loadm e2 = e2nor;
% /* storage matrix */
param = zeros(4*k,nsam);
i = 1; %/* start loop */
while i < nsam;
    if i <= 125; %/* select error vectors */
        c2 = 2*i;
        c1 = c2-1;
        e = e1(:,[c1 c2]);
    else
        c2 = 2*(i-125);
        c1 = c2-1;
        e = e2(:,[c1 c2]);
    end;
    e = e*sighalf'; %/* transform errors */
    y = xb + e; %/* create y */
    b1 = x1\y(:,1); %/* ols */
    b2 = x2\y(:,2);
    ehat = [(y(:,1) - x1*b1) (y(:,2) - x2*b2)];
    shat = ehat'*ehat/(t-k); %/* sur */
    bg = fSur(x,y,shat);
    param(:,i) = [b1;b2;bg]; %/* store estimates */
    i = i + 1;
end %/* end loop */
m = mean(param'); %/* Calculate means */
m=m';
std2 = std(param'); %/* Calculate Std Errors */
std2 = std2'; % use std2 instead of std since it colludes with the std gauss function of matlab

disp([[beta1;beta2] m(1:6,:) std2(1:6,:) m(7:12,:) std2(7:12,:)]);
% /* End of Program */

fprintf('Execute the program and compare the results to Table 11.2 in the text. \n')
fprintf('Use histograms to compare the distributions of the least squares and GLS estimators \n')
fprintf('of the second parameter in the first equation. To obtain histograms just \n')
fprintf('like those in the top panel of Figure 11.1 we must use the same �breakpoints� \n')
fprintf('as in the text. These are given in the vector v1 below. \n')

v1 =[.0111 .0253 .0395 .0537 .0679]';
fprintf('So that you can reproduce the 2nd, 3rd and 4th panels of Figure 11.1, the \n')
fprintf('breakpoints to use are: \n')
v2 = [.0959 .119 .141 .164 .186]';
v3 = [.0291 .0446 .0601 .0757 .0912]';
v4 = [-.0373 .0121 .0616 .111 .161]';

fig = figure(1);
set(fig, 'Color', 'white')
subplot(4,2,1);
hist(param(2,:)',v1);
% axis tight
subplot(4,2,2);
hist(param(8,:)',v1);
% axis tight

subplot(4,2,3);
hist(param(3,:)',v2);
% axis tight
subplot(4,2,4);
hist(param(9,:)',v2);
% axis tight

subplot(4,2,5);
hist(param(5,:)',v3);
% axis tight
subplot(4,2,6);
hist(param(11,:)',v3);
% axis tight

subplot(4,2,7);
hist(param(6,:)',v4);
% axis tight
subplot(4,2,8);
hist(param(12,:)',v4);
% axis tight

fprintf('In Section 11.2.5 of the text there is a discussion of methods used to test hypotheses \n')
fprintf('in the SUR model. In Section 11.2.6 an example of those tests is given. \n')
fprintf('LOAD the data in the file TABLE11.3 on the disk accompanying this text. Take \n')
fprintf('natural logs to create the dependent and independent variables for each equation. \n')
fprintf('The data consist of thirty observations on prices, quantities and income \n')
fprintf('for three commodities. \n')

load mDataTable11_3;
dat=mDataTable11_3;
t = rows(dat);
c = ones(t,1);
lnd = log(dat);
x1 = [c lnd(:,[1 4])];
x2 = [c lnd(:,[2 4])];
x3 = [c lnd(:,[3 4])];
y1 = lnd(:,5);
y2 = lnd(:,6);
y3 = lnd(:,7);

fprintf('Compute the least squares estimates and compare them to the values in Table \n')
fprintf('11.4 of ITPE2. \n')
b1 = x1\y1;
b2 = x2\y2;
b3 = x3\y3;
disp('first column in Table 11.4')
disp([b1; b2; b3;]);

fprintf('Compute the residuals from the least squares estimates, and estimate the contemporaneous \n')
fprintf('covariance matrix. \n')
y = [y1 y2 y3];
ehat = y - [(x1*b1) (x2*b2) (x3*b3)];
k = rows(b1);
shat = ehat'*ehat/(t-k);

fprintf('Write a function to compute the squared correlations in Equation 11.2.35. \n')

fprintf('Using CORR, compute the Lagrange multiplier statistic to test for contemporaneous \n')
fprintf('correlation. See Equation 11.2.34. Under the null hypothesis of no \n')
fprintf('contemporaneous correlation, the test statistic lambda has a 23 \n')
fprintf('distribution, in \n')
fprintf('this case. Compare to the value given on p.461 of ITPE2. \n')
lambda = t*(fCorr(2,1,shat) + fCorr(3,1,shat) + fCorr(3,2,shat));
disp(lambda)
chi2cdf(lambda,3,'upper');

fprintf('Compute the generalized least squares estimates, using the procedure SUR written \n')
fprintf('above in Section 11.2.3. Compare your results to those in Table 11.4. \n')

x = [x1 x2 x3];
[bg, xx, xty, std1] = fSur(x,y,shat);

fprintf('use std1 instead of std since it colludes with the std gauss function of matlab \n')
fprintf('Print the results and compare to the second column of Table 11.4. \n')
disp('second column in Table 11.4')
disp([bg std1])

fprintf('Now estimate a restricted model requiring that the price elasticities be the \n')
fprintf('same for all three commodities (the price is the second column of the relevant \n')
fprintf('X matrix). First write the restrictions in matrix format: R = r, where is \n')
fprintf('the vector of unknown parameters. \n')
r = zeros(2,9);
r(1,2) = 1;
r(2,2) = 1;
r(1,5) = -1;
r(2,8) = -1;
rr = zeros(2,1);
disp([r rr])

fprintf('Following Equations 11.2.39 through 11.2.43 in the text, estimate the restricted \n')
fprintf('seemingly unrelated regression estimator. Note that the matrix xx was automatically \n')
fprintf('returned from memory when bg was estimated. It is equal to \n')
fprintf('XTranspose(Sigmahat^(-1) KronIt)X or C^(-1) in the text. \n')
chat = invpd(xx);
qq = chat*r'*invpd(r*chat*r');
bgr = bg + (qq*(rr - r*bg));

fprintf('The covariance matrix of the estimated parameters is: \n')
covbgr = chat - qq*r*chat;

fprintf('Print the results and compare to the third column of Table 11.4. \n')
disp('third column in Table 11.4')
disp([bgr sqrt(diag(covbgr))])

fprintf('Write a procedure to compute the restricted generalized least squares estimator. \n')
fprintf('It takes as its arguments the output from the unrestricted estimates, bg and xx, \n')
fprintf('and the matrices describing the constraints, r and rr. \n')

fprintf('Use the procedure SUR written above to compute the least squares estimates \n')
fprintf('of the three equations and the matrix xx. Do this by setting shat equal to an \n')
fprintf('identity matrix, thereby assuming no contemporaneous correlation. (Note that \n')
fprintf('the computed standard errors will not be correct in this case, but that they are \n')
fprintf('not used in any of the following computations.) \n')
shat = eye(3);
[b, xx, xty, std1] = fSur(x,y,shat);

fprintf('use std1 instead of std since it colludes with the std function of matlab \n')
fprintf('Now compute the restricted generalized least squares (SUR) estimates using \n')
fprintf('glsr. Verify that the estimates satisfy the constraints. \n')
[br, covbgr] = fGlsr(b,xx,r,rr);
disp(r*br)

fprintf('Compute the restricted least squares residuals. Use them to compute the contemporaneous \n')
fprintf('covariance matrix. \n')
br1 = br(1:3,1);
br2 = br(4:6,1);
br3 = br(7:9,1);
erls = y - [(x1*br1) (x2*br2) (x3*br3)];
shat = erls'*erls/(t-k);

fprintf('Compute a new generalized least squares estimate using the new, restricted, \n')
fprintf('estimate shat. \n')
[bgn, xx, xty, std1] = fSur(x,y,shat);

fprintf('use std1 instead of std since it colludes with the std function of matlab \n')
fprintf('Now compute the restricted generalized least squares estimate and compare \n')
fprintf('these results to the last column of Table 11.4. Slight differences may be present \n')
fprintf('due to rounding error. \n')
[bgrn, covbgrn] = fGlsr(bgn,xx,r,rr);
disp('last column in Table 11.4')
disp([bgrn sqrt(diag(covbgrn))])

fprintf('In Section 11.2.7 the problem of unequal numbers of observations in SUR equations \n')
fprintf('is discussed. \n')
fprintf('Load in the data from Table 11.1 in the text again, this time dropping the last \n')
fprintf('five observations for the first equation. \n')
% load dat[20,6] = table11.1;

load mDataTable11_1
dat = mDataTable11_1;
y1 = dat(1:15,1);
x1 = [ones(15,1) dat(1:15,[2 3])];
y2 = dat(:,4);
x2 = [ones(20,1) dat(:,[5 6])];
t = rows(y1);
n = rows(y2) - t;

fprintf('Compute the least squares coefficients. \n')
b1 = x1\y1;
b2 = x2\y2;
disp(b1)
disp(b2)

fprintf('Compute the generalized least squares estimates, dropping the last five observations \n')
fprintf('for the second group so that the sample sizes are the same. Use the \n')
fprintf('procedure SUR written in Section 11.2.3 above and using the correction in \n')
fprintf('Equation 11.2.60 \n')
e1 = y1 - x1*b1;
e2 = y2 - x2*b2;
ehat = [e1 e2(1:15,1)];
shat = ehat'*ehat/t;
shat(2,2) = e2'*e2/(t+n); 
[bb, xx, xty, std1] = fSur([x1 x2(1:15,:)], [y1 y2(1:15,:)],shat);
disp(shat)
disp(bb)

fprintf('This time adjust xx and xty to use all observations in the data set. (See \n')
fprintf('Equation 11.2.59 in the text.) \n')
x20 = x2(16:20,:);
y20 = y2(16:20,1);
xxadd = (x20'*x20)/shat(2,2);
xyadd = (x20'*y20)/shat(2,2);
xx(4:6,4:6) = xx(4:6,4:6) + xxadd;
xty = sumc(xty') + ( [zeros(3,1); xyadd] );
bg = xx\xty;
fprintf('See page 465 in ITPE2 \n')
disp(bg')
disp(sqrt(diag(invpd(xx)))')

fprintf('11.3 Pooling Time Series and Cross-Sectional \n')
fprintf('Data Using Dummy Variables \n')
fprintf('In this section you will apply the dummy variable techniques of Chapter 10 to \n')
fprintf('the problem of pooling Time-Series and Cross-Sectional (TSCS) data. LOAD in \n')
fprintf('the data from the file TABLE11.1 on the disk accompanying this book. Columns \n')
fprintf('1 � 4 contain cost data for four different firms, and columns 5 � 8 contain output \n')
fprintf('data for the four firms. Examine the data. \n')
fprintf('load dat[10,8] = table11.5; \n')
load mDataTable11_5
dat=mDataTable11_5;
n = 4;
t = rows(dat);

% format 8,4;
disp(dat)
fprintf('Compute the means of each column of data, and use the vector of means, mn, to \n')
fprintf('compute deviations from the mean for each column of data. Call the matrix of \n')
fprintf('deviations from the mean ddat. Note that we can take advantage of GAUSS�s \n')
fprintf('elementwise operations to subtract a row from the data matrix. Compare the \n')
fprintf('result to Table 11.6 in ITPE2. \n')
mn = mean(dat);
mn=mn';
disp(mn)
ddat = dat - repmat(mn',rows(dat),1);
disp(ddat)

fprintf('Take the observations on cost (deviations from the mean) and put them in a \n')
fprintf('single column vector using the GAUSS function VEC. Do the same for the observations \n')
fprintf('on output. This stacks the data on the slope variables as in Equation \n')
fprintf('11.4.13�11.4.16 \n')
dy = ddat(:,1:4);
w = vec(dy);
dx = ddat(:,5:8);
z = vec(dx);

fprintf('Compute the slope coefficient using least squares. Remember that this estimate \n')
fprintf('of the slope coefficient is equivalent to a least squares regression with dummy \n')
fprintf('variables for each firm (omitting the constant term). \n')
bs = z\w;

fprintf('See page 477 in ITPE2 \n')
disp(bs)

fprintf('Compute the N intercept terms using Equation 11.4.10 and the means computed \n')
fprintf('above. \n')
b1 = mn(1:4,1) - mn(5:8,1)*bs;

fprintf('See page 477 in ITPE2 \n')
disp(b1)

fprintf('Compute the estimate of the error variance which is assumed to be constant \n')
fprintf('across the firms. Use Equation 11.4.18. \n')
k1 = rows(bs);
ehat = w - z*bs;
sse = ehat'*ehat;
sighat2 = sse/(n*t - n - k1);

fprintf('See page 477 in ITPE2 \n')
disp(sighat2)

fprintf('Estimate the variance of the estimated slope parameter and its standard deviation. \n')

covbs = sighat2*invpd(z'*z);
sqrt(covbs);

fprintf('Your results should agree with those on pages 477-478 of the text. As an exercise, \n')
fprintf('apply OLS (use PROC MYOLS) to the model including the dummy variables \n')
fprintf('for the intercepts to verify, in this small model, that the results are the same. \n')
fprintf('First create y vector and X matrix as shown in Equations 11.4.4 and 11.4.5. \n')
y = dat(:,1:4);
y = vec(y);
xs = dat(:,5:8);
xs = vec(xs);
x = [kron(eye(n),ones(t,1)) xs];
% x = ( eye(n) .*. ones(t,1) )~xs;

fprintf('Now make sure PROC MYOLS is in memory or can be found by the GAUSS \n')
[b, covb] = fMyOls(x,y);


fprintf('Next, carry out the F-test for the hypothesis that all the intercepts are equal. \n')
fprintf('Compute the least squares coefficients this time constraining all of the intercepts \n')
fprintf('to be equal. Use the vector y just created and add a column of ones to xs to \n')
fprintf('create the X matrix. model. \n')
x = [ones(n*t,1) xs];
b = x\y;
disp(b)

fprintf('Compute the sum of squared residuals from the restricted regression and call it \n')
fprintf('sser. \n')
ehatr = y - x*b;
sser = ehatr'*ehatr;
disp(sser)

fprintf('Test the null hypothesis that the intercepts are equal. \n')
df1 = n-1;
df2 = n*t - n - k1;
fstat = (sser - sse)/(df1*sighat2);

fprintf('See page 479 in ITPE2 \n')
disp(fstat)
fcdf(fstat,df1,df2,'upper');

fprintf('11.4 Pooling Time Series and Cross-Sectional \n')
fprintf('Data Using Error Components \n')
fprintf('In this section the assumption is made that the intercepts of each firm are random \n')
fprintf('instead of fixed, and consist of a �mean� intercept and a random component. \n')
fprintf('The appropriate estimator for this model is the genreralized least squares \n')
fprintf('estimator, and the steps involved are summarized on pages 485-486 of ITPE2. \n')
fprintf('1. Calculate the dummy variable estimator, which is simply the estimator of \n')
fprintf('the slope parameter (bs) computed in the previous section. \n')
disp(bs)

fprintf('2. Use the residuals from (1) to calculate the unbiased estimate of the error \n')
fprintf('variance. Again, this we have calculated above. \n')
disp(sighat2)

fprintf('3. Estimate beta using the observations on the individual means, as in (11.5.27). \n')
mny = mn(1:4,1);
mnx = [ones(4,1) mn(5:8,1)];
bstar = mnx\mny;
disp(bstar)

fprintf('4. Compute the residuals from (3). Use these residuals to calculate (11.5.28) \n')
k = rows(bstar);
vstar = mny - mnx*bstar;
sig1 = t * (vstar'*vstar)/(n - k);

fprintf('See page 487 in ITPE2 \n')
disp(sig1/t)

fprintf('5. Use the estimates sig1 and sighat2 to estimate 2u \n')
fprintf('as in Equation 11.5.30. \n')
sigu2 = (sig1 - sighat2)/t;

fprintf('See page 487 in ITPE2 \n')
disp(sigu2)

fprintf('If sigu2 is negative, then the researcher is advised to rethink the model \n')
fprintf('formulation rather than proceeding in an ad hoc manner. \n')
fprintf('6. Calculate alphahat \n')
alphahat = 1 - sqrt(sighat2/sig1);

fprintf('See page 487 in ITPE2 \n')
disp(alphahat)

fprintf('7. Transform the data by subtracting the fraction alphaof their means. \n')
sdat = dat - repmat(alphahat*mn',rows(dat),1);
sy = vec(sdat(:,1:4));
sx = vec(sdat(:,5:8));

fprintf('8. Add an intercept to the matrix of explanatory variables and obtain the \n')
fprintf('EGLS estimator of the variance components model by applying OLS to \n')
fprintf('the transformed data. Note that the intercept must be transformed as \n')
fprintf('well. \n')
sx = [(ones(n*t,1)-alphahat) sx];
bhathat = sx\sy;

fprintf('See page 488 in ITPE2 \n')
disp(bhathat)
sehat = sy - sx*bhathat;
sighate = sehat'*sehat/(rows(sx) - cols(sx));
covbhat = sighate * invpd(sx'*sx);
stderr = sqrt(diag(covbhat));

fprintf('See page 488 in ITPE2 \n')
disp(stderr)

fprintf('Next we consider the problem of �predicting� the random components. Compute \n')
fprintf('the residuals using the generalized least squares estimator. Then reshape \n')
fprintf('the column vector of residuals into a (N x T) matrix so that the first column \n')
fprintf('contains the residuals for the first firm, the second column for the second firm, \n')
fprintf('etc. To predict the random components, sum the residuals for each firm and \n')
fprintf('multiply by sigma2_u/sigma2_1 as in Equation 11.5.31. \n')
ehathat = y - x*bhathat;

fprintf('In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape \n')
fprintf('reshape(Data,N,T))Transpose in GAUSS is equivalent to reshape(Data,T,N) in MATLAB \n')
ui = (sigu2/sig1)*sumc(reshape(ehathat,t,n));
fprintf('There seems to be a bug here since I can not replicate the results of page 488 in ITE2  \n')
disp(ui)

fprintf('Compare these answers with the corrsponding estimates from the dummy variable \n')
fprintf('estimator by taking the deviation from the means of the dummy variables \n')
fprintf('as suggested near the bottom of page 488. The estimated intercepts b1 should \n')
fprintf('still be in memory. \n')
uidv = b1 - mean(b1);
disp(uidv)

fprintf('Finally, test the specification by testing whether individual components exist. \n')
fprintf('Calculate the value of the Lagrange multiplier test statistic to test the null \n')
fprintf('hypothesis that sigma2_u is equal to zero. See Equation 11.5.32 in the text. \n')
fprintf('In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape \n')
fprintf('reshape(Data,N,T))Tranpose in GAUSS is equivalent to reshape(Data,T,N) in MATLAB \n')
eje = sumc( sumc(reshape(ehatr,t,n)).^2 );
ratio = eje/(ehatr'*ehatr);
lambda = (n*t/(2*(t-1))) * (ratio - 1)^2;
disp(lambda)
disp(chi2cdf(lambda,1,'upper'))

fprintf('11.5 The Choice of Model for Pooling \n')
fprintf('In this section a variety of factors are presented for consideration when trying \n')
fprintf('to decide which model, the dummy variable or error components model, to use \n')
fprintf('in a particular application. One factor to consider is whether the random error \n')
fprintf('components are correlated with the X data using the Hausman specification \n')
fprintf('error test. \n')
fprintf('Compute the Chi-square statistic for the Hausman test given in Equation 11.6.2 \n')
fprintf('in the text. Rejection of the null hypothesis that the slope coefficients are \n')
fprintf('the same in the two models suggests that the error components model is not \n')
fprintf('appropriate. \n')
k = rows(bhathat);
bdif = (bs - bhathat(2:k,1));
mdif = covbs - covbhat(2:k,2:k);
m = bdif'*invpd(mdif)*bdif;
disp(m)
disp(chi2cdf(m,k-1,'upper'))

fprintf('What do you conclude? \n')



