function bstar=fRls(b,r,rr,x)

ixx = invpd(x'*x);
q = invpd(r*ixx*r');
bstar = b + ixx*r'*q*(rr-r*b);

return