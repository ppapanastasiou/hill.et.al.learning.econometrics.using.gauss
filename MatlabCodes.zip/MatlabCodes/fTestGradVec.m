function [ vFx ] = fTestGradVec( vX )
% fTestGradVec.m
% Testfunktion zur Approximation des Gradienten einer 
% vektoriellen Funktion
%
% Input:
%   vX:  2 x 1 Vektor, Stelle, an welcher der Funktionswert berechnet wird
%
% Output:
%   vFx: 2 x 1 Vektor der Funktionswerte
%
% Version: Februar 2014
%
% Copyright (c) 2013, Th. Poddig, A. Varmaz, Ch. Fieberg
%
% Bestandteil des Buchs: 
% Computational Finance von Th. Poddig, A. Varmaz, Ch. Fieberg

vFx = NaN(2,1);

% y1 = 4 * x(1)^2 - 5 * x(1) * x(2) - 3 * x(2)^2

vFx(1) = 4 * vX(1)^2 - 5 * vX(1) * vX(2) - 3 * vX(2)^2;

% y2 = 3 * x(1) + 2 * x(2)

vFx(2) = 3 * vX(1) + 2 * vX(2);

end