function vOut=fInvcdfx(f)

vOut = -log(1-f)/3;

return