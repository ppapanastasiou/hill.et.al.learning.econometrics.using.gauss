function out = fNewRho(b)

global y x t

% local e;
e = y - x*b;
out = e(1:t-1,:)\e(2:t,:);

return