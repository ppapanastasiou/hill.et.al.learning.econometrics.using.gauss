% /***************************************************************/
% /* */
% /* PROC HETEROLI -- Log likelihood for multiplicative */
% /* heteroskedastic errors */
% /***************************************************************/
function out = fHeteroli(param0)

global x z y

% local k,b,alpha,za,e,const;
% /* Take apart the parameter vector */
k = cols(x);
b = param0(1:k,:);
alpha = param0(k+1:rows(param0),:);
% /* Compute the log likelihood */
za = z*alpha;
e = y - x*b;
const = -log(2*pi)/2;
% retp(const - za/2 - exp(-za).*e.*e/2 );
out = (const - za/2 - exp(-za).*e.*e/2 );
% endp;

return

