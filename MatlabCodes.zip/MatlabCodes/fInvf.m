function fstat=fInvf(df1,df2,alpha)

fstat=0.95 + 0.05*minindc(abs(fcdf( seqa(1,.05,2000),df1,df2, 'upper')-alpha ));

return