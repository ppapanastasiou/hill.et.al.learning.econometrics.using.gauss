% /***************************************************************/
% /* PROC NLS --- Non-linear Least Squares */
% /* using numerical derivatives */
% /***************************************************************/
function [b0, z] = fNLS(b0, FI, x, y, iPrint)

if nargin <5 || isempty(iPrint)
    iPrint =1;
end

% local FI:proc;
% local *;
crit = 1; % /* Initialize values */
iter = 1;
s = 0;
k = rows(b0);
dh = 1e-6; %/* Values used in gradients*/
e = eye(k)*dh;
while (iter <= 25) && (all(crit > 1e-8)); % /* Begin do loop */
    % /* Compute numerical gradients */
    % /* Could use z = gradp(&FI,b0); */
    % Win codes http://www.aae.wisc.edu/aae637/main.asp
    % numobs = rows(y);
    % z = Grad(b0,FI,numobs);
    % Poddig codes
    % z2 = fGradApprox(FI,b0)
    tmp = repmat(b0, 1, cols(e));
    z = (FI(tmp + e) - FI(tmp - e))/(2*dh);
    u = y - FI(b0); % /* Compute residuals */
    sse = u'*u; % /* Compute sum of sqrd res. */

    % crit = solpd(z�u,z�z); /* Compute full step adjust */
    crit = z'*z\z'*u; % /* Compute full step adjust*/
    % gosub step; /* Compute step length */

    % step: /* Subroutine for step length */
    s = 2;
    ss1 = 2; ss2 = 1;
    while ss1 >= ss2;
        s = s/2;
        % u1 = y - FI(b0 + s*crit);
        u1 = y - FI(b0 + s*crit);
        % u2 = y - FI(b0 + s*crit/2);
        u2 = y - FI(b0 + s*crit/2);
        ss1 = u1'*u1;
        ss2 = u2'*u2;
    end
    % return;

    b = b0 + s*crit; % /* Update parameters */
    % gosub prnt; /* Print results for iter�n */
    iter = iter + 1; % /* Update for next iter�n */
    crit = abs(b - b0);
    b0 = b;
end
% /* Compute covariance matrix */
sighat2 = sse/(rows(y) - k);
covb = sighat2*invpd(z'*z);
% /* Print out final results */
% " Final Results: ";
% " Coefficients : " b0�;
% " Std. Errors : " sqrt(diag(covb))�;
% " Sighat2 : " sighat2;
% retp(b0,z);

if iPrint ==1
    %print out
    disp('Final Results:')
    disp('Coefficients:')
    disp(b0)
    disp('Std. Errors:')
    disp(sqrt(diag(covb)))    
    disp('Sighat2:')
    disp(sighat2)
end

% prnt: /* Subroutine for printing */
% format 4,2; " i = " iter;;
% format 4,2; " Steplength = " s;;
% format 10,6; " SSE = " sse;
% " b = " b0�;?;
% return;
% endp;

return