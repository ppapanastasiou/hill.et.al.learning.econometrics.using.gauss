clear;close all;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 5 \n')
fprintf('Linear Statistical Models \n')
fprintf('5.1 Introducton \n')
fprintf('In this Chapter the fundamentals of the Classical Linear Regression Model \n')
fprintf('(CLRM) are considered. The chapter begins with a simple linear model for \n')
fprintf('the mean of a population, evolves into a 2-variable regression model and then \n')
fprintf('to the Multiple regression model. This handbook will present the GAUSS \n')
fprintf('commands that replicate numerical examples, and thus providing a basis for all \n')
fprintf('linear model estimation. \n')
fprintf('5.2 Linear Statistical Model 1 \n')
fprintf('In this section it is noted that the model given in (3.2.2a), in which a random \n')
fprintf('variable has a mean and varinace, is a linear model. Familiar assumptions are \n')
fprintf('put into vector and matrix notation. It is important to master this notation, as \n')
fprintf('it will be the basis for all future work. \n')
fprintf('5.3 Linear Statistical Model 2 \n')
fprintf('In this section computations associated with the Example in Chapter 5.3.6 of \n')
fprintf('ITPE2 will be carried out. The data on Consumption and Income in Table 5.1 \n')
fprintf('in the text is contained in the file TABLE5.1 on the disk available with this \n')
fprintf('book. The regression model relates consumption to income. \n')
fprintf('First, LOAD the data, which is in an ASCII file. Insert a column of ones in the \n')
fprintf('first column to represent the �intercept� variable. Print and examine the data \n')
fprintf('to confirm it is identical to that in the text. \n')

load mDataTable5_1;
dat=mDataTable5_1;
y = dat(:,1);
x = dat(:,2);
x = [ones(20,1) x];
%format 8,4;
disp([y x])

fprintf('You now have the data set represented by the vector y and the matrix X but \n')
fprintf('you do not know the true parameters, beta, or the variance of the error term, \n')
fprintf('2. We need to solve the system of linear equations (5.3.8b) represented by \n')
fprintf('xTx*b = xTy. Use Equation (5.3.11). There are several GAUSS functions that \n')
fprintf('invert matrices. See your GAUSS manual for a description of INV, INVPD \n')
fprintf('and SOLPD. \n')
fprintf('To show the intermediate results follow the sequence of steps outlined in Equations \n')
fprintf('(5.3.22c and 5.2.23. First form the inverse of X0X and X0y and print. \n')
ixx = inv(x'*x);
xty = x'*y;
% format 14,10;
% [ixx xty]

fprintf('Note that X0y is named XTY instead of XY to avoid confusion with the GAUSS \n')
fprintf('QUICK GRAPHICS proc. Now compute the least squares estimates. \n')
b = ixx*xty;
%format 8,5;
disp(b); % ; /* Eq. 5.2.23 */

fprintf('The most efficient way to solve the equations in GAUSS is to use the matrix \n')
fprintf('/ operator. That is, b = inv(x0x)  (x0y) = (x0y)/(x0x) = y/x. \n')
b = x\y;
disp(b);

fprintf('Compute the least squares residuals and the sum of squared errors. \n')
ehat = y - x*b;
sse = ehat'*ehat;
%sse

fprintf('Next compute the degrees of freedom. In general, T is the number of rows in \n')
fprintf('the matrix x and k is the number of columns in x. The degrees of freedom is \n')
fprintf('the difference. \n')
t = rows(x);
k = cols(x);
df = t - k;
df;
fprintf('The estimate of the error variance 2 is sse/df. \n')
sighat2 = sse/df;
disp(sighat2) %/* Eq. 5.3.25 */

fprintf('Estimate the variance-covariance matrix of the LS estimator. The function \n')
fprintf('invpd takes the inverse of a positive definite matrix, and is more efficient than \n')
fprintf('inv for these types of matrices. \n')
ixx = invpd(x'*x);
covb = sighat2*ixx;
disp(covb) %/* Eq. 5.3.26 */

fprintf('Let x0 represent a matrix of subsequent values of explanatory variables that we \n')
fprintf('would like to use for prediction purposes. It contains 1 observation. \n')
x0 = [1 22];

fprintf('The predicted values for y using those values of x are: \n')
y0 = x0*b;
disp(y0) %/* Eq. 5.3.28 */

fprintf('The estimated covariance matrix for the prediction error is \n')
y0var = sighat2*(x0*ixx*x0' + 1);
disp(y0var) %/* Eq. 5.3.17b */

fprintf('The square roots of the diagonal elements are the standard errors for the prediction \n')
fprintf('errors. \n')
std = sqrt(diag(y0var)); std;

fprintf('The coefficient of determination R2 can be computed using the sum of squared \n')
fprintf('errors (SSE computed above) and the total sum of squares (SST). \n')
ybar = mean(y,1);
sst = y'*y - t*ybar^2;
r2 = 1 - (sse/sst);
disp(r2)

fprintf('The adjusted R2, Bar(R2), is: \n')
rbar2 = 1 - (t-1)*(1-r2)/(t-k);
disp(rbar2)

fprintf('5.4 The General Linear Statistical Model \n')
fprintf('Model 3 \n')
fprintf('In this Section of ITPE2 the notation for the CLRM with K explanatory variables \n')
fprintf('is presented. Carefully analyze all the variations on this basic notation. \n')

fprintf('5.4.1 Point Estimation \n')
fprintf('In this Section we repeat many of the steps taken in Chapter 5.3. The data on \n')
fprintf('a poultry production function is given in Table 5.3 in ITPE2. The dependent \n')
fprintf('variable, y, is the average weight of the chickens at a point in time and the \n')
fprintf('explanatory or independent variables are cumulative food consumption and its \n')
fprintf('square. \n')
fprintf('Create the y vector and X matrix and print the data. \n')
load mDataTable5_3
dat=mDataTable5_3;
y = dat(:,1);
xvec = dat(:,2);
x = [ones(15,1) xvec (xvec.^2)];
disp([y x])

fprintf('Compute the cross-product matrices between x and itself and x and y and print. \n')
fprintf('These matrices appear in Equation (5.5.22b) \n')
xx = x'*x;
xty = x'*y;
disp([xx xty])

fprintf('Compute and print the matrix inverse of x�x. Compare to (5.5.23) \n')
ixx = invpd(x'*x);
display(ixx)

fprintf('Compute the sample estimates using (5.5.24) \n')
b = ixx*xty;
display(b)

fprintf('Note again that computationally it is more efficient to use � / � \n')
b = x\y;
display(b)

fprintf('Now plot the estimated production function for the sample values of X. \n')
yhat = x*b;
% library qgraph;
scatter(xvec,yhat);

fprintf('5.5 Sampling Properties of the Least Squares \n')
fprintf('Rule \n')
fprintf('In this Section the mean and covariance matrix of the least squares estimator \n')
fprintf('are determined. In Section 5.10 a Monte Carlo Experiment is carried out that \n')
fprintf('explores these properties. \n')

fprintf('5.5 Sampling Properties of the Least Squares \n')
fprintf('Rule \n')
fprintf('In this Section the mean and covariance matrix of the least squares estimator \n')
fprintf('are determined. In Section 5.10 a Monte Carlo Experiment is carried out that \n')
fprintf('explores these properties. \n')

fprintf('5.5.1 Sampling Properties�The Gauss-Markov Result \n')
fprintf('In this Section it is proved that the least squares estimator is the Best Linear \n')
fprintf('Unbiased Estimator ( BLUE ) under the assumptions of the CLRM. \n')
fprintf('5.5.2 Estimating the Scale Parameter 2 \n')
fprintf('In order to estimate the error variance 2 calculate the sum of squared least \n')
fprintf('squares residuals. Note that an alternative computational form is given in Equation \n')
fprintf('(5.8.7) \n')
ehat = y - x*b;
sse = ehat'*ehat;
disp(sse)

fprintf('Calculate the degrees of freedom. \n')
t = rows(x);
k = cols(x);
df = t - k;
disp(df)

fprintf('Calculate the parameter estimate using (5.8.7) \n')
sighat2 = sse/df;
disp(sighat2)

fprintf('Calculate the estimate of the covariance matrix of b. \n')
cov = sighat2*ixx;
disp(cov)
fprintf('5.5.3 Prediction and Degree of Explanation \n')
fprintf('Specify the following X0 matrix, as in Section 5.9.2 of ITPE2. \n')
x0= [1 10 100];
t0 = rows(x0);

fprintf('The corresponding predicted value of y is \n')
y0hat = x0*b;
disp(y0hat)

fprintf('The sampling variance of the forecast error for y0hat as an estimator of y0 is \n')
fprintf('given in (5.9.3a) \n')
y0var = sighat2*(x0*ixx*x0' + eye(t0));
disp(y0var)

fprintf('The sampling variance of y0hat as an estimator of E(y0) is given in (5.9.4a) \n')
Ey0var=sighat2*(x0*ixx*x0');
disp(Ey0var)

fprintf('The degree of explanation by the linear model is given by R2 in (5.9.9). The \n')
fprintf('total sum of squares SST is \n')
ybar = mean(y,1);
sst = y'*y - t*(ybar.^2);
sst;
fprintf('The value of R2 is \n')
r2 = 1 - (sse/sst);
r2;
fprintf('and the Adjusted-R2 is \n')
rbar2 = 1 - (t-1)*(1-r2)/(t-k);
rbar2;
fprintf('5.5.4 OLS Proc \n')
fprintf('For future reference, and use, combine all that you have learned into an Ordinary \n')
fprintf('Least Squares (OLS) procedure. Save this procedure in a separate file MYOLS.G \n')
fprintf('in the SRC subdirectory so that you may call it later and it will be LOADed \n')
fprintf('automatically. GAUSS�s PROC OLS can also be used. See your GAUSS \n')
fprintf('manual for details \n')

fprintf('The beauty of this OLS program is that you understand every step of its workings, \n')
fprintf('unlike some �canned� programs you may use. \n')
fprintf('After you have created the file containing the PROC run it using the F2 key \n')
fprintf('which will compile the program and check for errors. Then you may use it as \n')
[b, covb] = fMyOls(x,y);
display(b)
display(covb)

fprintf('5.6 A Monte Carlo Experiment to Demonstrate \n')
fprintf('the Sampling Performance of the Least Squares \n')
fprintf('Estimator \n')
fprintf('To better understand the properties of the estimators, run a series of Monte \n')
fprintf('Carlo experiments. To do this, write a procedure to simulate the data generation \n')
fprintf('process of a linear statistical model. Create many data sets that follow \n')
fprintf('this process, the only difference being the values of the random disturbances. \n')
fprintf('Then estimate the parameters of the model for each data set and observe how \n')
fprintf('the parameter estimates are distributed. They should agree closely with the \n')
fprintf('theoretical properties that have been derived. \n')
fprintf('The sampling experiment will use the parameter values in Equation (5.10.1) \n')
fprintf('and the design matrix X in (5.10.2), which is in the data file JUDGE.X on the \n')
fprintf('data disk. In these simulations, assume that the random errors have a uniform \n')
fprintf('distribution with mean zero and variance 2. While the GAUSS random number \n')
fprintf('generators could be used to create the values of the random disturbances, \n')
fprintf('use instead the �official� uniform random numbers contained in the data file \n')
fprintf('URANDOM.DAT. This data set is a GAUSS data file and may be read using \n')
fprintf('the READR command. It contains 10,000 uniform random numbers falling in \n')
fprintf('the (0,1) interval. Since these random numbers have mean 1/2 and variance \n')
fprintf('1/12 we must transform them to mean 0 and variance 2 by subtracting 1/2 and \n')
fprintf('multiplying by sqrt(24). \n')
fprintf('Start �small� and create NSAM = 10 samples of size T = 20 and obtain the least \n')
fprintf('squares estimates of beta and sigma^2. First create a (T x NSAM) matrix E containing \n')
fprintf('the random errors. \n')
t = 20; %/* sample size */
k = 3; %/* number of regressors */
nsam = 10; %/* number of samples */
nr = t*nsam; %/* number obs. to read */
% open f1 = urandom.dat; /* open data set */
f1 = rand(10000,1);
e = f1(1:nr); %/* read nr obs. */
% f1 = close(f1); /* close file */

fprintf('The uniform random disturbances are now in a (NR x 1) vector. To create \n')
fprintf('the desired (T x NSAM) matrix E use the RESHAPE function. RESHAPE \n')
fprintf('stores the data in �row major� form so form an (NSAM x T) matrix and then \n')
fprintf('transpose it. \n')
fprintf('In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape \n')
fprintf('reshape(Data,N,T))Transpose in GAUSS is equivalent to reshape(Data,T,N) in MATLAB \n')
e = (reshape(e,t,nsam));

fprintf('Now correct the mean and variance. \n')
e = sqrt(24)*(e - 0.5);

fprintf('Now LOAD x and define beta. \n')
load mDataJudge
x=mDataJudge;
beta = [10.0 0.4 0.6]';
fprintf('The matrix of error terms created, e, has T rows � the size of each separate \n')
fprintf('sample, and NSAM columns � the number of samples. Because of the special \n')
fprintf('features of matrix addition in GAUSS, when this matrix is added to the vector \n')
fprintf('x*beta, a matrix of y�s is created. The first column is equal to x*beta plus the \n')
fprintf('first column of e, the second column is equal to x*beta plus the second column \n')
fprintf('of e, etc. \n')
fprintf('The same formula for computing the estimated coefficients, y/x can still be used. \n')
fprintf('The first column will contain the estimated coefficients for the first sample, \n')
fprintf('the second column the second sample, etc. The sighat2 is a column vector \n')
fprintf('containing the estimated variances for each sample. Since we will use it several \n')
fprintf('times, create PROC MC to carry out the calculations. The arguments are x, \n')
fprintf('beta and a (T x NSAM) matrix of random disturbances e. \n')

fprintf('The arguments of PROC MC are the design matrix x, the beta vector, and the \n')
fprintf('matrix of random disturbances e. The procedure will return the (K x NSAM) \n')
fprintf('matrix of estimated coefficients and (NSAM x 1) vector of estimated variances. \n')
fprintf('Run the procedure to compile it and then use it to carry out the Monte Carlo \n')
fprintf('exercise. \n')

[b, sighat2] = fMc(x,beta,e);
disp([b' sighat2])

fprintf('Compare the values of the estimated parameters to those in Table 5.4. They \n')
fprintf('should be identical. Note that the parameter estimates vary from sample to \n')
fprintf('sample. \n')
fprintf('Now carry out the Monte Carlo experiment on a grander scale. Use NSAM \n')
fprintf('= 500 samples of size T = 20. Unfortunately, due to limits on the abilities of \n')
fprintf('personal computers, a matrix in GAUSS can only hold 8190 elements. Thus \n')
fprintf('the 10,000 random numbers cannot all be read into a single matrix. Thus we will \n')
fprintf('divide the computations into two steps, using NSAM = 250 each time. First, \n')
fprintf('construct the matrices of uniform random errors with zero mean and variance \n')
fprintf('one. SAVE them for future use. They will be given the extension .FMT and \n')
fprintf('can be LOADed when needed. \n')

t = 20;
k = 3;
nsam = 250;
nr = t*nsam;
%open f1 = urandom.dat;
e1 = f1(1:nr); %/* read 1st 5000 obs. */
e2 = f1(nr+1:nr+nr); %/* read 2nd 5000 obs. */
% f1 = close(f1);
fprintf('In MATLAB the RESHAPE stores the data in �column major� form. Hence, reshape \n')
fprintf('reshape(Data,N,T))Transpose in GAUSS is equivalent to reshape(Data,T,N) in MATLAB \n')
e1 = (reshape(e1,t,nsam)); %/* 250 random vectors */
e2 = (reshape(e2,t,nsam)); %/* 250 random vectors */
e1 = sqrt(12)*(e1-0.5); %/* adjust to U(0,1) */
e2 = sqrt(12)*(e2-0.5);
% save e1uni = e1; /* SAVE to E1.FMT */
% save e2uni = e2; /* SAVE to E2.FMT */

fprintf('Now, assuming x, beta, and PROC MC are still in memory, transform the errors \n')
fprintf('to have variance 2 and execute the Monte Carlo. \n')
e1 = sqrt(2)*e1;
e2 = sqrt(2)*e2;
[b1, s1] = fMc(x,beta,e1);
[b2, s2] = fMc(x,beta,e2);
%Stack all the parameter estimates into a matrix and clear unneeded matrices.
est=[[b1; s1'] [b2; s2']];
e1=0; e2=0; b1=0; b2=0; s1=0; s2=0;
fMcSum(est,x,beta,2);

fig=figure(1);
set(fig, 'Color', 'white')
title('Histogram of the parameters')
subplot(2,2,1);
hist(est(1,:),30);
legend('\beta_1');
subplot(2,2,2);
hist(est(2,:),30)
legend('\beta_2');
subplot(2,2,3);
hist(est(3,:),30)
legend('\beta_3');
subplot(2,2,4);
hist(est(4,:),30)
%see http://www.mathworks.com/matlabcentral/answers/103035-how-do-i-add-a-hat-on-a-character-which-is-displayed-in-the-legend-of-a-figure-in-matlab-7-0-r14
% Create a blank legend
h = legend('');
% hchild is the handle to the children of the axes object.
% In this case it is a 3 by 1 vector and hchild(3) is the
% handle to the string in the legend
hchild = get(h,'children');
% Set LaTeX as the interpreter
set(hchild(2),'Interpreter','LaTeX');
% Add x with a hat to the legend in the current figure
set(hchild(2),'String','$$\hat{\sigma^{2}}$$');


