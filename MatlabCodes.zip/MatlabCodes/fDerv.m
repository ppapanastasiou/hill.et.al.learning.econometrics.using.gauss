function out = fDerv(beta)

global x

out = ( x(:,1) + 2*beta*x(:,2) );
return