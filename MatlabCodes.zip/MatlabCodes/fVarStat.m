function results=fVarStat(y,x)

m = cols(y);
t = rows(y);
n = (cols(x) - 1)/2;
b=x\y; %/* Estimate parms */
e = y - x*b; %/* residuals */
sig = e'*e/t; %/* Eq. 18.3.17 */
aic = log(det(sig)) + 2*(m^2)*n/t; %/* Eq. 18.3.15 */
sc = log(det(sig)) + (m^2)*n*log(t)/t; %/* Eq. 18.3.16 */
results.n=n;
results.det=det(sig);
results.aic=aic;
results.sc=sc;
results.sig=sig;


% print out results
fid=1;
fprintf(fid,'\n ***** Var stat results ***** \n');

nstring = 'n';
detstring = 'det';
aicstring = 'aic';
scstring = 'sc';

tmp = [n det(sig) aic sc];

in.cnames = strvcat(nstring,detstring,aicstring,scstring);
% rnames = vstring;
% for i=1:k
%     tmpn{i} = [Vname{i} lnames{i}];
% rnames = strvcat(rnames,tmpn{i});
% end;
% in.rnames = rnames;
in.fmt = '%16.6f';
in.fid = fid;
mprint(tmp,in); 

sig

% format 8,4;
% "----n-------det--------aic--------sc";?;
% n~det(sig)~aic~sc;
% ?;
% " sighat ";
% sig;
% retp("");
% endp;


return