
% /*	DW() Procedure (first used in Example 19.4.3)
% **
% **	A GAUSS procedure designed to compute the Durbin-Watson
% **	statistic and Prob[ dw < d ] under the null assumptions
% **	of a normally distributed and uncorrelated noise process.  The
% **	The exact distribution also depends on the explanatory variables 
% **	for the model, and the regressors are assumed to be fixed in 
% **	repeated samples.  The algorithm outlined in the text is based 
% **	on the application of Imhof (1961) presented in the book by 
% **	Koerts and Abrahamse (1969).
% **
% **	The required inputs are:
% **
% **		ehat		(n x 1) vector of residuals
% **		x		(n x k) matrix of explanatory variables
% **		tol		tolerance between the reported tail probability
% **					and the actual tail probability
% **
% **	The information returned by the procedure is:
% **
% **		d		Durbin-Watson test statistic
% **		p		Prob[ dw < d ]
% */


% Reference: please refer to pages 548 and 549 of Mittelhammer et al
% Econometric foundations

function [d, p, d1, d2]= fDW(ehat, x, tol)

global lambda n

if nargin < 3 || isempty(tol)
    tol = 0.00001;
end
% 	local p, num, denom, sum, lims, a, h, m, nr, temp;
% 	declare d, lambda, n;
intord=40;

n = rows(x);
num = 0;
denom = ehat(1,1)^2;
for i=2:n
    num = num + ehat(i,1)^2 + ehat(i-1,1)^2 -2*ehat(i,1)*ehat(i-1,1);
    denom = denom + ehat(i,1)^2;
end
d = num/denom;

m = eye(n) - x*pinv(x'*x)*x';
h = zeros(n,1);
h(1,1) = 2;
h(2,1) = -1;
a = toeplitz(h);
a(1,1) = 1;
a(n,n) = 1;

% alternative ways to calculate the DW statistic d1 and d2 should be equal
% to d
edif = ehat(2:end,1) - ehat(1:end-1,1);
d1 = (edif'*edif)/(ehat'*ehat);
d2 = ehat'*a*ehat/(ehat'*ehat);

h = m*a*m - d*m;
nr = n - cols(x);
lambda = eig(h);
temp = zeros(n,1);
for i=1:n
    if abs(lambda(i,1)) < 1e-8;
        temp(i,1) = 0;
    else
        temp(i,1) = lambda(i,1);
    end;
end
lims = zeros(2,1);
lims(1,1) = (tol*pi*nr*sumc(sqrt(abs(temp)))/2)^(-2/nr);
% sum = quadgk(@integrand, lims(2), lims(1));
sum = integral(@integrand, lims(2), lims(1));

p = 0.5 - sum/pi;

% retp(d, p);
return

function out = integrand(w)
global lambda n

% local e, g;
mW = repmat(w, rows(lambda),1); 
mLambda = repmat(lambda, 1, cols(w));
e = 0.5*sumc(atan(mW.*mLambda));
% g = (prodc(ones(n,1) + w.*w.*lambda.*lambda))^0.25;
g = (prodc(ones(n,cols(mW)) + mW.*mW.*mLambda.*mLambda)).^0.25;
out = (((sin(e)./g)')./w);
return

