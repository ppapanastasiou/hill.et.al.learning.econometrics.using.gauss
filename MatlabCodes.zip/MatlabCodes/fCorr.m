function out=fCorr(i,j,shat)

out= shat(i,j)^2/(shat(i,i)*shat(j,j));

return