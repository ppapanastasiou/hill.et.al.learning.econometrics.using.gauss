% /**************************************************************/
% /* PROC MAXL -- Maximum likelihood estimation (BHHH) */
% /**************************************************************/
function  b0 = fMaxl(b0,LI,x,y)
% local LI:proc;
% local *;

db = 1; % /* Initialize values */
iter = 1;
s = 0;
while db >= 1e-5; % /* Begin do loop */
    % z = gradp(LI,b0); % /* Compute gradients (T x K) */
    % Win codes http://www.aae.wisc.edu/aae637/main.asp
    % numobs = rows(y);
    % z = Grad(b0,FI,numobs);
    % Poddig codes  
    z = fGradApprox(LI,b0); % /* Compute gradients (T x K) */
    H = z'*z; % /* Compute approx. to Hessian */
    g = -sumc(z); % /* Gradient vector (K x 1) */
    db = -inv(H)*g; % /* Compute full step adjustment */

    % gosub step; /* Compute step length */
    % step: /* Subroutine for step length */
    s = 2;
    li1 = 0; li2 = 1;
    while li1 < li2;
        s = s/2;
        li1 = sumc(LI(b0 + s*db));
        li2 = sumc(LI(b0 + s*db/2));
    end
    % return;
    b = b0 + s*db; % /* Update parameters */

    % gosub prnt; /* Print results for iteration */
    % prnt: /* Subroutine for printing */
    % format 4,2; "i = " iter;;
    % format 4,2; " Steplength = " s;;
    % format 10,6; " Ln Likelihood = " sumc(LI(b0));
    % format 10,6; " Parameters: " b0�;
    % return;



    iter = iter + 1; % /* Update for next iteration */
    db = abs(b-b0); % /* Convergence criteria */
    b0 = b; % /* Replace old estimate */
end
std = sqrt(diag(invpd(H))); % /* Compute estimated std. errors*/

% ?; /* Print out final results */
% "Final Results: ";
% " Parameters: " b0�;
% " Std. Errors: " std�;

fprintf('Final Results \n');
fprintf('Parameters \n')
disp(b0);
fprintf('Standard errors \n')
disp(std);

% retp(b0); /* Return parameters to memory */

return
