function [covb, covalpha] = fHetercov(param0)

global x z 

% local k,b,alpha,xstar,za,covb,covalpha;
k = cols(x);
b = param0(1:k,:);
alpha = param0(k+1:rows(param0),:);
za = z*alpha;
xstar = x .* kron(ones(1,k), sqrt(exp(-za)));
covb = invpd(xstar'*xstar);
covalpha = 2*invpd(z'*z);
fprintf('Final Results \n');
fprintf('Est. \n');
disp(param0)
fprintf('Std. Errs. \n');
disp(sqrt(diag(covb)))
sqrt(diag(covalpha));
% retp(covb,covalpha);
% endp;

return