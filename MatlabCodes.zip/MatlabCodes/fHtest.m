function [dAccept, dReject] = fHtest(beta)

sigma = sqrt(10);                    % true std deviation
t =10;                               % sample size
h0= 1;                              % Hypothesized mean

y = beta + sigma*randn(t, 400);      % Create data
b = sum(y)/t;                        % Compute means
z = (b - h0)/(sigma/sqrt(t));         % Standardize
reject = mean(abs(z) >= 1.96);       % Compute fraction 

dAccept = 1 - reject;
dReject = reject;

fprintf('Accept: %5.2f \n', dAccept) % print results
fprintf('Reject: %5.2f \n', dReject) % print results

return