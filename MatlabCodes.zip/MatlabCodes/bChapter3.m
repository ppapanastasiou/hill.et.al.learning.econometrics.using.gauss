clear;close all;clc
format bank; % two decimal points
% format compact; 

fprintf('Chapter 3 \n')
fprintf('3.2 Methods for finding point estimators \n')

theta =  13000;
sigma = 5000;
t = 20;
e = sigma*randn(t,1);
y =theta + e;

display(y)

fprintf('The estimated mean of y is %5.2f \n', mean(y))

fprintf('the method of moments \n')
fprintf('The method of moments equates true moments to sample moments and the \n')
fprintf('resulting equations solved. First compute the first and second sample \n')
fprintf('moments \n')
T = rows(y);
mu1 = sum(y)/T;
mu2 = sum(y.^2)/T;

fprintf('or alternatively \n')
mu1_1 = mean(y);
mu2_1 =(y'*y)/T;


fprintf('Compute the point estimates for the (typically) unknown parameters: the \n')
fprintf('mean and standard deviation (std): \n')

dMean = mu1;
dVar = mu2 - dMean^(2);
dStd =sqrt(dVar);

fprintf('The estimated mean is %5.2f and the estimated standard deviation is %5.2f \n', dMean, dStd)

fprintf('The method of maximum likelihood \n')
fprintf('The method of maximum likelihood requires maximizing the joing p.d.f. of the \n')
fprintf('observable (T x 1) vector random variable, y, with respect to the unknown \n')
fprintf('parameters, given the sample values of y. The joint p.d.f. interpreted as \n')
fprintf('a function of the parameters, given the data, is the likelihood function. \n')

fprintf('As an example the method of maximum likelihood is used to estimate the \n')
fprintf('parameter p pf a Bernoulli random variable. While all the work for tis \n')
fprintf('problem can be done analytically ( see Example 3.3 in ITPE2) we will \n')
fprintf('treat the problem as a numerical one. This will not only emphasize the \n')
fprintf('principle but prepare you for the many problems in which there is no \n')
fprintf('analytic solution. \n')

fprintf('Begin by creating the vector of observed Bernoulli outcomes, 1, 1 and 0 \n')
fprintf('as in the text \n')

y = [1 1 0]';

fprintf('In Equations (3.2.5) in ITPE2 the likelihood function/joint p.d.f. for \n')
fprintf('this vector of y values is given. We will write the likelihood function \n')
fprintf('in a more general form that for any (T x 1) vector of Bernoulli values. \n')

dLik1 = fLik(y, 0.25);
dLik2 = fLik(y, 0.75);

fprintf('The likelihood for p = 1/4 is %5.2f and for p = 3/4 %5.2f \n', dLik1, dLik2)

fprintf('In order to obtain the maximum likelihood estimate of the parameter p for \n')
fprintf('the sample y we will use the brute forece technique of simply trying a \n')
fprintf('large number of p values in the interval [0,1] and picking the value that \n')
fprintf('gives us the largest value of the likelihood function. We will compute \n')
fprintf('the likelihood function for 101 values of p, beginnings with zero and \n')
fprintf('incrementing by units of 0.01. Store the values of the likelihood \n')
fprintf('function in a vector, liex, and pick the laregest value.... \n')

liex = zeros(101,1); % storage vector
p =seqa(0, 0.01, 101); % p-values
iter =1;

while iter <= 101 % begin do-loop
    liex(iter, 1) =fLik(y, p(iter, :)); %calculate fLik(y, p)
    iter = iter +1;
end
maxiter = fMaxindxc(liex); % locate max

fprintf('ptilde is %5.2f and maxli %5.2f \n', p(maxiter), liex(maxiter)) % print results

fprintf('This method illustratesthe use of DO loops to repeatedly calculate the \n')
fprintf('likelihood function. The function fMaxindc gives the row index of the  \n')
fprintf('maximum element in a column. The use of a DO loop shows the nature of the \n')
fprintf('"search" processs for the maximum likelihood estimate. It is not \n')
fprintf('necessarily the most efficient computational procedure. Note that the \n')
fprintf('following 2 statements achieve the same goal \n')

liex1 =fLik(y, p');
fprintf('ptilde is %5.2f and maxli %5.2f \n', p(fMaxindxc(liex1)), liex1(fMaxindxc(liex1))) % print results

fprintf('This works because the argument passed to the function fLik is a row \n')
fprintf('vector. Then element-wise exponetiation and multiplication are carried \n')
fprintf('out making the argument of PROD a (t x 101) matrix whose column products \n')
fprintf('are the values of the likelihood function. We will generally opt for the \n')
fprintf('former, less efficient approach as it is more apparant what is going on. \n')

fprintf('How does your "numericall generated" estimate compare to the value given \n')
fprintf('by the ML estimator (Ex. 3.3) \n')

disp(sum(y)/rows(y))

fprintf('Now graph the likelihood function \n')

fig1=figure(1);
set(fig1, 'Color', 'white')
p1 = plot(liex1);
titel='Graph of the likelihood function';
title(titel,'FontSize',10);
set(p1, 'LineStyle', '-', 'LineWidth' , 2)
legend({'$\hat{lik}$'},'Interpreter','latex')
ylabel( 'l(p|y)', 'FontSize', 10 );
xlabel( 'p', 'FontSize', 10 );
% axis tight

fprintf('Examining the graph makes it clear that our estimate corresponds to the \n')
fprintf('global maximum of the likelihood function. Verify the first and second \n')
fprintf('order conditions for a local maximu by graphing the first and second \n')
fprintf('derivatives against the values of p. \n')

fig2=figure(2);
set(fig2, 'Color', 'white')
p2 = plot(p, fDerv1(p), p, fDerv2(p));
set(p2, 'LineStyle', '-', 'LineWidth' , 2)
titel='Graph of the first and second derivative against the values of p';
legend('first derivative','second derivative')
title(titel,'FontSize',10);
ylabel( 'derivative', 'FontSize', 10 );
xlabel( 'p', 'FontSize', 10 );

fprintf('Now use the method of maximum likelihood to estimate the two parameters, \n')
fprintf('beta and sigma squared, of a normal population (See example 3.4 in the \n')
fprintf('text). Begin by writing a function to compute the log-likelihood function \n')
fprintf('(See Equation 3.2.6) give a sample y of size T. \n')

fprintf('(Note that the standard normal p.d.f could be used to write this \n')
fprintf('function as: ln(pdfn((y-b)/sigma)sigma) where sigma = sqrt(sigma2).) \n')

fprintf('Create the vector y with a mean of 10, standard deviation of 5, and \n')
fprintf('sample size of T =  20; \n')
rng('default');
rng(1);
t = 20;
y = 10 + 5*randn(t,1);

fprintf('Compute the value of the likelihood function for cobinations of b and \n')
fprintf('sigma2. A vector of 41 values of b (bvec) is created, beginning with 5 \n')
fprintf('and with increments of 0.25. Similarly a vector of 41 values of sigma2 \n')
fprintf('(sig2vec) is created, beginning with 20. These are used as arguments into \n')
fprintf('the log-likelihood functon fLli above. What is returned is a matrix of \n')
fprintf('values, the rows correspond to changing values of b and the columns \n')
fprintf('correspond to changing values of sigma2. \n')

bvec = seqa(5, 0.25, 41); % param. values
sig2vec = seqa(20, 0.25, 41);
liex = zeros(41, 41);

iAlternative = 0;
if iAlternative==0
    fprintf('Use normal method to compute the likelihood \n')
else
    fprintf('Use alternative method to compute the likelihood \n')
end

iterb =1; % begin b do-loop
while iterb <= 41
    itersig2 = 1; % begin sig2 do-loop
    while itersig2 <= 41
        liex(iterb, itersig2) = fLli(y, bvec(iterb,1), sig2vec(itersig2, 1), iAlternative); % calculate fLli(y, b, sig2)
        itersig2 = itersig2 +1;
    end
    iterb = iterb +1;
end

fprintf('Find the positions of the values of b in bvec which maximize the \n')
fprintf('likelihood function for each values of sigma by using the fMaxindc \n')
fprintf('fucntion. Put the positions of the values of b in the vector maxpos and \n')
fprintf('pring out the values. \n')

maxpos = fMaxindxc(liex);

fprintf('the maxpos is %5.2f \n', maxpos)

fprintf('Notice that the same position (i.e. value) of b maximizes the likelihood \n')
fprintf('function for all values of sigma2. Examination of the first order \n')
fprintf('conditions in Equation (3.2.7) in the text shows that the value of b is \n')
fprintf('in fact independent of sigma2. \n')

fprintf('Find the actual estimated vlue of b (bhat) by taking that element from the \n')
fprintf('bvec vector. \n')

bhat = bvec(maxpos(1,1),1);

fprintf('bhat is %5.2f \n', bhat)

fprintf('Take the row of the matrix of values of the likelihood function which \n')
fprintf('corresponds to the optimal value of bhat. Call the vector maxbs. \n')

maxbs = liex(maxpos(1,1),:);

fprintf('Now find hte position of sigma2 which maximizes the values of the \n')
fprintf('likelihood function in maxbs. \n')

sig2pos = fMaxindxc(maxbs');
sig2hat = sig2vec(sig2pos, 1);
fprintf('sig2hat is %5.2f \n', sig2hat)

fprintf('Graph a two dimensional view of the likelihood function --- first where \n')
fprintf('the value of sigma2 is held fixed and b varies \n')

fig3=figure(3);
set(fig3, 'Color', 'white')
subplot(2,1,1)
scatter(bvec, liex(:, sig2pos));
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='likelihood function where the value of sigma2 is held fixed and b varies';
legend('likelihood')
title(titel,'FontSize',10);
ylabel( 'likelihood', 'FontSize', 10 );
xlabel( 'bvec', 'FontSize', 10 );
subplot(2,1,2)
scatter(sig2vec, maxbs');
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='likelihood function holding b equal to bhat and allowing sigma2 to vary along the x-axis';
legend('likelihood')
title(titel,'FontSize',10);
ylabel( 'likelihood', 'FontSize', 10 );
xlabel( 'sig2vec', 'FontSize', 10 );

fprintf('You should have just learned a very important lesson. It is clear from \n')
fprintf('the previous graph that sig2hat is not the ML estimate. Searching over a \n')
fprintf('reasonable range of values is not enough. Once some values are found it \n')
fprintf('must be confirmed that they do indeed maximize the likelihood function. \n')

fprintf('Let us search over additional values of sigma2. Furthermore, it is \n')
fprintf('possible to avoid time consuming do-loops here by using the convenience \n')
fprintf('of elementwise operators. You should try to rationalize why the single \n')
fprintf('call to LLI works (not sure how to do this in matlab that is why I will \n')
fprintf('use a wrapper function with the loop built in. \n')

sig2vec = seqa(40, 0.25, 41); % new sig2 values

liex = fLliWrapper(y, bvec, sig2vec); % calc fLLi(y, b, sig2)
maxpos = fMaxindxc(liex);
bhat = bvec(maxpos(1,1), 1);
maxbs = liex(maxpos(1,1),:);
sig2pos = fMaxindxc(maxbs');
sig2hat = sig2vec(sig2pos, 1);

% print results
fprintf('bhat is %5.2f \n', bhat)
fprintf('sig2hat is %5.2f \n', sig2hat)

fig4=figure(4);
set(fig4, 'Color', 'white')
subplot(2,1,1)
scatter(bvec, liex(:, sig2pos));
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='likelihood function where the value of sigma2 is held fixed and b varies';
legend('likelihood')
title(titel,'FontSize',10);
ylabel( 'likelihood', 'FontSize', 10 );
xlabel( 'bvec', 'FontSize', 10 );
subplot(2,1,2)
scatter(sig2vec, maxbs');
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='likelihood function holding b equal to bhat and allowing sigma2 to vary along the x-axis';
legend('likelihood')
title(titel,'FontSize',10);
ylabel( 'likelihood', 'FontSize', 10 );
xlabel( 'sig2vec', 'FontSize', 10 );

fprintf('Finally, in a "real" problem the search process would be taken over a \n')
fprintf('finer grid of parameter values once the neighborhood of the maximum is \n')
fprintf('found. You may try that if you like. \n')

fprintf('Least square estimation \n')

fprintf('Least square estimation of the rth central moment of a random variable \n')
fprintf('requires minimizing the "distance" between the sample values of y^{r} and \n')
fprintf('the unknown parameters. One way to do that is by minimizing the sum of \n')
fprintf('squared differences given in Equation 3.2.8 in ITPE2. In some problems \n')
fprintf('this can be done analytically and in some it can not. We illustrate using \n')
fprintf('an example where an analytic solution is possiblebut where we find the LS \n')
fprintf('estimate numerically. \n')

fprintf('Use least squares to estimate the mean of a population given a random \n')
fprintf('sample of observations from that population. (See example 3.5 in the \n')
fprintf('text). We will use the data created for the Maximum Likelihood example \n')
fprintf('above. \n')

fprintf('Write a function to compute the sum of squared differences. (See Equaton 3.2.8 in the text) \n')

fprintf('Compute the sum of squared differences for 75 values of b, beginning with \n')
fprintf('8and with increments of 0.05. \n')

b =  seqa(8, 0.05, 75)';
ss = fSSdif(y, b);

fprintf('Compute the value of b which minimizes the sum of squared differences by \n')
fprintf('using the fMinindc operator \n')

fprintf('value of b which minimizes the sum of squared differences is %5.2f \n', b(fMinindc(ss)))

fprintf('Graph the sum of squares parabola for this data set. \n')

fig5=figure(5);
set(fig5, 'Color', 'white')
scatter(b', ss)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='The sum of squares parabola';
legend({'$\hat{\beta}$'},'Interpreter','latex')
title(titel,'FontSize',10);
ylabel( 'S', 'FontSize', 10 );
xlabel( {'$\hat{\beta}$'}, 'Interpreter', 'latex', 'FontSize', 10 );

fprintf('from example 3.4 and 3.5 in ITPE2 we know that the ML and LS estimators \n')
fprintf('of a population mean are identical and equal to the sample mean. Compare \n')
fprintf('the analytical estimate to the the "numerically" obtained estimates. \n')

fprintf('Sample mean is %5.2f \n', mean(y))

fprintf('The numerical difference between the ML and LS estimates are due to the \n')
fprintf('differences in the fineness of the grid searches. Further numerical work \n')
fprintf('would produce values identical to the sample mean. \n')

fprintf('3.3. Properties of point estimators \n')

fprintf('In this section the properties of point estimators will be illustrated by \n')
fprintf('carrying out a Monte Carlo experiment. Many artificial samples from a \n')
fprintf('known statistical model will be created and an estimator usd to estimate \n')
fprintf('the population parameter(s) in each sample. The values of the estimaters \n')
fprintf('from all the samples will then be examined and their actual distribution \n')
fprintf('compared to the true parameter values(s). \n')

fprintf('The experiment will involve estimation of the mean of a population which \n')
fprintf('has a uniform distribution. Construct n = 200 samples of size T = 10 from \n')
fprintf('a uniform distribution with mean 10 and variance 9. To do this we will \n')
fprintf('first construct a (T x n) matrix of uniformly distributed random numbers \n')
fprintf('with mean 0 and variance 1. \n')

n = 200;
t = 10;
e = sqrt(12)*(rand(t, n) - 0.5);

fprintf('Then construct the sample values using the linear model for the mean, \n')
fprintf('Equation 3.2.2a \n')

dMean =10;
dStd =3;
y = dMean + dStd*e;

fprintf('The matrix y represents 200 samples of size T =10 from the desired \n')
fprintf('population. Compute the means of each column and put them in the column \n')
fprintf('vector thetahat. \n')

thetahat = mean(y);

fprintf('The sample mean of thetaha corresponds to the mathematical expectation of \n')
fprintf('thetahat as it is the average value in a large number oftrials. Similarly \n')
fprintf('the sample variance of thetahat measures the variability of the \n')
fprintf('estimator. Compares the sample mean and variance of thetahat to its true \n')
fprintf('mean and variance as given in Example 3.6 in ITPE2. \n')

fprintf('mean is %5.2f and std is %5.2f \n', mean(thetahat), (std(thetahat))^2) % print results

fprintf('Now compute the percentage of the computed means that are between +1 and \n')
fprintf('-1 of the true expected value of 10. \n')


fprintf('The percentage of the computed means that are between +1 and -1 of the true expected value of 10 is %5.2f \n', 100*mean( abs(thetahat - dMean) <1) ) % print results

fprintf('The actual probability distribution of thetahat is not known in this \n')
fprintf('case, but the "empirical" distribution can be considered as follows. To \n')
fprintf('facilitate comparison to cases where the sample size T is larger consider \n')
fprintf('the random variable \n')

z = sqrt(t)*(thetahat - dMean);

fprintf('The empirical distribution can be obtained by using the function hist \n')

fig6=figure(6);
set(fig6, 'Color', 'white')
hist(z, 11)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Empirical distribution of z';
title(titel,'FontSize',10);

fprintf('Repeat this exericse for sample sizes of 20 and 40 to see how the \n')
fprintf('accuracy of your estimates improve as sample size increases. Also observe \n')
fprintf('how, as the sample size increases, the plots of the empirical \n')
fprintf('distribution appear more bell shaped and symmetric. BY the central limit \n')
fprintf('theorem in Chapter 3.3.3b the quantity we have graphed converges in \n')
fprintf('distribution to the normal distribution N(0, 9) as T grows to infinity. \n')
fprintf('As you can see, for this problem a smaple size of T = 40 is "large" in \n')
fprintf('the sense that this asymptoric distribution holds. \n')

fprintf('3.4 Interval estimation \n')

fprintf('Interval estimation conveys information contained in data about the mean \n')
fprintf('and standard deviation of a population. For example, it is clear that if \n')
fprintf('a population has an estimated mean of 12000 our uncertainty about what \n')
fprintf('the true value might be is inversely proportional to the estimated \n')
fprintf('standard deviation or variance. To illustrate interval estimators for the \n')
fprintf('mean and variance of a normal population (Example 3.12-3.14 in ITPE2) \n')
fprintf('will be constructed. \n')

fprintf('Create a random sample of values from a nornal population with a \n')
fprintf('mean(beta) of 13000 a standard deviation (sigma) of 50, and a sample size \n')
fprintf('(T) of 20. Then the estimated mean, b. \n')

beta =13000;
sigma = 50;
t =20;
y = beta + sigma*randn(t,1);
b = mean(y);
fprintf('Estimated mean(b) is %5.2f \n', b) % print results

fprintf('Assuming that the variance is know, compute the interval which contains \n')
fprintf('the mean with a 95 percentage probability. The standard normal value which contains \n')
fprintf('0.025 in the upper tail is 1.96. Verify this using normcdf(__,upper) which \n')
fprintf('returns the complement of the normal cdf at each value in x. \n')

z = 1.96;
fprintf('complement of the normal cdf is %5.3f \n', normcdf(z, 'upper')) % print results
lb = b - z*sigma/sqrt(t);
ub = b + z*sigma/sqrt(t);
fprintf('confidence interval for beta -- sigma know is %5.2f lower bound: %5.2f upper bound: %5.2f \n', b, lb, ub) % print results

fprintf('Now assme that the standard deviation of the distribution is unknown, as \n')
fprintf('in Example 3.13 in the text. Compute the estimate sigmahat, and again \n')
fprintf('compute the 95 percentage interval, this time using Students t-distribution. The t \n')
fprintf('value with 0.025 in the upper tails and 19 degrees of freedom is 2.093 \n')
fprintf('from Table 2 at the end of ITPE2. Verify this with the function tcdf \n')

sighat2 = sum((y - b).^2)/(t-1);
sighat = sqrt(sighat2);
tstat = 2.093;
fprintf('The t value of the t-stat 2.093 and 19 degrees of freedom is %5.3f \n', tcdf(tstat, t-1, 'upper')) % print results
lb = b - tstat*sighat/sqrt(t);
ub = b + tstat*sighat/sqrt(t);
fprintf('confidence interval for beta -- sigma unknown is %5.2f lower bound: %5.2f upper bound: %5.2f \n', b, lb, ub) % print results

fprintf('Note that the centers of the two confidence intervals for beta are the \n')
fprintf('same. The widths differ because of the larger percentile values for the \n')
fprintf('t-distribution and the difference between the true and estimated standard \n')
fprintf('deviations. \n')

fprintf('Now compute the 95 percentage internval for the population variance. The relevant \n')
fprintf('Chi-squared percentile values (19 d.f.) are 8.90652 and 32.8523, from \n')
fprintf('Table 3 at then end of ITPE2. \n')

chi1 = 8.90652;
chi2 = 32.8523;
fprintf('chi value of chi2 8.90652 is %5.3f \n', chi2cdf(chi1, t-1, 'upper')) % print results
fprintf('chi value of chi2 32.8523 is %5.3f \n', chi2cdf(chi2, t-1, 'upper')) % print results

lb = (t-1)*sighat2/chi2;
ub = (t-1)*sighat2/chi1;
fprintf('sighat2 is %5.2f lower bound (chi2squared): %5.2f upper bound (chi2squared): %5.2f \n', sighat2, lb, ub) % print results

fprintf('The classical or repeated sampling interpretation of confidence interval \n')
fprintf('estimates will be illustrated now. You will contrast this to the Bayesian \n')
fprintf('interpretation later. Return to the situation in which the populations \n')
fprintf('standard deviation is known, compute interval estimates based on 400 \n')
fprintf('artificial samples and determine the percent of intervals that contain \n')
fprintf('the true parameter value. \n')

nsam = 400;
beta = 13000;
sigma = 50;
t = 20;
y = beta +sigma*randn(t,nsam);
b = mean(y);
z = 1.96;
lb = b - z*sigma/sqrt(t);
ub = b + z*sigma/sqrt(t);
percent = sum((beta <= ub) & (beta >= lb))/nsam;

fprintf('Percent of the intervals that contain the true parameter value %5.2f \n', percent) % print results

fprintf('The empirical percent you have discovered should be close to the true  \n')
fprintf('probability that the interval estimator contains the ture parameter, 0.95. \n')

fprintf('3.5 Hypothesis Testing \n')

fprintf('In this section we illustrate the properties of a statistical test using \n')
fprintf('Example 3.15 in ITPE2 as a basis. In that example the hypothesis tested \n')
fprintf('is that the mean of a normal population is one, and it is assumed that \n')
fprintf('the population variance is known to be 10. In order to carry out a series \n')
fprintf('of Monte Carlo experiments write a PROC that will do the work. \n')

fprintf('PROC fHtest will create 400 samples (columns) of data each with a sample \n')
fprintf('size of 10. The true mean, beta , of the normal distribution is an \n')
fprintf('argument of the procedure. \n')

fprintf('Within the procedure, compute the mean of each sample (column) and test  \n')
fprintf('the hypotheis that the mean is equal to one at a 5 percentage confidence level.  \n')
fprintf('Print out the fraction of times the hypothesis is accepted and the \n')
fprintf('freaction of times it is rejected. \n')

fprintf('Now use the procedure to test the hypotheis that the mean if equal to one \n')
fprintf('when the true mean (beta) is in fact one. The probability of rejecting \n')
fprintf('the hypothesis given that it is in fact true is the Type I error. The \n')
fprintf('ture probability of a Type I error is leass than or equal to 5 percentage in this \n')
fprintf('example. \n')

beta =1;
fHtest(beta);

fprintf('Next test the hypoteis that the mean is equal to one when the true mean \n')
fprintf('is equal to 2, 3, 4. The further the true mean is from the hypothesized \n')
fprintf('mean, h0 =1, the greater the percent of rejections and the smaller the \n')
fprintf('percent of nonrejections, or acceptances. \n')

beta =2;
fHtest(beta);

beta =3;
fHtest(beta);

beta =4;
fHtest(beta);

fprintf('For the values of beta = 2, 3 and 4 the hypothesis being tested is false. \n')
fprintf('In that case the hypothesis is not rejected, it is an error of Type II. \n')
fprintf('Naturally the ability of a test to detect a false hypothesis is an \n')
fprintf('important attribute and is called the "power" of the test. The power of a \n')
fprintf('test is the probability of rejecting a false hypothesis, or one minus the \n')
fprintf('probability of accepting it. In the numerical experiments above we see \n')
fprintf('that the percent of rejections goes up further the true mean is from the \n')
fprintf('hypothesized value. The empirical finding that the percent of rejections \n')
fprintf('(power) of a test increases when the hypothesized value is further from \n')
fprintf('the true mean will now be verified. \n')

fprintf('To compute the true probability of a Type II error, given beta = 2 \n')
fprintf('calculate the probability of accepting the hypothesis that the mean \n')
fprintf('equals one. That is, calculate the probability that the test-statistic z \n')
fprintf('falls in the interval (-1.96, 1.96) given that the true population mean \n')
fprintf('is beta. Then the power of the test is one minus the probability of the \n')
fprintf('Type II error. See p. 97 in ITPE2 and verufy algebraically that the term \n') 
fprintf('ADJUST below is the appropiate adjustment to the critical value. \n')

beta = 2;
h0 =1;
sigma = sqrt(10);
t = 10;
adjust = (h0 -beta)/(sigma/sqrt(t));
z1 = 1.96 + adjust;
p1 = normcdf(z1);
z2 = -1.96 + adjust;
p2 = normcdf(z2);
type2 =(p1 -p2);
fprintf('Type II error: %5.2f \n', type2) % print results
fprintf('Power: %5.2f \n', 1-type2) % print results

fprintf('To graph the power function we compute its value for a sequence of betas \n')
fprintf('beginning with -4 and incrementing by 0.1. The power is equal to 1 minus \n')
fprintf('the probability of a Type II error. \n')

beta = seqa( -4, 0.1, 101);
adjust = (h0 - beta)./(sigma./sqrt(t));
power1 = 1 -(normcdf(1.96 + adjust) -  normcdf( -1.96 + adjust));

fprintf('Graph an additional power function, this time assuming that the \n')
fprintf('significance level is equal to 0.1 instead of 0.05, which changes the \n')
fprintf('critical value of the N(0,1) distribution from 1.96 to 1.64 \n')
power2 = 1 -(normcdf(1.64 + adjust) -  normcdf( -1.64 + adjust));

fprintf('Try one more graph, this time assuming that the sample size is T = 40 \n')
t = 40;
adjust = (h0 -beta)/(sigma/sqrt(t));
power3 = 1 -(normcdf(1.96 + adjust) -  normcdf( -1.96 + adjust));

fig7=figure(7);
set(fig7, 'Color', 'white')
plot(beta, power1, 'Color', 'blue', 'LineWidth' , 3)
hold on
plot(beta, power2, 'Color', 'red', 'LineWidth' , 3)
plot(beta, power3, 'Color', 'green', 'LineWidth' , 3)
set(gca, 'LineStyle', '-', 'LineWidth' , 2)
titel='Graph of the power function';
title(titel,'FontSize',10);
legend('power1', 'power2', 'power3', 'Location', 'SouthEast')
ylabel( {'$\pi(\beta)$'}, 'Interpreter', 'latex', 'FontSize', 10 );
xlabel( {'$\beta$'}, 'Interpreter', 'latex', 'FontSize', 10 );
hold off

fprintf('Note that the power of the test increases as the sample size increases. \n')
fprintf('The power of this test increases to unity as the sample size increases to \n')
fprintf('increases to infinity no matter what the true value of beta. That is, the \n')
fprintf('test will always reject a hypothesis that it is not exactly true given \n')
fprintf('enough data. \n')

fprintf('To illustrate the use of likelihood ratio test procedures consider \n')
fprintf('Examples 3.16 to 3.20 in ITPE2. \n')

fprintf('Construct a sample of size T = 100 fro a N(1,4) population \n')
beta =1;
sigma =2;
t = 100;
y =beta +sigma*randn(t,1);

fprintf('Example 3.16 Testing H0: beta = 1 assuming the variance is known \n')
b = sum(y)/T;                 %estimate men
fprintf('b: %5.2f \n', b)     
z = (b -beta)/(sigma/sqrt(t)); % test statistic
fprintf('z: %5.2f \n', z)
pval = 2*normcdf(abs(z), 'upper');
fprintf('pval: %5.2f \n', pval)

fprintf('The p-value is the area in the tails of the distribution of the test \n')
fprintf('statistic. If this value is less than the level of significance of the \n')
fprintf('test, then the hypothesis is rejected. A two-tailed test is assumed. \n')

fprintf('Example 3.17 Testing H0: beta = 1 assuming the variance is unknown \n')
dVar = sum((y-b).^2)/(t-1);          % estimate variance
tstat = (b -beta)/(sqrt(dVar/t));   % test statistic
fprintf('tstat: %5.2f \n', tstat);
pval = 2*tcdf(abs(tstat), t-1, 'upper');
fprintf('pval: %5.2f \n', pval)

fprintf('Example 3.18 Testing H0: sigma2 = 4 \n')
cstat =(t-1)*dVar/(sigma.^2); % test statistic
fprintf('chi2stat: %5.2f \n', cstat)
pval = chi2cdf(cstat, t-1, 'upper');
fprintf('pval: %5.2f \n', pval)

fprintf('To illustrate Example 3.19 and 3.20 create another data set from a N(1,4) \n')
fprintf('population with T2 =75 observations. \n')

t2 =75;
y2 = beta + sigma*randn(t2, 1);

fprintf('Example 3.19: Test of equality of variances of two normal populations. \n')
b2 = sum(y2)/t2;                        % estimate mean
var2 = sum( (y2-b2).^2)/(t2 -1);        % estimate variance

fstat = dVar/var2;                      % test statistic
fprintf('fstat: %5.2f \n', fstat)
pval = fcdf(fstat, t-1, t2-1, 'upper');
fprintf('pval: %5.2f \n', pval)

fprintf('Example 3.20 Joint test of 2 population means with variances known. \n')
jtvar = (sum((y - b).^2) + sum((y2 - b2).^2))/(t +t2 -2); % pooled variance
u = (( b - beta).^2 + (b2 - beta).^2)/(2*jtvar);          % test statistic
fprintf('u: %5.2f \n', u)
pval = fcdf(u, 2, t + t2 -2, 'upper');
fprintf('pval: %5.2f \n', pval)

fprintf('Section 3.5.4 in ITPE2 describes three asymptotically equivalent test \n')
fprintf('procedures that are based on the asymptotic properties of maximum \n')
fprintf('likelihood estimators. The tests are the Likelihood Ratio Test, the Wald \n')
fprintf('test and the Lagrange Multiplier test. To illustrate consider applying \n')
fprintf('these test to the problem of testing a hypotheis about the mean of a \n')
fprintf('normal population with known variance as described in Example 3.21. \n')

fprintf('Write a function for the normal log-likelihood function when the variance \n')
fprintf('is equal to one. \n')

fprintf('Note that this could also be written as: function wLg(i) = sum(log(normpdf(y - dBeta))); \n')

fprintf('Create a sample of data with a sample size of 20 and mean equal to 2. \n')

beta = 2;
t = 20;
y =beta + randn(t, 1);

fprintf('Compute the value of the log-likelihood function for 50 values of b. \n')

b = seqa(-3, 0.2, 50);
lg = fLi(y, b', t, 0);

fprintf('Create a sample of data with a sample size of 100. \n')

t =100;
y =beta + randn(t,1);

fprintf('Graph the log-likelihood for the two samples. \n')

fig8=figure(8);
set(fig8, 'Color', 'white')
plot(b, lg, b, fLi(y, b', t), 'LineStyle', '-', 'LineWidth' , 4)
titel='Log-likelihood function for the two sample';
title(titel,'FontSize',10);
legend('lg1', 'lg2', 'Location', 'SouthEast')
xlabel( {'$\beta$'}, 'Interpreter', 'latex', 'FontSize', 10 );
ylabel( {'log-likelihood'}, 'FontSize', 10 );

fprintf('Compute the information amtrix and the estimated mean, b \n')

i =t;
b =sum(y)/t;
lr = 2*(fLi(y, b, t)-fLi(y, beta, t));      % Likelihood ratio test
fprintf('Likelihood ratio test: %5.2f \n', lr)

pval = chi2cdf(lr, 1);          % p-value
fprintf('pval: %5.2f \n', pval)

w = ((b - beta).^2)*i;          % Wald test
fprintf('wald-test: %5.2f \n', w)

s = sum(y -beta);
lm = (s.^2)/i;                  % Lagrange mult. test
fprintf('Lagrange mult. test: %5.2f \n', lm)

fprintf('The valeus of all three test statistics are identical for this example \n')
fprintf('but this is not true in general. The reader may wish to carry out a \n')
fprintf('similar investigation of these asymptoitc test for the case of a \n')
fprintf('Bernoulli population. See example 3.3. and 3.7. \n')

fprintf('3.6 The Relationship Between Confidence Intervals and Hypothesis Tests \n')

fprintf('In Chapter 3.6 the relationship between confidence intervals and \n')
fprintf('hypothesis test is explored. Here a PROC is given that provides a basis \n')
fprintf('for graphing Figure 3.19 in ITPE2. It can be used to plot confidence \n')
fprintf('ellipses for two means, beta1 and beta2, of a joint normal distribution \n')
fprintf('PROC CONFID takes four arguments: 1) B, the estimates of the means, 2) \n')
fprintf('VARCOV, the variance-covariance matrix of the paramater estimates, 3) \n')
fprintf('FSTAT, the relevant test statistic value, which here is the chi-square \n')
fprintf('divided by 2, and 4) POS, a (2 x1) vector containing the positions of \n')
fprintf('values of beat1 and beta2 in the vector of estimates B. The procedure \n')
fprintf('returns a maxtrix with two columns-the values to be used in plotting the \n')
fprintf('confidence ellipse. Store the PROC for later use, perhaps in the SRC \n')
fprintf('subdirectory as fle CONFID.G so that it can be automatically loaded when \n')
fprintf('called. See your GAUSS manual about automatic loading of procedures. \n')

fprintf('First assume that the covariance between beta1 and beta2 is equal to 0.5. \n')
fprintf('Compute the values for a 5 percentage confidence level (chi = 5.99). The \n')
fprintf('variance-covariance matrix contains the variances of the betas on the \n')
fprintf('diagonal and the covariance term on the off diagonal. \n')

b = [0 0 ]';
varcov = [1 0.5; 0.5 1];
pos = [1 2]';
d = fConfid (b, varcov, 5.99/2, pos);

fprintf('Now graph the confidence region \n')

fig9=figure(9);
set(fig9, 'Color', 'white')
scatter(d(:,1), d(:,2), 'LineWidth' , 2)
titel='Confidence tests';
title(titel,'FontSize',10);
l1 = legend('$\sigma_{12}=0.5$');
set(l1, 'Interpreter', 'latex', 'FontSize', 10 );
xlabel( {'$\beta_1$'}, 'Interpreter', 'latex', 'FontSize', 10 );
ylabel( {'$\beta_2$'}, 'Interpreter', 'latex', 'FontSize', 10 );

fprintf('Repeat the exercise, this time setting the covariance equal to 0.9 \n')

varcov = [1 0.9; 0.9 1];
d1 = fConfid (b, varcov, 5.99/2, pos);

fprintf('Graph both confidence intervals on the same graph \n')

d = [d d1];

fig10=figure(10);
set(fig10, 'Color', 'white')
hold on
scatter(d(:, 1), d(:, 2), 'LineWidth' , 2)
scatter(d(:, 3), d(:, 4), 'LineWidth' , 2)
titel='Confidence tests';
title(titel,'FontSize',10);
l1 = legend('$\sigma_{12}=0.5$', '$\sigma_{12}=0.9$');
set(l1, 'Interpreter', 'latex', 'FontSize', 10 );
xlabel( {'$\beta_1$'}, 'Interpreter', 'latex', 'FontSize', 10 );
ylabel( {'$\beta_2$'}, 'Interpreter', 'latex', 'FontSize', 10 );
hold off

fprintf('Change the confidence level to 10 percent (chi = 4.605). \n')

d2 = fConfid (b, varcov, 4.605/2, pos);

fprintf('Graph the three ellipses \n')

d = [d d2];

fig11=figure(11);
set(fig11, 'Color', 'white')
hold on
scatter(d(:, 1), d(:, 2), 'LineWidth' , 2)
scatter(d(:, 3), d(:, 4), 'LineWidth' , 2)
scatter(d(:, 5), d(:, 6), 'LineWidth' , 2)
titel='Confidence tests';
title(titel,'FontSize',10);
l1 = legend('$\sigma_{12}=0.5$', '$\sigma_{12}=0.9$', '$\sigma_{12}=0.9, (10\%)$');
set(l1, 'Interpreter', 'latex', 'FontSize', 10 );
xlabel( {'$\beta_1$'}, 'Interpreter', 'latex', 'FontSize', 10 );
ylabel( {'$\beta_2$'}, 'Interpreter', 'latex', 'FontSize', 10 );
hold off

fprintf('What happens to the confidence region when the covariance term is \n')
fprintf('negative? \n')

fprintf('Replicate page 112 from ITPE2 \n')

b = [0.7 0.5 ]';
varcov = [1 0; 0 1];
d1 = fConfid (b, varcov, 5.99/2, pos);

varcov = [1 0.5; 0.5 1];
d2 = fConfid (b, varcov, 5.99/2, pos);

varcov = [1 0.9; 0.9 1];
d3 = fConfid (b, varcov, 5.99/2, pos);

d =[d1 d2 d3];

fig12=figure(12);
set(fig12, 'Color', 'white')
hold on
scatter(d(:, 1), d(:, 2), 'LineWidth' , 2)
scatter(d(:, 3), d(:, 4), 'LineWidth' , 2)
scatter(d(:, 5), d(:, 6), 'LineWidth' , 2)
titel='Confidence tests';
title(titel,'FontSize',10);
l1 = legend('$\sigma_{12}=0$', '$\sigma_{12}=0.5$', '$\sigma_{12}=0.9$');
set(l1, 'Interpreter', 'latex', 'FontSize', 10 );
xlabel( {'$\beta_1$'}, 'Interpreter', 'latex', 'FontSize', 10 );
ylabel( {'$\beta_2$'}, 'Interpreter', 'latex', 'FontSize', 10 );
hold off



