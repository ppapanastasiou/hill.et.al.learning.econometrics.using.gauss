function g = fPost(beta)

c = 1;
b = 0.95;
xsum = 196;

% local g;

g = c.*sqrt(xsum).*exp(-0.5*xsum*(beta-b).^2)./sqrt(2*pi);

% retp(g);
% endp;

return