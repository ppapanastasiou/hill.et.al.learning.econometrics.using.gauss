function mom1 = fRhoMu(rho)
% local mom1;
mom1 = rho .* fRhoPost(rho);

return