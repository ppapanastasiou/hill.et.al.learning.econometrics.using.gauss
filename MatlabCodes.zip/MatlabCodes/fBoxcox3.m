% /* BOXCOX3 -- Full likelihood with differing lambdas */
function li =  fBoxcox3(p0)

global y x j

% local k,b,lam,sigmasq,dat,ybc,xbc,e,c,li;
% /* Take apart the parameter vector */
k = cols(x) + 1;
b = p0(1:k,1);
lam = p0(k+1:2*k,1);
sigmasq = p0(rows(p0),1);
% /* Transform the data */
dat = fBct([y x],lam);
ybc = dat(:,1);
xbc = [j dat(:,2:cols(dat))];
% /* Compute the likelihood */
e = ybc - xbc*b;
c = log(2*pi*sigmasq);
li = -(c/2) - (e.*e/(2*sigmasq)) + (lam(1,:)-1) .* log(y);
% retp(li);
% endp;

return