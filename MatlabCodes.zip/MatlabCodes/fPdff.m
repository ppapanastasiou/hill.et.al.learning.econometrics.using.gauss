function out=fPdff(x, n1, n2)

out=(n1/n2).^(n1/n2)*x.^((n1/2)-1)./((gamma(n1/2)*gamma(n2/2)/gamma((n1+n2)/2))*(1+n1*x/n2).^((n1+n2)/2));
return