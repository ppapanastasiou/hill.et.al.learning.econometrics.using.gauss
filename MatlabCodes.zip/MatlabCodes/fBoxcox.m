% /* BOXCOX -- the full log-likelihood function */
function li = fBoxcox(p0)

global y x j

% local c,e,b,li,lambda,sigmasq;
% /* Take apart the parameter vector */

b = p0(1:rows(p0)-2,1);
lambda = p0(rows(p0)-1,1);
sigmasq = p0(rows(p0),1);
% /* Compute the error term for the transformed data */
e = fBct(y,lambda) - ([j fBct(x,lambda)])*b;
% /* Compute the log-likelihood */
c = log(2*pi*sigmasq);
li = -(c/2) - (e.*e./(2*sigmasq)) + (lambda-1).*log(y) ;
% retp(li);
% endp;

return