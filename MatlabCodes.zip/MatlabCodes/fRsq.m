function out = fRsq(beta)

global y

out = nan(length(beta),1);
for i =1:length(beta)
    dBeta = beta(i);
    out(i,1) = sum( (y - fFnb(dBeta)).*(y - fFnb(dBeta)), 1);
end

return