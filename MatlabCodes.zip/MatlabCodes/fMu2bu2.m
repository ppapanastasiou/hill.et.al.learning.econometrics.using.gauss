function mom2 = fMu2bu2(rho,b2)
% local mom2;
mom2 = b2 .* b2 .* fRb2Post2(rho,b2);
% retp(mom2);
% endp;

return