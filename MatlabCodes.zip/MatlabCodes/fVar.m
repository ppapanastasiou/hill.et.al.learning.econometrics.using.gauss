function results=fVar(y,x,nlag)

if nargin < 1; error('wrong # of arguments to fVar'); end;
if nargin > 3; error('wrong # of arguments to fVar'); end;

if (nargin<3 || isempty(nlag))
    nlag=[];
    fid=1;
    fprintf(fid,'\n Number of lags was not entered will enter enmpty matrix. No effect for VAR estimation but number of lags is needed for fPrt_var \n');
end


% find position of the constant. 
IsEqualOne=x==1;
% The constant is the column for which all elements are equal to one
lConst=all(IsEqualOne);
iColConst=find(lConst==1);
% store the column number where the constant is
results.iColConst = iColConst;

[nobs neqs] = size(y);
k=cols(x);
b=x\y; %/* Eq. 18.3.4 */
e = y - x*b; %/* obtain residuals */
sighat = e'*e/(nobs - k); %/* Eq. 18.3.11 */
sigtheta = kron(sighat,invpd(x'*x)); %/* Eq. 18.3.13 */
stderr = sqrt(diag(sigtheta));

% added by panos

results.sighat=sighat;
results.meth = 'vare';

% nobs have been already adjusted for lags
nobse = nobs;

nvar =k;
results.nvar = nvar;
results.nobs = nobse;
results.neqs = neqs;
results.nlag = nlag;

for j=1:neqs
    results(j).beta  = b(:,j);      % bhats 
    results(j).stderr = stderr(k*(j-1)+1:j*k,:);
    tstat = (b(:,j)./stderr(k*(j-1)+1:j*k,:));
    results(j).tstat = tstat;
    results(j).pval = 2*tcdf(abs(tstat),nobs-k,'upper');
    % compute t-probs
    tstat = zeros(nvar,1);
    tstat = results.tstat;
    tout = tdis_prb(tstat,nobse-nvar);
    results(j).tprob = tout;          % t-probs
    
    yvec=y(:,j);
    results(j).yhat = x*b(:,j);
    results(j).resid = yvec - results(j).yhat;
    sigu = results(j).resid'*results(j).resid;
    results(j).sige = sigu/(nobs-nvar);
    ym = yvec - mean(yvec);
    rsqr1 = sigu;
    rsqr2 = ym'*ym;
    results(j).rsqr = 1.0 - rsqr1/rsqr2; % r-squared
    rsqr1 = rsqr1/(nobs-nvar);
    rsqr2 = rsqr2/(nobs-1.0);
    if rsqr2 ~= 0
        results(j).rbar = 1 - (rsqr1/rsqr2); % rbar-squared
    else
        results(j).rbar = results(j).rsqr;
    end;
end

return