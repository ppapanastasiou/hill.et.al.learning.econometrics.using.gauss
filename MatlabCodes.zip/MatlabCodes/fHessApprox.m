function [ mHess, vGrad ] = fHessApprox( hFunc, vX, dEps, varargin )
% fHessApprox.m
% Funktion zur Approximation der Hesse-Matrix
%
% Aufruf:
%   [ mHess, vGrad ] = fHessApprox( hFunc, vX, dEps, varargin )
%
% Input:
%   hFunc:    function handle auf Zielfunktion, ersatzweise String mit 
%             Namen der Funktion
%   vX:       Kx1 Vektor der Argumente der Zielfunktion
%   dEps:     Skalar, Schrittweite (relativ)
%   varargin: Cell-Array mit weiteren zu uebergebenden Inputparametern 
%             fuer die Zielfunktion 
%
% Output:
%   mHess:    K x K Matrix der zweiten partiellen Ableitungen,
%             Approximation der Hesse-Matrix
%
% Achtung: Diese Funktion erlaubt keine vektoriellen Funktionen, d.h., der
% Output von fhandle muss skalar sein!
%
% Version: Februar 2014
%
% Copyright (c) 2013, 2014 Th. Poddig, A. Varmaz, Ch. Fieberg
%
% Bestandteil des Buchs: 
% Computational Finance von Th. Poddig, A. Varmaz, Ch. Fieberg

% Optionale Argumente pruefen
if nargin < 3 || isempty(dEps)
    dEps = 1e-5;
end

% Dimension ermitteln
iNumPara = length(vX);

% Speicherallokation
mHess = NaN(iNumPara,iNumPara);

% Rechtsseitigen Gradienten approximieren
[ vGrad, dFxBase, vFxPh, vFxMh, vHi ] = ...
    fGradApprox( hFunc, vX, dEps, 1, varargin{:} );

% Zweite partiellen Ableitungen approximieren
for iI=1:iNumPara
    for iJ=iI:iNumPara
        vXij = vX;
        vXij(iI) = vXij(iI) + vHi(iI);
        vXij(iJ) = vXij(iJ) + vHi(iJ);
        dFxPlusHij = feval(hFunc,vXij,varargin{:});
        dHessIJ = ...
            (dFxPlusHij - vFxPh(iI) - vFxPh(iJ) + dFxBase) ...
            / (vHi(iI) * vHi(iJ));
        mHess(iI,iJ) = dHessIJ;
        mHess(iJ,iI) = dHessIJ;
    end
end

end