close all;clear;clc
format bank; % two decimal points
% format compact; 

fprintf('7.1 Introduction \n')
fprintf('In this chapter the Bayesian framework of Chapter 4 is extended to the normal \n')
fprintf('linear statistical model. First, a simple model of the consumption function \n')
fprintf('with only one coefficient is analyzed. Second, an example of a normal linear \n')
fprintf('model with more coefficients but a known variance is used. There is a short \n')
fprintf('digression to consider Bayes� point estimation before returning to the standard \n')
fprintf('model with unknown variance. Prior, posterior, and posterior distributions with \n')
fprintf('non-informative priors are examined \n')

fprintf('Chapter 7.2 A Simple Model \n')

fprintf('LOAD the data from file TABLE7.1. The first column represents consumption \n')
fprintf('(Y) and the second column represents income (X). Check the data. \n')
load mDataTable7_1

y = mDataTable7_1(:,1);
x = mDataTable7_1(:,2);

fprintf('Compute the least squares estimate of the marginal propensity to consume beta \n')
b=x\y; %/* Eq. 7.2.2 */
display(b)

fprintf('This was added by me to compute the standard deviation of betahat \n')
[nobs nvar] = size(x);
if nobs < 10000
  [q r] = qr(x,0);
  xpxi = (r'*r)\eye(nvar);
else % use Cholesky for very large problems
  xpxi = (x'*x)\eye(nvar);
end;
beta = xpxi*(x'*y)
yhat = x*beta;
resid = y-yhat;
sigu = resid'*resid;
sige = sigu/(nobs-nvar);
tmp = sige*diag(xpxi);
sigb=sqrt(tmp)

fprintf('Construct a 95% confidence interval for beta assuming that the variance of the \n')
fprintf('error term is known and equal to 2.25. \n')
sigma2=2.25;
interval=1.96*sqrt(sigma2/(x'*x));
dLowerIntervalBeta=(b-interval) %/* Eq. 7.2.3 */
dUpperIntervalBeta=(b+interval) %/* Eq. 7.2.3 */

fprintf('In Section 7.2.1 Bayesian inference with an informative prior is illustrated using \n')
fprintf('the consumption function model. Suppose that there is a 90 percent probability that \n')
fprintf('beta lies between 0.75 and 0.95, as in Equation 7.2.4. Simultaneously solve the \n')
fprintf('system of equations, below (7.2.5), beta- 1.645*sigmahat_b= .75 and beta+1.645 *sigmahat_b=.95 \n')
fprintf('for the mean beta and the standard deviation sigmahat_b of the prior distribution. \n')
a=[1 -1.645; 1 1.645];
c = [0.75 0.95];
c=c';
p=a\c;
bbar=p(1,1) %/* Eq. 7.2.6 */
sigbar=p(2,1) %/* Eq. 7.2.6 */

fprintf('Given the estimates of beta and sigmahat, compute the probability that beta > 1 \n')
z=(1-bbar)/sigbar;
dProb1=normcdf(z);

fprintf('Compute the probability that beta < 0. (You answer here differs somewhat from \n')
fprintf('text because of rounding error.) \n')

z=(0-bbar)/sigbar;
dProb2=normcdf(z);

fprintf('Compute the mean and variance of the posterior distribution, where ho is the \n')
fprintf('precision of the prior information, hs is the precision of the sample information, \n')
fprintf('and h1 is the precision of the posterior information. See Equations 7.2.11 and \n')
fprintf('7.2.12 in the text. Compare your results to those on page 280 of the text. \n')
h0 = 1/(sigbar^2);

fprintf('h0 \n')
hs = (x'*x)/sigma2;

fprintf('hs \n')
bdb = (hs*b + h0*bbar)/(hs + h0); %/* Eq. 7.2.11 */
display(bdb)
h1 = h0 + hs;

fprintf('h1 \n')
sdb2 = 1/h1; %/* Eq. 7.2.12 */
sdb = sqrt(sdb2);
display(sdb)

fprintf('Examine the prior and posterior distributions. See Figure 7.1 in the text. First \n')
fprintf('write a function to compute the p.d.f. for the normal distribution using the \n')
fprintf('standard normal p.d.f. \n')

fprintf('Create a sequence of betas in the relevant range, and compute the prior p.d.f., and \n')
fprintf('graph. \n')
bvec=seqa(0.6, 0.005, 101);
pdfprior=normpdf(bvec, bbar, sigbar); %/* Eq. 7.2.9 */
fig1 = figure(1);
set(fig1, 'Color', 'white')
plot(bvec,pdfprior)

fprintf('Compute the posterior p.d.f. and graph it with the prior. \n')
pdfpost = normpdf(bvec, bdb, sdb);% /* Eq. 7.2.13 and /* Eq. 7.2.15 */
fig2 = figure(2);
set(fig2, 'Color', 'white')
plot(bvec, pdfprior, bvec, pdfpost)
title('Figure 7.1: Prior and posterior p.d.fs for the marginal propensity to consume')
legend('Prior','Posterior')
xlabel('\beta')
ylabel('probability density')

fprintf('Bayesian inference with a noninformative prior is treated in Section 7.2.2. Graph \n')
fprintf('the posterior distribution with a noninformative prior, in addition to the distributions \n')
fprintf('graphed above. (See Figure 7.2 in the text.) \n')
varx = sigma2/(x'*x);
pdfnon = normpdf(bvec, b,sqrt(varx)); %/* Eq. 7.2.21 */
fig3 = figure(3);
set(fig3, 'Color', 'white')
plot(bvec, pdfprior, bvec, pdfpost, bvec, pdfnon); %/* Eq. 7.2.22 */
title('Figure 7.2: Prior, posterior and non-informative p.d.fs for the marginal propensity to consume')
legend('Prior','Posterior','Non-Informative')
xlabel('\beta')
ylabel('probability density')

%%
fprintf('7.3 Bayesian Inference for the General Lineral \n')
fprintf('Model with Known Disturbance Variance \n')
fprintf('In this Section the posterior distribution for vector of linear model parameters \n')
fprintf('is derived under the assumption that the error variance sigma^2 is known. If the prior \n')
fprintf('distribution for the regression parameters is multivariate normal the posterior \n')
fprintf('distribution is also shown to be multivariate normal. If the prior distribution \n')
fprintf('is noninformative the posterior distribution is proportional to the likelihood \n')
fprintf('function and again multivariate normal. \n')

fprintf('7.4 An Example \n')
fprintf('To illustrate the use of a natural conjugate prior a Cobb-Douglas production \n')
fprintf('function is hypothesized. See Equations 7.4.1 and 7.4.2. \n')
fprintf('Prior information is such that P(.2 < beta2 < .8) = P(.2 < beta3 < .8) = .9. \n')
fprintf('Compute the implied mean and variance using the following equations: \n')
fprintf('beta2 - 1.645*sigmahat_beta_2 = 0.2 and beta2 + 1.645*sigmahat_beta2 = 0.8. These equations are a representation \n')
fprintf('of Equation 7.4.9. \n')
close all;clear;clc

a=[1 -1.645; 1 1.645];
c = [0.2 0.8];
c=c';
p=a\c;
bbar2 = p(1,1);
sbar2 = p(2,1);
sbar22 = sbar2^2;
%bbar2 sbar2 sbar22; /* See Eq. 7.4.10 */
c =[ -10 20];
c=c';
p=a\c;
bbar1 = p(1,1);
sbar1 = p(2,1);
sbar11 = sbar1^2;
% bbar1 sbar1 sbar11; /* See Eq. 7.4.12 */
c =[0.9 1.1]; %/* See Eq. 7.4.4 */
c=c';
p=a\c;
bbar23 = p(1,1);
sbar23 = p(2,1);
% bbar23 sbar23;

fprintf('Use the definition of the variance of a sum to compute the covariance: \n')
cov23 = (sbar23*sbar23 - 2*sbar2*sbar2)/2;
% cov23; /* Eq. 7.4.14 */

fprintf('Create the variance-covariance matrix for beta noting that beta2 and beta3 are assumed \n')
fprintf('to have the same prior distribution. See Equation 7.4.15 in the text. \n')
vcbar = [sbar11 0 0; 0 sbar22 cov23; 0 cov23 sbar22]

fprintf('Construct a vector of prior means. \n')
bbar= [bbar1; bbar2; bbar2]

fprintf('Now LOAD the data in file TABLE7.2, define ypf to be the vector of observations \n')
fprintf('on the dependent variable and xpf to be the matrix of regressor values. \n')
load mDataTable7_2
ypf = mDataTable7_2(:,1);
xpf = mDataTable7_2(:,2:4);
disp([ypf xpf])

fprintf('Compute the least squares estimator and its covariance matrix. Assume that \n')
fprintf('sigma^2 is known and equal to .09. \n')
b = xpf\ypf;
display(b) % /* Eq. 7.4.16 */
sigma2 = 0.09;
sigma = sqrt(sigma2);
varcov = sigma2*invpd(xpf'*xpf); %/* Eq. 7.4.17 */
display(varcov)

fprintf('Compute the mean and covariance matrix for the posterior distribution. See \n')
fprintf('Equations 7.4.18 and 7.4.19 in the text. \n')
vcdb = inv( invpd(vcbar) + (xpf'*xpf)/sigma2 );
display(vcdb);

bdb = vcdb*(invpd(vcbar)*bbar + ((xpf'*xpf)/sigma2)*b);
display(bdb)

fprintf('Graph the marginal prior and posterior parameter distributions. Begin with the \n')
fprintf('prior distribution for 2, as in Figure 7.3 in the text. \n')
bvec = seqa(0,.01,101);
pdfprior = normpdf(bvec, bbar2,sbar2);

fig4 = figure(4);
set(fig4, 'Color', 'white')
plot(bvec,pdfprior)
title('Prior p.d.fs for \beta_2 when \sigma is known')
legend('Prior')
xlabel('\beta')
ylabel('probability density of \beta_2')

fig5 = figure(5);
set(fig5, 'Color', 'white')
fprintf('Now add the posterior distribution. \n')
pdfpost = normpdf(bvec, bdb(2,1),sqrt(vcdb(2,2)));
plot(bvec, pdfprior, bvec, pdfpost)
title('Figure 7.3: Prior and posterior p.d.fs for \beta_2 when \sigma is known')
legend('Prior','Posterior')
xlabel('\beta_2')
ylabel('probability density of \beta_2')

fprintf('Repeat the exercise for beta3. Recall that the prior distributions for beta2 and beta3 are \n')
fprintf('identical. \n')
pdfpost = normpdf(bvec, bdb(3,1),sqrt(vcdb(3,3)));
fig6 = figure(6);
set(fig6, 'Color', 'white')
plot(bvec,pdfprior, bvec, pdfpost);
title('Figure 7.3: Prior and posterior p.d.fs for \beta_3 when \sigma is known')
legend('Prior','Posterior')
xlabel('\beta_3')
ylabel('probability density of \beta_3')

fprintf('Compute the 90 percent HPD interval for beta2 using the prior and posterior densities. \n')
disp([(bbar2 - 1.645*sbar2) (bbar2 + 1.645*sbar2)])
interv = 1.645*sqrt(vcdb(2,2));
display(interv)
disp([(bdb(2,1) - interv) (bdb(2,1) + interv)])


fprintf('In Chapter 3.6 the relationship between confidence intervals and hypothesis tests \n')
fprintf('is explored. Here a PROC is given that provides a basis for graphing Figure \n')
fprintf('3.19 in ITPE2. It can be used to plot confidence ellipses for two means, beta2 and \n')
fprintf(' beta3, of a joint normal distribution. PROC CONFID takes four arguments: (1) b, \n')
fprintf('the estimates of the means; (2) varcov, the variance- covariance matrix of the \n')
fprintf('parameter estimates; (3) fstat, the relevant test statistic value, which here is \n')
fprintf('the chi-square value divided by 2; and (4) pos, a (2 x 1) vector containing the \n')
fprintf('positions of values of beta2 and beta3 in the vector of estimates beta. The procedure \n')
fprintf('returns a matrix with two columns�the values to be used in plotting the confidence \n')
fprintf('ellipse. Store the PROC for later use, perhaps in the SRC subdirectory \n')
fprintf('as file confid.g so that it can be automatically �loaded� when called. See your \n')
fprintf('GAUSS manual about automatic loading of procedures. \n')

fprintf('Compute and graph the joint 95 percent HPD region for beta2 and beta3 and again compare \n')
fprintf('the prior with the posterior results. You will need to load the procedure PROC \n')
fprintf('CONFID into memory. Or it must be in file that can be found by GAUSS�S \n')
fprintf('autoloading feature. The procedure takes four arguments. The first is the \n')
fprintf('entire vector of means of the coefficients. The second argument is the variancecovariance \n')
fprintf('matrix, the third the statistic value, which in this case is 2/2. Last \n')
fprintf('is a vector containing the positions of the parameters to use, in this case 2 and \n')
fprintf('3. Begin with the confidence region from he prior distribution. Compare to \n')
fprintf('Figure 7.4. \n')
pos = [2 3];
pos = pos';
d = confid(bbar,vcbar,5.99/2,pos);
fig7 = figure(7);
set(fig7, 'Color', 'white')
plot(d(:,1),d(:,2));
title('Figure 7.4: Prior 95% probability regions for \beta_2 and \beta_3 when \sigma is known')
legend('Prior 95%')
xlabel('\beta_3')
ylabel('\beta_2')

fprintf('Now add the confidence region for the posterior distribution. \n')
d1 = confid(bdb,vcdb,5.99/2,pos);
d = [d d1];
fig8 = figure(8);
set(fig8, 'Color', 'white')
plot(d(:,1), d(:,2), d(:,3), d(:,4));
title('Figure 7.4: Prior and posterior 95% probability regions for \beta_2 and \beta_3 when \sigma is known')
legend('Prior 95%','Posterior 95% region')
xlabel('\beta_3')
ylabel('\beta_2')

%%
fprintf('7.5 Point Estimation \n')
fprintf('Simulate data to compute the empirical Bayes� estimation. (See Section 7.5.2 \n')
fprintf('of the text.) First create a (20 x 4) matrix of normally distributed error terms \n')
fprintf('with a variance equal to 2. \n')
k = 4;
n = 20;
ssq = 2;
e = sqrt(ssq)*randn(n,k);

fprintf('Assume that the (K x 1) vector of betas has a mean of ? and variance tau^2. Create \n')
fprintf('a vector beta. See Equation 7.5.19 in the text. \n')
tau2 = 4;
mu = 2;
beta = mu + sqrt(tau2)*randn(4,1);
display(beta)

fprintf('Use the vector beta and matrix e to create a matrix of observations, y. \n')
y = repmat(beta',length(e),1) + e;

fprintf('The least squares estimator is the vector of sample means. See Equation 7.5.12. \n')
ybar = mean(y);
display(ybar)

fprintf('How do these values compare with the true betas? \n')
fprintf('The estimate for ? is the sample mean of yhat. See the discussion following Equation \n')
fprintf('7.5.21 in the text \n')
ydb = mean(ybar);
display(ydb)

fprintf('How does ydb compare with the true value of ? = 2? \n')
fprintf('An estimate of the weight attached to ? when computing the posterior mean is: \n')
fprintf('(See Equation 7.5.24 in the text.) \n')
wt = ((k-3)*sigma2/n)/(sumc((ybar - ydb).^2));
display(wt)

fprintf('The empirical Bayes� estimator is computed from Equation 7.5.25 in the text. \n')
bdb = wt*ydb + (1-wt)*ybar;
display(bdb)

%%
fprintf('7.6 Comparing Hypotheses and Posterior Odds \n')
fprintf('Here we continue the production function example. Make sure YPF, XPF, B, \n')
fprintf('BBAR, VCBAR, and SIGMA2 from Section 7.4 above are in memory. \n')
ypf;
xpf; 
b;
bbar;
vcbar; 
sigma2;

fprintf('From the discussion following Equation 7.6.10 in the text, compute the matrix \n')
fprintf('a. \n')
a = invpd(vcbar/sigma2);

fprintf('Compute rss1 and q1 from Equations 7.6.13 and 7.6.14. \n')
rss1 = (ypf - xpf*b)'*(ypf - xpf*b);

q1 = (b-bbar)'*(inv(inv(a)+inv(xpf'*xpf)))*(b-bbar);

fprintf('Define q and z using Equation 7.6.17. \n')
q = ypf - xpf(:,3);
z = [xpf(:,1) xpf(:,2) - xpf(:,3)];

fprintf('Define gbar, ghat, and bb (B in the text). See the discussion following Equation \n')
fprintf('7.6.18 and before 7.6.21. \n')
gbar = bbar([1 2],:);
bb = invpd(vcbar(1:2, 1:2)/sigma2);
ghat = z'*z\z'*q;

fprintf('From Equations 7.6.21 and 7.6.22, compute rss0 and q0. \n')
rss0 = (q - z*ghat)'*(q - z*ghat);
q0 = (ghat-gbar)'*(invpd(invpd(bb)+invpd(z'*z)))*(ghat-gbar);

fprintf('Added by me to check the inpouts are correct \n')
display(bbar)
display(inv(a))
display(bbar(1:2))
inv(bb)
display(b)
display(xpf'*xpf)
display(ghat)
display(z'*z)

fprintf('Last, using Equation 7.6.24 compute the posterior odds ratio given a prior odds \n')
fprintf('ratio of unity. \n')
t1 = sqrt( det(bb)/(det(bb + z'*z)));
t2 = sqrt( det(a)/ (det(a + xpf'*xpf)));
k01 = (t1/t2)*exp(-(rss0-rss1+q0-q1)/(2*sigma2));
display(rss0)
display(rss1)
display(q0)
display(q1)
display(k01)

fprintf('Compute the chi-square statistic which would be calculated if the same test \n')
fprintf('were performed within a sampling theory framework. (See Equation 7.6.27.) \n')
chi = (rss0 - rss1)/sigma2;
chi = chi2cdf(chi,1);

%%
fprintf('7.7 Bayesian Inference for the General Linear \n')
fprintf('Model with Unknown Disturbance Variance \n')
fprintf('Continue the production function example from Section 7.5, now assuming that \n')
fprintf('the disturbance variance is unknown. \n')
fprintf('As in Section 4.4 (page 143), solve for the parameters of the inverted gamma, \n')
fprintf('on the assumption that cdfchic(s/.09,v) = .5 and cdfchic(s/(.652),v) = .95. Do \n')
fprintf('so by creating a matrix of possible values of s and v and finding the pair that \n')
fprintf('comes closest to simultaneously satisfying the two equations. \n')
v = seqa(1,1,10);
ssq = seqa(0.05,0.0001,300);
ssq1 = repmat(ssq',length(v),1);
v1 =repmat(v,1,cols(ssq1));
r = v1.*ssq1;
q = abs(chi2cdf(r/.09,v1,'upper') - 0.5 ) + abs(chi2cdf(r/(.65^2),v1,'upper') - .95);
i = fMinColumnOfVector(min(q));
j = fMinColumnOfVector(min(q'));
vbar = v(j,1)
sbarsq = ssq(i,1)

fprintf('vbar sbarsq; \n')
sbar = sqrt(sbarsq);

fprintf('Compute the mean and mode for the prior density for sigma using Equations 4.4.8, \n')
fprintf('on page 142. \n')
meanprior = sqrt(vbar/2)*gamma((vbar-1)/2)*sbar/gamma(vbar/2);
modeprior = sqrt( vbar/(vbar + 1) )*sbar;

fprintf('meanprior modeprior; \n')
fprintf('Compute the mean of the posterior distribution. See Equation 7.7.10. \n')

a = invpd(vcbar/sigma2);

fprintf('Compare the value here with page 314 \n')
adb = inv(a + xpf'*xpf);
bdb = adb*(a*bbar + xpf'*xpf*b);

fprintf('Using Equation 7.7.13 in the text, compute the posterior parameter vdb. \n')
t = rows(ypf);
vdb = t + vbar;

fprintf('Compute the posterior parameter sdb2 using vdb and Equation 7.7.11. \n')
sdb2 =(vbar*sbarsq+ypf'*ypf+bbar'*a*bbar-bdb'*(a+xpf'*xpf)*bdb)/vdb;
fprintf('Graph the marginal prior and posterior distributions for sigma^2 using the inverted \n')
fprintf('gamma p.d.f., given in Equation 7.7.4. In addition, graph the posterior distribution \n')
fprintf('assuming a noninformative prior. Begin by writing a function to compute \n')
fprintf('the p.d.f of the inverted gamma. \n')

fprintf('Create a vector of sigmas in the relevant range, compute the p.d.f. for the marginal \n')
fprintf('prior, and graph. See Figure 7.7. \n')
sigma = seqa(.001,.01,80);
priors = igamma(sigma,vbar,sbar);
fig9 = figure(9);
set(fig9, 'Color', 'white')
plot(sigma,priors);
title('Figure 7.7: Prior p.d.fs for \sigma')
legend('Prior')
xlabel('\sigma')
ylabel('probability density')
fprintf('Now add the marginal posterior distribution for sigma. \n')
posts = igamma(sigma,vdb,sqrt(sdb2));
fig10 = figure(10);
set(fig10, 'Color', 'white')
plot(sigma,priors, sigma,posts);
title('Figure 7.7: Prior and posterior p.d.fs for \sigma')
legend('Prior','Posterior')
xlabel('\sigma')
ylabel('probability density')

fprintf('Next compute some parameters needed for the posterior distribution with a noninformative \n')
fprintf('prior (nonis), compute it, and add it to the graph. See Section 7.7.4 \n')
fprintf('and the definitions below Equation 7.7.34. \n')
k = rows(b);
ssq = (ypf - xpf*b)'*(ypf - xpf*b)/(t - k);
nonis = igamma(sigma,t-k,sqrt(ssq));
fig11 = figure(11);
set(fig11, 'Color', 'white')
plot(sigma, priors, sigma, posts, sigma, nonis);
title('Prior, posterior and non-infomative p.d.fs for \sigma')
legend('Prior','Posterior', 'Non-Informative')
xlabel('\sigma')
ylabel('probability density')

fprintf('Graph the prior and posterior distributions for beta2. Consider both an informative \n')
fprintf('and non-informative prior. See Equations 7.7.26 and 7.7.27. First write \n')
fprintf('the probability density function for the t-distribution: ? is the mean, h is the \n')
fprintf('precision, v is the degrees of freedom and x is the value of the random variable. \n')
fprintf('The formula comes from Equation 7.7.19 with p = 1. \n')

fprintf('Here created function pdft \n')

fprintf('Specify a vector of b�s in the relevant range and graph the prior distribution. \n')
ainv = inv(a);
bvec = seqa(0,.01,100);
priorb = pdft(bbar(2,:),1/(sbarsq*ainv(2,2)),vbar,bvec);
fig12 = figure(12);
set(fig12, 'Color', 'white')
plot(bvec,priorb);
title(' Prior p.d.fs for \beta_2 when \sigma is unknown')
legend('Prior')
xlabel('\beta_2')
ylabel('probability density')

fprintf('Now add the posterior distribution to the graph. \n')
postb = pdft(bdb(2,:),1/(sdb2*adb(2,2)),vdb,bvec);
fig13 = figure(13);
set(fig13, 'Color', 'white')
plot(bvec,priorb, bvec, postb);
title('Figure 7.6: Prior and posterior p.d.fs for \beta_2 when \sigma is unknown')
legend('Prior','Posterior')
xlabel('\beta_2')
ylabel('probability density')

fprintf('Compute the parameters for the posterior with a non-informative prior, and \n')
fprintf('include it in the graph. See Equation 7.7.37. \n')
ixx = invpd(xpf'*xpf);
nonib = pdft(b(2,1),1/(ssq*ixx(2,2)),t-k,bvec);
fig14 = figure(14);
set(fig14, 'Color', 'white')
plot(bvec, priorb, bvec, postb, bvec, nonib);
title('Prior and posterior p.d.fs for \beta_2 when \sigma is unknown')
legend('Prior','Posterior', 'Non-Informative')
xlabel('\beta_2')
ylabel('probability density')

fprintf('Do the same for b3. \n')
priorb = pdft(bbar(3,1),1/(sbarsq*ainv(3,3)),vbar,bvec);
fig15 = figure(15);
set(fig15, 'Color', 'white')
plot(bvec,priorb);
title(' Prior p.d.fs for \beta_3 when \sigma is unknown')
legend('Prior')
xlabel('\beta_3')
ylabel('probability density')

postb = pdft(bdb(3,1),1/(sdb2*adb(3,3)),vdb,bvec);
fig16 = figure(16);
set(fig16, 'Color', 'white')
plot(bvec, priorb, bvec, postb);
title('Prior and posterior p.d.fs for \beta_3 when \sigma is unknown')
legend('Prior','Posterior')
xlabel('\beta_3')
ylabel('probability density')

nonib = pdft(b(3,1),1/(ssq*ixx(3,3)),t-k,bvec);
fig17 = figure(17);
set(fig17, 'Color', 'white')
plot(bvec, priorb, bvec, postb, bvec, nonib);
title('Prior, posterior and non-informative p.d.fs for \beta_3 when \sigma is unknown')
legend('Prior','Posterior', 'Non-Informative')
xlabel('\beta_3')
ylabel('probability density')

fprintf('Compute and graph confidence intervals for b2 and b3 using the informative \n')
fprintf('prior distribution, as in Figure 7.8 in the text. \n')
vcbar = sbarsq*ainv;
vcdb = sdb2*adb;
pos = [2 3];
pos = pos';
d = confid(bbar,vcbar,6.94,pos);

fig18 = figure(18);
set(fig18, 'Color', 'white')
plot(d(:,1),d(:,2));
title('Prior probability regions for \beta_2 and \beta_3 when \sigma is known')
legend('Prior 95%')
xlabel('\beta_3')
ylabel('\beta_2')

fprintf('Now add the confidence region using the posterior distribution. \n')
d1 = confid(bdb,vcdb,3.40,pos);
d = [d d1];
fig19 = figure(19);
set(fig19, 'Color', 'white')
plot(d(:,1), d(:,2), d(:,3), d(:,4));
title('Figure 7.4: Prior and posterior 95% probability regions for \beta_2 and \beta_3 when \sigma is known')
legend('Prior 95%','Posterior 95% region')
xlabel('\beta_3')
ylabel('\beta_2')

fprintf('Can you add the confidence region using the posterior with a non-informative \n')
fprintf('prior to the graph? (Hint: F(2,17) = 3.59, the variance-covariance matrix is \n')
fprintf('ssq*ixx, and the parameter estimates are in b.) \n')



