function I = maxindc(X)

% Returns row number of largest
% element in each column of a matrix

[~, I] = max(X, [], 1);

return