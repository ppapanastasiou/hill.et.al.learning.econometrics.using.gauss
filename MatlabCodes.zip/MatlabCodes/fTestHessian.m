function [ dFx ] = fTestHessian( vX )
% fTestHessian.m
% Tesfunktion zur Schaetzung einer Hesse-Matrix
%
% Aufruf:
%   [ dFx ] = fTestHessian( vX )
%
% Input:
%   vX:  2 x 1 Vektor, Stelle, an welcher der Funktionswert berechnet
%   werden soll
%
% Output:
%   dFx: Skalar, Funktionswert
%
% Version: Februar 2014
%
% Copyright (c) 2013, Th. Poddig, A. Varmaz, Ch. Fieberg
%
% Bestandteil des Buchs: 
% Computational Finance von Th. Poddig, A. Varmaz, Ch. Fieberg

% f(x) = 4 * x(1)^2 - 5 * x(1) * x(2) - 3 * x(2)^2

dFx = 4 * vX(1)^2 - 5 * vX(1) * vX(2) - 3 * vX(2)^2;

end